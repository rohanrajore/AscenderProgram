# gunicorn settings for parcel-api — the process side of the Cloud Run container contract.
# Supplied complete. The Dockerfile starts gunicorn WITH this file.
import os

bind = f"0.0.0.0:{os.environ.get('PORT', '8080')}"   # listen on the port Cloud Run injects
workers = 1                                            # Cloud Run scales instances, not workers
threads = 8                                            # one instance serves many concurrent requests
timeout = 0                                            # Cloud Run enforces the request timeout
graceful_timeout = 8                                   # finish in-flight requests inside the 10 s SIGTERM grace
accesslog = "-"                                        # stdout -> Cloud Logging
errorlog = "-"


def on_exit(server):
    print("parcel-api: SIGTERM received, in-flight requests finished, exiting cleanly", flush=True)
