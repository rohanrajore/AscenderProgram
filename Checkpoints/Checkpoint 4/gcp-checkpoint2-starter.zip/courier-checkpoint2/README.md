# Courier checkpoint 2 — starter kit
Everything is supplied complete. You write no code: the tasks are secrets and identities, a gated pipeline,
and signals and alerts — all in Cloud Shell or the console. See the problem statement.

- baseline.sh            Task 0: puts your project in the starting state (registry, two identities, both services) — run once
- services/parcel-api/   version 2.0 (adds GET /config and FAULT_RATE), Dockerfile included
- services/track-web/    version 1.0, Dockerfile included
- tests/, requirements-dev.txt, pyproject.toml   the gates the pipeline runs
- cloudbuild.yaml        Task 2: the pipeline — gates, build, integration, push, scan, digest
- deploy/                Task 2: Cloud Deploy pipeline + targets, skaffold, the two Cloud Run manifests (PROJECT_ID placeholder)
- observability/alert-5xx.json   Task 3: the alert policy (CHANNEL_NAME placeholder)
- SUBMISSION.md          your answer sheet — fill every blank and hand it back

Upload to Cloud Shell (⋮ → Upload), then:
    unzip -q gcp-checkpoint2-starter.zip && cd courier-checkpoint2 && bash baseline.sh

Region: asia-south1. Repository: courier. Services: parcel-api, track-web (+ parcel-api-staging from Task 2).
Time-box: 2 hours. Leave everything running for grading; the instructor tears down.
