# Courier checkpoint 2 — submission
Name: ____________________   Project id: ____________________   Start time: ________

## Task 1 — Secrets and identities
Secret name: courier-api-key   Versions and their state (`gcloud secrets versions list courier-api-key`): 1 = ________  2 = ________
Revision serving with the file pinned to version 2: ______________________________
`/config` output after rotation — secret_file.sha256_8: ________  (before rotation it was: ________)
Where does parcel-api-sa hold roles/secretmanager.secretAccessor — the project or the secret? ________
courier-deployer holds roles/iam.serviceAccountUser on: ______________________________ (resource, not project)

## Task 2 — Pipeline and promotion
Commit short SHA: ________   Cloud Build id: ______________________________   Build status: ________
Image digest (sha256:…): ______________________________________________________
Release name: ________   Staging rollout state: ________   Prod rollout: approved by ________ at ________
Prod canary phase — the traffic split you observed at 20 %: ______________________________
Prod serving image after advance (`gcloud run services describe parcel-api --format='value(spec.template.spec.containers[0].image)'`):
______________________________________________________

## Task 3 — Signals
Log-based metric name: ________   Its filter: ______________________________________________________
Notification channel display name: ________   Alert policy display name: ______________________________
Uptime check display name: ________   What it checks (host + path): ______________________________

