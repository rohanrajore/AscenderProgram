"""Unit tests for parcel-api — run by the Cloud Build 'unit-tests' gate. Supplied complete."""
import importlib.util
import pathlib

import pytest

APP = pathlib.Path(__file__).resolve().parents[2] / "services" / "parcel-api" / "app.py"


def load_app(monkeypatch, **env):
    for k, v in env.items():
        monkeypatch.setenv(k, v)
    spec = importlib.util.spec_from_file_location("parcel_api_app", APP)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.app.test_client()


def test_banner(monkeypatch):
    c = load_app(monkeypatch)
    body = c.get("/").get_json()
    assert body["service"] == "parcel-api" and body["version"] == "2.0"
    assert body["fault_rate"] == 0


def test_parcels(monkeypatch):
    c = load_app(monkeypatch)
    assert len(c.get("/parcels").get_json()) == 5
    assert c.get("/parcels/cr-1002").get_json()["status"] == "out for delivery"
    assert c.get("/parcels/CR-9999").status_code == 404


def test_eta_flag(monkeypatch):
    assert "eta" not in load_app(monkeypatch).get("/parcels/CR-1001").get_json()
    assert "eta" in load_app(monkeypatch, ETA_ENABLED="true").get("/parcels/CR-1001").get_json()


def test_config_never_returns_value(monkeypatch):
    c = load_app(monkeypatch, API_KEY="s3cret-value-1234")
    body = c.get("/config").get_json()
    assert body["secret_env"]["present"] is True and body["secret_env"]["length"] == 17
    assert "s3cret" not in c.get("/config").get_data(as_text=True)
    assert body["secret_file"] == {"present": False}


@pytest.mark.parametrize("rate,expected", [("1.0", 500), ("0", 200), ("garbage", 200)])
def test_fault_rate(monkeypatch, rate, expected):
    c = load_app(monkeypatch, FAULT_RATE=rate)
    assert c.get("/parcels").status_code == expected
    assert c.get("/healthz").status_code == 200  # health never faults
