#!/bin/bash
# Courier checkpoint 2 — BASELINE (Task 0, not graded). Puts the project in the state the first checkpoint
# left behind, with parcel-api 2.0: registry, two identities, parcel-api (authenticated only), track-web
# (public, calls the api with its own identity). Run ONCE from the kit root: bash baseline.sh
# Idempotent: safe to re-run if something failed half-way.
set -u
PROJECT=$(gcloud config get-value project 2>/dev/null); R=asia-south1; AR=$R-docker.pkg.dev/$PROJECT/courier
[ -z "$PROJECT" ] && { echo "no project set: gcloud config set project <id>"; exit 1; }
echo "baseline for $PROJECT in $R"

gcloud services enable run.googleapis.com artifactregistry.googleapis.com cloudbuild.googleapis.com \
  iam.googleapis.com secretmanager.googleapis.com clouddeploy.googleapis.com containerscanning.googleapis.com \
  ondemandscanning.googleapis.com logging.googleapis.com monitoring.googleapis.com cloudasset.googleapis.com --quiet

gcloud artifacts repositories describe courier --location=$R >/dev/null 2>&1 || \
  gcloud artifacts repositories create courier --repository-format=docker --location=$R --description="Courier images" --quiet

for SA in parcel-api-sa track-web-sa; do
  gcloud iam service-accounts describe $SA@$PROJECT.iam.gserviceaccount.com >/dev/null 2>&1 || \
    gcloud iam service-accounts create $SA --display-name="$SA runtime" --quiet
done

# Cloud Build's default identity (the compute service account) needs to build, push and write logs
PN=$(gcloud projects describe $PROJECT --format='value(projectNumber)')
for ROLE in roles/cloudbuild.builds.builder roles/artifactregistry.writer roles/logging.logWriter; do
  gcloud projects add-iam-policy-binding $PROJECT --member=serviceAccount:$PN-compute@developer.gserviceaccount.com --role=$ROLE --quiet >/dev/null
done

echo "building parcel-api:2.0 and track-web:1.0 (about four minutes)"
gcloud builds submit --tag $AR/parcel-api:2.0 services/parcel-api --quiet >/dev/null || { echo "parcel-api build failed — gcloud builds list --limit 1"; exit 1; }
gcloud builds submit --tag $AR/track-web:1.0 services/track-web --quiet >/dev/null || { echo "track-web build failed"; exit 1; }

gcloud run deploy parcel-api --image $AR/parcel-api:2.0 --region $R \
  --service-account parcel-api-sa@$PROJECT.iam.gserviceaccount.com \
  --no-allow-unauthenticated --memory 512Mi --cpu 1 --concurrency 80 --max-instances 3 \
  --set-env-vars DEPOT=BLR --quiet
API_URL=$(gcloud run services describe parcel-api --region $R --format='value(status.url)')

gcloud run services add-iam-policy-binding parcel-api --region $R \
  --member=serviceAccount:track-web-sa@$PROJECT.iam.gserviceaccount.com --role=roles/run.invoker --quiet >/dev/null
gcloud run deploy track-web --image $AR/track-web:1.0 --region $R \
  --service-account track-web-sa@$PROJECT.iam.gserviceaccount.com \
  --set-env-vars API_URL=$API_URL --allow-unauthenticated --memory 512Mi --max-instances 3 --quiet
WEB_URL=$(gcloud run services describe track-web --region $R --format='value(status.url)')

echo; echo "== baseline check"
curl -s -o /dev/null -w "parcel-api anonymous: HTTP %{http_code} (expect 403)\n" $API_URL/
curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/ ; echo "   (expect version 2.0)"
curl -s "$WEB_URL/?id=CR-1002" | grep -o "status: <b>[^<]*" || echo "track-web could not reach the api — re-run baseline.sh"
echo "API_URL=$API_URL"; echo "WEB_URL=$WEB_URL"
echo "baseline done — start Task 1"
