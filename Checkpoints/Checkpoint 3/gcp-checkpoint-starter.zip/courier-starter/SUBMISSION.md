# Courier checkpoint — submission

Name: ____________________    Project ID: ____________________    Date: __________

Fill every blank by pasting the real value or command output from your project. The instructor
verifies each line against your project with gcloud, so the values must match.

## Task 1 — Dockerfiles
- parcel-api image size (`docker images` SIZE column): ________
- track-web image size: ________
- User the api container runs as (`docker run --rm <image> whoami`): ________

## Task 2 — Contract proof (local run in Cloud Shell)
- Output of `curl -s localhost:9090/healthz` when run with `-e PORT=9090 -p 9090:9090`: ________
- Last log line printed by the api container after `docker stop` (paste it): ________

## Task 3 — Artifact Registry
- Repository resource name (`gcloud artifacts repositories describe courier --location asia-south1 --format='value(name)'`): ________
- Full image path of parcel-api 1.0 (region/project/repo/image:tag): ________
- Full image path of track-web 1.0: ________

## Task 4 — parcel-api on Cloud Run
- Service URL: ________
- Runtime service account (`spec.template.spec.serviceAccountName`): ________
- HTTP code for an anonymous `curl` to the URL: ________
- HTTP code for `curl -H "Authorization: Bearer $(gcloud auth print-identity-token)"` to the URL: ________

## Task 5 — track-web on Cloud Run
- Service URL: ________
- Runtime service account: ________
- The IAM binding that lets web call api (paste the `member` and `role`): ________
- Status shown on the page for parcel CR-1002: ________

## Task 6 — Break it, fix it
- Error text shown on the page after you removed the binding (first 60 characters): ________
- Command you ran to restore it: ________

## Task 7 — Release 1.1 with a traffic split
- Two revision names of parcel-api and their traffic %, from `gcloud run services describe parcel-api --region asia-south1 --format='value(status.traffic)'`: ________
- One line from the track-web page proving ETA is on (the "estimated delivery" line): ________
- Final traffic after promotion: ________

## Stretch (optional)
- track-web `--min-instances` value and the reason you chose it: ________
