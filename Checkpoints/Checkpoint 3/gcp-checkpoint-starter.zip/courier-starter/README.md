# Courier checkpoint — starter kit

Two Python services, supplied complete. Your job is to package and deploy them — see the problem statement document for the tasks.

- parcel-api/   app.py, gunicorn.conf.py, requirements.txt, .dockerignore, Dockerfile (EMPTY — you write it)
- track-web/    app.py, requirements.txt, .dockerignore, Dockerfile (EMPTY — you write it)
- SUBMISSION.md your answer sheet — fill it in and hand it back

Do not edit app.py, gunicorn.conf.py or requirements.txt. Everything else is yours.

Upload to Cloud Shell (⋮ → Upload), then:
    unzip -q gcp-checkpoint-starter.zip && cd courier-starter

Region for everything: asia-south1. Repository name: courier. Service names: parcel-api, track-web.
Time-box: 2 hours. Tear down at the end with the commands in the problem statement.
