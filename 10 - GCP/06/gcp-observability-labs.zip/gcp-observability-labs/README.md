# Observability on Google Cloud — lab kit
- labs.sh          Labs 1–4 as one command sheet — run block by block from this folder
- dashboard.json   the one-page dashboard (Lab 2)
- alert-5xx.json   the alert policy (Lab 3) — CHANNEL_NAME is filled by the sheet
- bookshelf-api/   version 1.2: GET /books fails at FAULT_RATE and logs "simulated fault" — supplied complete; build+deploy ONLY if the CI/CD session did not leave 1.2 running (block at the top of labs.sh)
- bookshelf-web/   version 1.1: forwards the trace header so one page load is one trace across both services (Lab 1 step 8) — supplied complete
- teardown.sh      removes this session's additions, keeps the services
Upload to Cloud Shell (⋮ → Upload), then: unzip -q gcp-observability-labs.zip && cd gcp-observability-labs
Prerequisite: the state the CI/CD session left (bookshelf-api 1.2 with FAULT_RATE support, bookshelf-web reaching it). If not, the kit's bookshelf-api/ gets you there.
