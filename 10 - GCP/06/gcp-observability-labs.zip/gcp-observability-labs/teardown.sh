#!/bin/bash
# Removes the Observability session's additions; keeps the services and the pipeline. Safe to re-run.
PROJECT=$(gcloud config get-value project); R=asia-south1
for P in $(gcloud monitoring policies list --filter='displayName:"bookshelf-api"' --format='value(name)'); do gcloud monitoring policies delete $P --quiet; done
for U in $(gcloud monitoring uptime list-configs --filter='displayName:"bookshelf-web page"' --format='value(name)'); do gcloud monitoring uptime delete $(basename $U) --quiet; done
for D in $(gcloud monitoring dashboards list --filter='displayName:"Bookshelf — one page"' --format='value(name)'); do gcloud monitoring dashboards delete $D --quiet; done
gcloud logging sinks delete bookshelf-errors --quiet 2>/dev/null || true
gcloud logging metrics delete api_simulated_faults --quiet 2>/dev/null || true
gcloud logging sinks update _Default --remove-exclusions=healthz 2>/dev/null || true
gcloud storage rm -r gs://bookshelf-logs-$PROJECT 2>/dev/null || true
gcloud run services update bookshelf-api --region $R --remove-env-vars FAULT_RATE --concurrency 80 --max-instances 3 --quiet 2>/dev/null || true
echo "Observability session resources removed (SLO: delete in the console if created)."
