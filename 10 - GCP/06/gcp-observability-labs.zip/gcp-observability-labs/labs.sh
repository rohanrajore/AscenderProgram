#!/bin/bash
# Observability on Google Cloud — command sheet for Labs 1–4. Run BLOCK BY BLOCK in Cloud Shell from this folder.
PROJECT=$(gcloud config get-value project); PN=$(gcloud projects describe $PROJECT --format='value(projectNumber)')
R=asia-south1; AR=$R-docker.pkg.dev/$PROJECT/bookshelf; ME=$(gcloud config get-value account)
API_URL=$(gcloud run services describe bookshelf-api --region $R --format='value(status.url)')
WEB_URL=$(gcloud run services describe bookshelf-web --region $R --format='value(status.url)')
echo "project=$PROJECT web=$WEB_URL api=$API_URL"
load() { for i in $(seq 1 ${1:-50}); do curl -s -o /dev/null "$WEB_URL/?i=$i" & done; wait; }   # a burst of page loads

# ONLY IF bookshelf-api is not 1.2 (fresh sandbox / CI/CD session not run) — build and deploy the kit's copy, then continue
# gcloud run services describe bookshelf-api --region $R --format='value(spec.template.spec.containers[0].image)'   # → …:1.2 or @sha256 from the pipeline
# (cd bookshelf-api && gcloud builds submit --tag $AR/bookshelf-api:1.2)
# gcloud run services update bookshelf-api --region $R --image $AR/bookshelf-api:1.2 --quiet

# =====================================================================
# LAB 1 — Cloud Logging: find, filter, count, route, exclude
# =====================================================================
# 1 — traffic, including some failures: 30 % of /books calls fail for a minute (the FAULT_RATE setting from the CI/CD kit)
gcloud run services update bookshelf-api --region $R --update-env-vars FAULT_RATE=0.3 --quiet
load 60; sleep 20; load 60
gcloud run services update bookshelf-api --region $R --remove-env-vars FAULT_RATE --quiet

# 2 — the request log of the api: one entry per request, with status, latency and a trace id
gcloud logging read 'resource.type="cloud_run_revision" AND resource.labels.service_name="bookshelf-api" AND httpRequest.requestUrl:"/books"' \
  --limit 5 --format='table(timestamp,httpRequest.status,httpRequest.latency,trace)'
# console: Logging → Logs Explorer → query: resource.type="cloud_run_revision" resource.labels.service_name="bookshelf-api"

# 3 — only the failures; then the application's own log line beside them
gcloud logging read 'resource.type="cloud_run_revision" AND resource.labels.service_name="bookshelf-api" AND httpRequest.status>=500' --limit 3 --format='value(timestamp,httpRequest.status,trace)'
gcloud logging read 'resource.type="cloud_run_revision" AND resource.labels.service_name="bookshelf-api" AND textPayload:"simulated fault"' --limit 3 --format='value(timestamp,textPayload)'

# 4 — one page load across both services: take a trace id from the web's request log and find it in the api's
TRACE=$(gcloud logging read 'resource.type="cloud_run_revision" AND resource.labels.service_name="bookshelf-web" AND httpRequest.requestUrl:"/?i="' --limit 1 --format='value(trace)')
echo $TRACE
gcloud logging read "trace=\"$TRACE\"" --format='table(timestamp,resource.labels.service_name,httpRequest.status,httpRequest.requestUrl)'
# expect two rows: bookshelf-web GET /?i=… and bookshelf-api GET /books — same trace (bookshelf-web 1.1 forwards the header; deploy it in step 8 if you see only one row)

# 5 — a log-based metric: count the application's fault line (a thing the built-in metrics cannot see)
gcloud logging metrics create api_simulated_faults --description="bookshelf-api simulated fault lines" \
  --log-filter='resource.type="cloud_run_revision" AND resource.labels.service_name="bookshelf-api" AND textPayload:"simulated fault"'
gcloud logging metrics list --format='table(name,filter)'
# console: Logging → Log-based metrics → Create metric

# 6 — a sink: route error logs to a bucket you own (retention you control; the auditor's export from Session C)
gcloud storage buckets create gs://bookshelf-logs-$PROJECT --location=$R --uniform-bucket-level-access
gcloud logging sinks create bookshelf-errors storage.googleapis.com/bookshelf-logs-$PROJECT \
  --log-filter='resource.type="cloud_run_revision" AND severity>=ERROR'
SINK_SA=$(gcloud logging sinks describe bookshelf-errors --format='value(writerIdentity)')
gcloud storage buckets add-iam-policy-binding gs://bookshelf-logs-$PROJECT --member=$SINK_SA --role=roles/storage.objectCreator
# objects appear hourly; check later: gcloud storage ls gs://bookshelf-logs-$PROJECT/**

# 7 — an exclusion: stop paying to store health-check noise
gcloud logging sinks update _Default --add-exclusion=name=healthz,filter='httpRequest.requestUrl:"/healthz"'
gcloud logging sinks describe _Default --format='yaml(exclusions)'
# console: Logging → Log Router → _Default → Edit sink → Exclusions

# 8 — bookshelf-web 1.1 (forwards the trace header) — build and deploy if step 4 showed one row
(cd bookshelf-web && gcloud builds submit --tag $AR/bookshelf-web:1.1)
gcloud run services update bookshelf-web --region $R --image $AR/bookshelf-web:1.1 --quiet

# 9 — Log Analytics: SQL over the same logs (console only: Logging → Log Analytics → query)
#   SELECT resource.labels.service_name AS service, http_request.status AS status, COUNT(*) AS n
#   FROM `PROJECT.global._Default._Default`
#   WHERE timestamp > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 HOUR) AND resource.type = 'cloud_run_revision'
#   GROUP BY 1, 2 ORDER BY 1, 2
gcloud logging buckets update _Default --location=global --enable-analytics   # once; harmless if already on

# =====================================================================
# LAB 2 — Cloud Monitoring: metrics, one dashboard, an uptime check, a burst
# =====================================================================
# 1 — read a built-in metric (console)
# console: Monitoring → Metrics Explorer → resource Cloud Run Revision → metric Request Count → group by response_code_class

# 2 — the dashboard from the kit: rate, 5xx, p50/p95/p99, instances, the log-based metric
gcloud monitoring dashboards create --config-from-file=dashboard.json
gcloud monitoring dashboards list --format='table(displayName,name.basename())'
# console: Monitoring → Dashboards → "Bookshelf — one page"

# 3 — an uptime check from outside Google on the public page
WEB_HOST=${WEB_URL#https://}
gcloud monitoring uptime create "bookshelf-web page" --resource-type=uptime-url --resource-labels=host=$WEB_HOST,project_id=$PROJECT \
  --protocol=https --path=/healthz --port=443 --period=1 --timeout=10 --matcher-content=ok --matcher-type=contains-string
gcloud monitoring uptime list-configs --format='table(displayName,monitoredResource.labels.host,period)'
# console: Monitoring → Uptime checks

# 4 — a burst, then watch the dashboard: rate climbs, instances scale, p99 moves
load 150; sleep 5; load 150
gcloud run services describe bookshelf-api --region $R --format='value(status.traffic[0].revisionName)'
# open the dashboard; set the time window to 1 hour; note the instance count step and the latency percentiles during the burst

# =====================================================================
# LAB 3 — Alerting and an SLO as measurement
# =====================================================================
# 1 — a notification channel: your email
CHANNEL=$(gcloud beta monitoring channels create --display-name="grad email" --type=email --channel-labels=email_address=$ME --format='value(name)')
echo $CHANNEL
# check your inbox for the verification mail (email channels need no verification for alerts; Google sends a welcome mail)

# 2 — the alert policy from the kit: 5xx on the api for two minutes → email. Read the JSON first.
sed "s#CHANNEL_NAME#$CHANNEL#" alert-5xx.json > /tmp/alert.json
gcloud monitoring policies create --policy-from-file=/tmp/alert.json
gcloud monitoring policies list --format='table(displayName,enabled,conditions[0].displayName)'
# console: Monitoring → Alerting → Policies

# 3 — an SLO: 99 % of api requests succeed, 28-day rolling window (console: Cloud Run → bookshelf-api → SLOs → Create SLO)
#     metric: Availability · request-based · goal 99 % · rolling 28 days.  Then: Create alerting policy → burn rate, lookback 60 min, threshold 10 (fast burn) → this channel.
# (SLOs are created in the console; the API is available but has no gcloud command. The manual has the clicks.)

# 4 — break it: every /books call fails for three minutes; wait for the email
gcloud run services update bookshelf-api --region $R --update-env-vars FAULT_RATE=1.0 --quiet
load 60; sleep 60; load 60; sleep 60; load 60
# console: Monitoring → Alerting → Incidents — the incident opens after the 2-minute duration; the email follows within a minute

# 5 — restore, watch the incident close (auto-close 30 min, or when the condition clears), and read the dent in the error budget
gcloud run services update bookshelf-api --region $R --remove-env-vars FAULT_RATE --quiet
load 60
# console: Cloud Run → bookshelf-api → SLOs → the availability SLO → error budget remaining

# =====================================================================
# LAB 4 — Cloud Trace: follow one slow request, then name the bad revision
# =====================================================================
# 1 — make the api slow without touching code: a revision with concurrency 1 and one instance, then a burst — requests queue
gcloud run services update bookshelf-api --region $R --concurrency 1 --max-instances 1 --quiet
load 40
# 2 — traces: Cloud Run samples request traces automatically; find the slow ones (console only)
# console: Trace → Trace Explorer → filter by span name "GET /" service bookshelf-web → sort by latency → open one → the waterfall shows bookshelf-web → bookshelf-api
# 3 — from the trace to the logs: copy the trace id, then
# gcloud logging read 'trace="projects/'$PROJECT'/traces/<TRACE_ID>"' --format='table(timestamp,resource.labels.service_name,httpRequest.status,httpRequest.latency)'
# 4 — name the culprit: which revision is serving, and when did it start?
gcloud run revisions list --service bookshelf-api --region $R --format='table(name,active,metadata.creationTimestamp,spec.containerConcurrency)' | head -4
# → the revision with containerConcurrency 1 created minutes ago. STOP HERE — Session B starts with "now what".
# 5 — restore the service's sizing (or leave it broken if Session B follows immediately — ask the trainer)
gcloud run services update bookshelf-api --region $R --concurrency 80 --max-instances 3 --quiet

# Teardown of THIS session's additions (keep the services): alert policy, uptime check, dashboard, sink, metric, exclusion
# bash teardown.sh
