#!/bin/bash
# END OF PROGRAMME ONLY — Sessions D and B start from the Lab 3 state. Removes the IAM-session additions and the Bookshelf services.
PROJECT=$(gcloud config get-value project); R=asia-south1
gcloud run services delete bookshelf-web --region $R --quiet 2>/dev/null || true
gcloud run services delete bookshelf-api --region $R --quiet 2>/dev/null || true
gcloud secrets delete db-password --quiet 2>/dev/null || true
for SA in bookshelf-api-min bookshelf-deployer bookshelf-api-sa bookshelf-web-sa; do
  gcloud iam service-accounts delete $SA@$PROJECT.iam.gserviceaccount.com --quiet 2>/dev/null || true
done
gcloud artifacts repositories delete bookshelf --location=$R --quiet 2>/dev/null || true
echo "IAM session resources removed."
