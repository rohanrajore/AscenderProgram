#!/bin/bash
# IAM, Secrets, Configuration and Environment Boundaries — command sheet for Labs 1–3.
# Same steps as the lab manual. Run BLOCK BY BLOCK in Cloud Shell, never end to end.
# Everything below is gcloud / curl. Nothing is coded. Console paths are in the manual.
PROJECT=$(gcloud config get-value project)
PN=$(gcloud projects describe $PROJECT --format='value(projectNumber)')
R=asia-south1
ME=$(gcloud config get-value account)
AR=$R-docker.pkg.dev/$PROJECT/bookshelf
echo "project=$PROJECT number=$PN region=$R me=$ME"

# ==== IF THE BOOKSHELF SERVICES ARE GONE (only if `gcloud run services list --region $R` is empty) ====
# Rebuilds the state the Cloud Run session left: two services, two service accounts, one invoker binding.
# gcloud services enable run.googleapis.com artifactregistry.googleapis.com cloudbuild.googleapis.com
# gcloud artifacts repositories create bookshelf --repository-format=docker --location=$R 2>/dev/null
# (cd bookshelf-api && gcloud builds submit --tag $AR/bookshelf-api:1.0)
# gcloud iam service-accounts create bookshelf-api-sa; gcloud iam service-accounts create bookshelf-web-sa
# gcloud run deploy bookshelf-api --image $AR/bookshelf-api:1.0 --region $R --service-account bookshelf-api-sa@$PROJECT.iam.gserviceaccount.com --no-allow-unauthenticated
# gcloud run services add-iam-policy-binding bookshelf-api --region $R --member=serviceAccount:bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --role=roles/run.invoker
# (bookshelf-web: use the Cloud Run session kit; Labs 1–3 below need only bookshelf-api and both service accounts)

# =====================================================================
# LAB 1 — an identity with nothing, a token you can read, and actAs
# =====================================================================
# 1 — where we start: what does bookshelf-api run as, and what roles does that identity hold?
gcloud run services describe bookshelf-api --region $R --format='value(spec.template.spec.serviceAccountName)'
gcloud projects get-iam-policy $PROJECT --flatten='bindings[].members' --filter='bindings.members:bookshelf-api-sa' --format='table(bindings.role)'
# expect: (empty) — the Cloud Run session created it with no roles. If you see roles here, note them: they are over-grants.

# 2 — a brand-new identity with no roles at all; run the api as it. It still serves.
gcloud iam service-accounts create bookshelf-api-min --display-name="bookshelf-api least-privilege"
gcloud run services update bookshelf-api --region $R --service-account bookshelf-api-min@$PROJECT.iam.gserviceaccount.com
API_URL=$(gcloud run services describe bookshelf-api --region $R --format='value(status.url)')
curl -s -o /dev/null -w "anonymous: HTTP %{http_code}\n" $API_URL/                                                   # 403 — IAM on the service
curl -s -w "\nme: HTTP %{http_code}\n" -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/       # 200 — a service needs no roles to SERVE
# console: Cloud Run → bookshelf-api → Edit & deploy new revision → Security → Service account

# 3 — impersonation is a permission too: grant yourself Token Creator on the web identity, then mint its token
gcloud iam service-accounts add-iam-policy-binding bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com \
  --member=user:$ME --role=roles/iam.serviceAccountTokenCreator
sleep 30   # IAM propagation
TOKEN=$(gcloud auth print-identity-token --impersonate-service-account=bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --audiences=$API_URL --include-email)
echo $TOKEN | cut -d. -f2 | tr '_-' '/+' | base64 -d 2>/dev/null | python3 -m json.tool
# expect: "aud": <API_URL>, "email": bookshelf-web-sa@..., "exp": one hour ahead
curl -s -o /dev/null -w "as web-sa: HTTP %{http_code}\n" -H "Authorization: Bearer $TOKEN" $API_URL/                 # 200 — invoker binding from the Cloud Run session
# wrong audience: mint for a different URL and present it here
BAD=$(gcloud auth print-identity-token --impersonate-service-account=bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --audiences=https://example.com --include-email)
curl -s -o /dev/null -w "wrong audience: HTTP %{http_code}\n" -H "Authorization: Bearer $BAD" $API_URL/             # 401 — rejected before IAM is consulted

# 4 — actAs: a deployer identity that may deploy but may not run code AS bookshelf-api-min
gcloud iam service-accounts create bookshelf-deployer --display-name="deployer (no actAs yet)"
gcloud projects add-iam-policy-binding $PROJECT --member=serviceAccount:bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --role=roles/run.admin
gcloud iam service-accounts add-iam-policy-binding bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --member=user:$ME --role=roles/iam.serviceAccountTokenCreator
sleep 30
gcloud run services update bookshelf-api --region $R --update-env-vars GREETING="deployed by the deployer" \
  --impersonate-service-account=bookshelf-deployer@$PROJECT.iam.gserviceaccount.com
# expect: ERROR ... PERMISSION_DENIED: Permission 'iam.serviceaccounts.actAs' denied on service account bookshelf-api-min@...
gcloud iam service-accounts add-iam-policy-binding bookshelf-api-min@$PROJECT.iam.gserviceaccount.com \
  --member=serviceAccount:bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --role=roles/iam.serviceAccountUser
sleep 30
gcloud run services update bookshelf-api --region $R --update-env-vars GREETING="deployed by the deployer" \
  --impersonate-service-account=bookshelf-deployer@$PROJECT.iam.gserviceaccount.com                                # succeeds
curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/ | grep -o '"greeting":"[^"]*"'

# 5 — the answer sheet: every role each identity holds, anywhere in the project
for SA in bookshelf-api-min bookshelf-web-sa bookshelf-deployer; do
  echo "== $SA"; gcloud projects get-iam-policy $PROJECT --flatten='bindings[].members' --filter="bindings.members:$SA@" --format='value(bindings.role)'
done
gcloud run services get-iam-policy bookshelf-api --region $R --format='value(bindings)'
# expect: api-min: nothing at project level. web-sa: nothing at project level; run.invoker ON THE SERVICE. deployer: run.admin (project) + serviceAccountUser on api-min.

# =====================================================================
# LAB 2 — a managed secret, mounted and injected, then rotated
# =====================================================================
# 1 — bookshelf-api 1.1 (adds GET /config, which fingerprints the secret — never the value). Build and push.
gcloud services enable secretmanager.googleapis.com
(cd bookshelf-api && gcloud builds submit --tag $AR/bookshelf-api:1.1)

# 2 — the secret, version 1, from a file (never on the command line: it would sit in shell history)
printf 'v1-correct-horse' > /tmp/db-password.txt
gcloud secrets create db-password --replication-policy=automatic --data-file=/tmp/db-password.txt
rm /tmp/db-password.txt
gcloud secrets versions list db-password                                                                          # 1 enabled
# console: Security → Secret Manager → Create secret

# 3 — access control ON THE SECRET, for the api identity only
gcloud secrets add-iam-policy-binding db-password \
  --member=serviceAccount:bookshelf-api-min@$PROJECT.iam.gserviceaccount.com --role=roles/secretmanager.secretAccessor
gcloud secrets get-iam-policy db-password

# 4 — revision A: the secret as a FILE tracking latest; revision B: as an ENV VAR pinned to version 1
gcloud run services update bookshelf-api --region $R --image $AR/bookshelf-api:1.1 \
  --update-secrets=/secrets/db-password=db-password:latest --tag file
gcloud run services update bookshelf-api --region $R \
  --update-secrets=DB_PASSWORD=db-password:1 --tag env
# two revisions now exist; the newest (env var + file) receives traffic. Read /config:
curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/config | python3 -m json.tool
# expect: secret_file {present:true, length:16, sha256_8:...}  secret_env {present:true, length:16, same sha256_8}

# 5 — rotate: add version 2. Read again (allow ~10 s). The file changes; the env var does not.
printf 'v2-battery-staple' > /tmp/db-password.txt
gcloud secrets versions add db-password --data-file=/tmp/db-password.txt; rm /tmp/db-password.txt
sleep 10; curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/config | python3 -m json.tool
# expect: secret_file length 17 with a NEW sha256_8; secret_env still length 16 with the OLD one — resolved once, at instance start

# 6 — disable version 1. The env-var revision keeps its value (already in memory) until a new instance starts.
gcloud secrets versions disable 1 --secret=db-password
gcloud secrets versions list db-password                                                                          # 2 enabled, 1 disabled
# force a new instance and watch the env-var revision fail to start — its pinned version is disabled:
gcloud run services update bookshelf-api --region $R --update-env-vars ROTATED=yes
# expect: ERROR ... Revision ... is not ready ... Permission denied / disabled version on secret db-password/versions/1
# fix by pinning to 2 (what a real rotation runbook does), then confirm:
gcloud run services update bookshelf-api --region $R --update-secrets=DB_PASSWORD=db-password:2
curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/config | python3 -m json.tool      # both fingerprints now match version 2

# 7 — who may read: the other identity is refused
gcloud secrets versions access latest --secret=db-password --impersonate-service-account=bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com
# expect: ERROR: PERMISSION_DENIED: Permission 'secretmanager.versions.access' denied for resource 'projects/.../secrets/db-password/versions/latest'
# and you, as Owner, are NOT refused — remember that for Lab 3:
gcloud secrets versions access latest --secret=db-password | wc -c                                               # 17

# =====================================================================
# LAB 3 — bring it together: least privilege, managed secret, internal ingress, two audit answers
# =====================================================================
# 1 — the api on internal ingress (web still reaches it through Direct VPC egress from the Cloud Run session; if web is not deployed, skip that check)
gcloud run services update bookshelf-api --region $R --ingress internal
gcloud run services describe bookshelf-api --region $R --format='value(metadata.annotations."run.googleapis.com/ingress")'   # internal
curl -s -o /dev/null -w "from the internet: HTTP %{http_code}\n" -H "Authorization: Bearer $(gcloud auth print-identity-token)" $API_URL/   # 404 — internal ingress refuses before IAM

# 2 — Data Access audit logs ON for Secret Manager (console: IAM & Admin → Audit Logs → Secret Manager API → Data Read + Data Write)
gcloud projects get-iam-policy $PROJECT --format=json > /tmp/policy.json
python3 - <<'EOF'
import json; p=json.load(open('/tmp/policy.json'))
cfg=[c for c in p.get('auditConfigs',[]) if c['service']!='secretmanager.googleapis.com']
cfg.append({'service':'secretmanager.googleapis.com','auditLogConfigs':[{'logType':'DATA_READ'},{'logType':'DATA_WRITE'}]})
p['auditConfigs']=cfg; json.dump(p,open('/tmp/policy.json','w'),indent=1)
EOF
gcloud projects set-iam-policy $PROJECT /tmp/policy.json | grep -A4 auditConfigs

# 3 — generate two reads: one by you, one by the service (a fresh instance fetches the env-var secret)
gcloud secrets versions access latest --secret=db-password >/dev/null
gcloud run services update bookshelf-api --region $R --update-env-vars TOUCH=$(date +%s) >/dev/null
sleep 60

# 4 — who CAN read it: Policy Analyzer walks inheritance (Cloud Asset API enabled by prep-project.sh)
gcloud services enable cloudasset.googleapis.com
gcloud asset analyze-iam-policy --project=$PROJECT \
  --full-resource-name=//secretmanager.googleapis.com/projects/$PN/secrets/db-password \   # project NUMBER, as in the audit log
  --permissions=secretmanager.versions.access
# expect: bookshelf-api-min via secretAccessor on the secret; YOU via roles/owner on the project (inherited — never bound on the secret)

# 5 — who DID read it: the Data Access log
gcloud logging read 'protoPayload.serviceName="secretmanager.googleapis.com" AND protoPayload.methodName="google.cloud.secretmanager.v1.SecretManagerService.AccessSecretVersion"' \
  --limit 10 --format='table(timestamp, protoPayload.authenticationInfo.principalEmail, protoPayload.resourceName)'
# expect: one row for you, one for bookshelf-api-min@ (the service's fetch at instance start)

# 6 — the answer sheet for the auditor (paste into Lab 3's table in the manual)
gcloud secrets versions list db-password
for SA in bookshelf-api-min bookshelf-web-sa; do echo "== $SA"; gcloud projects get-iam-policy $PROJECT --flatten='bindings[].members' --filter="bindings.members:$SA@" --format='value(bindings.role)'; done
gcloud secrets get-iam-policy db-password --format='value(bindings)'
gcloud run services get-iam-policy bookshelf-api --region $R --format='value(bindings)'

# DO NOT TEAR DOWN — Sessions D (CI/CD) and B (Incident) start from this state. teardown.sh is for the end of the programme.
echo "Lab 3 complete. Leave everything running."
