#!/bin/bash
# TRAINER — run once per sandbox project the day before (needs roles/orgpolicy.policyAdmin on the ORGANIZATION for step 2).
# Usage: bash prep-project.sh <project-id>
PROJECT=${1:?project id}
gcloud services enable run.googleapis.com artifactregistry.googleapis.com cloudbuild.googleapis.com \
  secretmanager.googleapis.com cloudasset.googleapis.com iam.googleapis.com compute.googleapis.com --project=$PROJECT
# Domain restricted sharing is enforced by default on orgs created after May 2024; sandboxes need allUsers for public services.
cat > /tmp/allow-all.yaml <<YAML
name: projects/$PROJECT/policies/iam.allowedPolicyMemberDomains
spec:
  rules:
  - allowAll: true
YAML
gcloud org-policies set-policy /tmp/allow-all.yaml
gcloud org-policies describe iam.allowedPolicyMemberDomains --project=$PROJECT --effective
# Cloud Build runs as the default compute SA in new projects; make sure it can build and push.
PN=$(gcloud projects describe $PROJECT --format='value(projectNumber)')
for ROLE in roles/cloudbuild.builds.builder roles/artifactregistry.writer roles/logging.logWriter; do
  gcloud projects add-iam-policy-binding $PROJECT --member=serviceAccount:$PN-compute@developer.gserviceaccount.com --role=$ROLE --quiet >/dev/null
done
echo "prepared $PROJECT — allow a few minutes for org policy and IAM to propagate"
