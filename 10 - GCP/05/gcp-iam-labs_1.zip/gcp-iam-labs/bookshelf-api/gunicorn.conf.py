# gunicorn settings — the process side of the container contract.
import os
bind = f"0.0.0.0:{os.environ.get('PORT', '8080')}"   # listen on the port Cloud Run injects
workers = 1                                            # Cloud Run scales instances, not workers
threads = 8                                            # one instance handles many concurrent requests
timeout = 0                                            # let Cloud Run enforce the request timeout
graceful_timeout = 8                                   # finish in-flight requests within Cloud Run's 10 s SIGTERM grace
accesslog = "-"                                        # access log to stdout -> Cloud Logging
errorlog = "-"


def on_exit(server):
    print("bookshelf-api: SIGTERM received, in-flight requests finished, exiting cleanly", flush=True)
