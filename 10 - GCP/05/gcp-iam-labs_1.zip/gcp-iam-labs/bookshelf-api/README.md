bookshelf-api 1.1 — supplied complete for the IAM & Secrets session. Same service as the Cloud Run session
plus GET /config, which reports whether a secret reached the container as a file or as an env var
(length + SHA-256 prefix only; the value is never returned). Build with Cloud Build in Lab 2 — nothing is edited.
