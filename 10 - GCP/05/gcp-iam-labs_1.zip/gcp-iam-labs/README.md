# IAM, Secrets, Configuration and Environment Boundaries — lab kit
- labs.sh                 Labs 1–3 as one command sheet (same steps as the manual) — run block by block, never end to end
- bookshelf-api/          the api, version 1.1 (adds GET /config — fingerprints a secret, never prints it). Supplied complete; built with Cloud Build in Lab 2
- activity-a-policy.yaml  Activity A: a 12-binding policy with three over-grants
- activity-b-template.md  Activity B: the three-environment boundary template
- prep-project.sh         TRAINER: per-sandbox preparation (APIs, org-policy override, Cloud Build SA roles)
- teardown.sh             END OF PROGRAMME only — later sessions start from Lab 3's state
Upload to Cloud Shell (⋮ → Upload), then: unzip -q gcp-iam-labs.zip && cd gcp-iam-labs
Prerequisite: bookshelf-api deployed from the Cloud Run session (labs.sh has a rebuild block if it is gone).
