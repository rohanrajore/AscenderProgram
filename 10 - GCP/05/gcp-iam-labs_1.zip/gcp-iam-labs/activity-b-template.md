# Activity B — boundaries for Bookshelf across three environments (pairs, 15 min)
Draw on paper or in a text file. Fill every blank.

## 1 · Folders and projects
Organization: example.com
  folder: __________  → projects: __________ (shared registry lives here), __________ (CI)
  folder: __________  → projects: bookshelf-dev, sandboxes            ← org-policy override (domain restricted sharing: allowAll) lives on THIS folder
  folder: __________  → projects: bookshelf-staging, bookshelf-prod   ← Data Access audit logs ON here

## 2 · Identities (project-qualified) and secrets — six of each
| Environment | bookshelf-api runs as | bookshelf-web runs as | secret db-password lives in | api ingress | web public? |
|---|---|---|---|---|---|
| dev | bookshelf-api-sa@__________ | bookshelf-web-sa@__________ | project __________, version __ | ______ | ______ |
| staging | | | | | |
| prod | | | | | |

## 3 · What crosses
The only resource all three environments read: __________________________ (identical by digest)
The pipeline identity: __________@__________ holds roles/run.admin on projects ____, ____, ____ and roles/iam.serviceAccountUser on ______ (not on the projects)

## 4 · Blast radius
A token for bookshelf-api-sa@bookshelf-dev leaks. List everything it can reach:
- 
- 
If your list contains anything in staging or prod, name the shared thing that should not be shared: __________
