# bookshelf-api — container edition (supplied complete)

Nothing in this folder is edited during the lab. You read it, build it, push it and deploy it.

- `app.py` — the catalogue API with the endpoints the lab uses: `/`, `/books`, `/books/<id>`, `/healthz`, `/whoami`, `/slow?seconds=N`
- `gunicorn.conf.py` — the process side of the container contract (PORT, graceful shutdown within 10 s, logs to stdout)
- `requirements.txt` — pinned dependencies
- `Dockerfile.naive` — the first Dockerfile everyone writes (big, root, unpinned)
- `Dockerfile` — the hardened multi-stage, slim, pinned, non-root image
- `.dockerignore` — what never enters the build context

Try it without a container: `pip install -r requirements.txt && gunicorn --config gunicorn.conf.py app:app`, then `curl localhost:8080/healthz`.
All commands for the lab are on the slides (and in the lab guide if you have one).
