"""bookshelf-api — the catalogue service, container edition.
Supplied complete: nothing here is edited in the lab. Read it to see what the
container contract needs from an app: PORT, /healthz, clean shutdown, logs to stdout.
"""
import os
import socket
import time
import logging
from flask import Flask, jsonify, request

logging.basicConfig(level=logging.INFO, format="%(message)s")  # Cloud Run collects stdout/stderr
log = logging.getLogger("bookshelf-api")
app = Flask(__name__)

BOOKS = [
    {"id": 1, "title": "The Pragmatic Programmer", "author": "Hunt & Thomas", "year": 1999},
    {"id": 2, "title": "Designing Data-Intensive Applications", "author": "Kleppmann", "year": 2017},
    {"id": 3, "title": "Site Reliability Engineering", "author": "Beyer et al.", "year": 2016},
    {"id": 4, "title": "Release It!", "author": "Nygard", "year": 2018},
]
VERSION = os.environ.get("APP_VERSION", "v1")          # runtime configuration, never baked into the image
GREETING = os.environ.get("GREETING", "Bookshelf catalogue")
STARTED = time.time()
INSTANCE = socket.gethostname()                        # differs per container instance


@app.get("/")
def index():
    return jsonify({"service": "bookshelf-api", "version": VERSION, "greeting": GREETING, "books": len(BOOKS)})


@app.get("/books")
def list_books():
    return jsonify(BOOKS)


@app.get("/books/<int:book_id>")
def get_book(book_id: int):
    for book in BOOKS:
        if book["id"] == book_id:
            return jsonify(book)
    return jsonify({"error": f"book {book_id} not found"}), 404


@app.get("/healthz")
def healthz():
    # the health contract: cheap, no dependencies, 200 means "send me traffic"
    return jsonify({"status": "ok", "uptime_s": round(time.time() - STARTED, 1)})


@app.get("/whoami")
def whoami():
    # which instance answered, and how long it has been alive — makes scaling and cold starts visible
    return jsonify({"instance": INSTANCE, "uptime_s": round(time.time() - STARTED, 1), "version": VERSION})


@app.get("/slow")
def slow():
    # simulates long-running work: /slow?seconds=45 — used to demonstrate request timeouts
    seconds = min(int(request.args.get("seconds", 5)), 600)
    log.info("slow request started: %s s", seconds)
    time.sleep(seconds)
    return jsonify({"slept_s": seconds, "instance": INSTANCE})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
