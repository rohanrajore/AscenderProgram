# Containerize and Deploy the Python Service to Cloud Run — lab kit
- bookshelf-web/ — the second service (public page that calls the api with its own identity), supplied complete — Lab 4
- bookshelf-api/ — the service, supplied complete (app.py, gunicorn.conf.py, requirements.txt, Dockerfile.naive, Dockerfile, .dockerignore). Nothing is edited.
- labs.sh — the four labs as one command sheet (matches the lab manual): run block by block, never all at once (some steps wait 30–45 s on purpose).
- teardown.sh — service, repository, local images.
Upload to Cloud Shell (⋮ → Upload), then: unzip -q gcp-cloudrun-labs-all.zip && cd gcp-cloudrun-labs
