# bookshelf-web (supplied complete — nothing to edit)
The public face: renders the catalogue it fetches from bookshelf-api. It mints an ID token for the api's URL with its own
service-account identity (google-auth, metadata server — no keys) and sends it as a Bearer header. Used in Lab 4.
