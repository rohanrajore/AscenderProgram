"""bookshelf-web — the public face. Renders the catalogue it fetches from bookshelf-api.
bookshelf-api has ingress=internal and requires an ID token, so this service must
(1) reach it through the VPC (Direct VPC egress) and (2) present its own identity.
"""
import os
import requests
import google.auth.transport.requests
import google.oauth2.id_token
from flask import Flask, render_template_string

app = Flask(__name__)
API_URL = os.environ.get("API_URL", "http://localhost:8091")  # local default for testing

PAGE = """<!doctype html><title>Bookshelf</title>
<body style="font-family:sans-serif;max-width:640px;margin:2em auto">
<h1>Bookshelf</h1>
<p style="color:#666">catalogue from <code>{{ api }}</code> (api version {{ version }})</p>
{% if error %}<p style="color:#9B2C1F">{{ error }}</p>{% endif %}
<ul>{% for b in books %}<li><b>{{ b.title }}</b> — {{ b.author }} ({{ b.year }})</li>{% endfor %}</ul>
</body>"""


def api_headers() -> dict:
    """Return the Authorization header for a call to bookshelf-api.

    Mints an ID token for the api's URL (the *audience*) using this service's own identity (the metadata server hands it out — no keys).
    Locally there is no metadata server, so fall back to no header.
    """
    if API_URL.startswith("http://localhost"):
        return {}
    auth_req = google.auth.transport.requests.Request()
    token = google.oauth2.id_token.fetch_id_token(auth_req, API_URL)
    return {"Authorization": f"Bearer {token}"}


@app.get("/")
def index():
    books, version, error = [], "?", None
    try:
        r = requests.get(f"{API_URL}/", headers=api_headers(), timeout=5)
        r.raise_for_status()
        version = r.json().get("version", "?")
        r = requests.get(f"{API_URL}/books", headers=api_headers(), timeout=5)
        r.raise_for_status()
        books = r.json()
    except Exception as exc:  # show the failure on the page: that IS the lab signal
        error = f"could not reach bookshelf-api: {exc}"
    return render_template_string(PAGE, api=API_URL, version=version, books=books, error=error)


@app.get("/healthz")
def healthz():
    return "ok", 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
