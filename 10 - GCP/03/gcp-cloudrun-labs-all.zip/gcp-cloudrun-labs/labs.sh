#!/bin/bash
# Containerize and Deploy the Python Service to Cloud Run — the three labs as a command sheet (matches the lab manual).
# Run block by block in Cloud Shell from the folder that contains bookshelf-api/. Nothing to code.
cd bookshelf-api
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com
AR=asia-south1-docker.pkg.dev/$(gcloud config get-value project)/bookshelf

# ==== LAB 1 — build the image twice and compare
docker build -f Dockerfile.naive -t bookshelf-api:naive .
docker images bookshelf-api
docker history bookshelf-api:naive --format 'table {{.Size}}\t{{.CreatedBy}}' | head -8
docker run --rm bookshelf-api:naive id -u
docker run --rm bookshelf-api:naive sh -c 'ls /app; python -c "import flask; print(flask.__version__)"'

# (Lab 1 continued) hardened image
docker build -t bookshelf-api:1.0 .
docker images bookshelf-api
docker history bookshelf-api:1.0 --format 'table {{.Size}}\t{{.CreatedBy}}' | head -12
docker run --rm bookshelf-api:1.0 id -u
docker run --rm bookshelf-api:1.0 sh -c 'which gcc || echo no-gcc'
docker run -d --name api -p 8080:8080 bookshelf-api:1.0
curl -s localhost:8080/healthz; echo; curl -s localhost:8080/whoami; echo; curl -s localhost:8080/books/2; echo

# (Lab 1 continued) contract check
# ==== LAB 2 — push, deploy with sizing, timeout, cold start
time docker stop api
docker logs api | tail -2
docker inspect api --format '{{.State.ExitCode}}'
docker rm api
gcloud artifacts repositories create bookshelf --repository-format=docker --location=asia-south1 || true
gcloud builds submit --tag $AR/bookshelf-api:1.0
gcloud artifacts docker images list $AR --include-tags

# (Lab 2) deploy with sizing, provoke a timeout
gcloud run deploy bookshelf-api --image $AR/bookshelf-api:1.0 --region asia-south1 \
  --cpu 1 --memory 512Mi --concurrency 80 --max-instances 5 --timeout 30 --allow-unauthenticated
URL=$(gcloud run services describe bookshelf-api --region asia-south1 --format='value(status.url)')
curl -s $URL/healthz; echo; curl -s $URL/books/2; echo
for i in $(seq 10); do curl -s $URL/whoami; echo; done
curl -s -o /dev/null -w '%{http_code} in %{time_total}s\n' "$URL/slow?seconds=45"      # 504 after 30 s
gcloud run services update bookshelf-api --region asia-south1 --timeout 120
curl -s -o /dev/null -w '%{http_code} in %{time_total}s\n' "$URL/slow?seconds=45"      # 200 after ~45 s

# (Lab 2) cold starts
gcloud run services update bookshelf-api --region asia-south1 --update-env-vars MARK=cold
curl -s -w '\ntotal %{time_total}s\n' $URL/whoami      # cold
curl -s -w '\ntotal %{time_total}s\n' $URL/whoami      # warm
gcloud run services update bookshelf-api --region asia-south1 --min-instances 1 --cpu-boost

# ==== LAB 3 — configure, split, roll back, read the logs
gcloud run services update bookshelf-api --region asia-south1 --update-env-vars GREETING='Hello from v2',APP_VERSION=v2
curl -s $URL/; echo
NEW=$(gcloud run revisions list --service bookshelf-api --region asia-south1 --format='value(name)' --limit 1)
OLD=$(gcloud run revisions list --service bookshelf-api --region asia-south1 --format='value(name)' --limit 2 | tail -n1)
gcloud run services update-traffic bookshelf-api --region asia-south1 --to-revisions $NEW=50,$OLD=50
for i in $(seq 6); do curl -s $URL/ | grep -o '"version":"v[12]"'; done
gcloud run services update-traffic bookshelf-api --region asia-south1 --to-revisions $OLD=100; curl -s $URL/; echo
gcloud run services update-traffic bookshelf-api --region asia-south1 --to-latest
gcloud run services logs read bookshelf-api --region asia-south1 --limit 20
gcloud run services logs read bookshelf-api --region asia-south1 --log-filter='textPayload:SIGTERM' --limit 5
gcloud run revisions list --service bookshelf-api --region asia-south1
gcloud run revisions describe $NEW --region asia-south1 --format='yaml(spec.containers[0].env,spec.timeoutSeconds)'

# (Lab 3) teardown
bash ../teardown.sh

# ==== LAB 4 — two services talking: web calls api with its identity
PROJECT=$(gcloud config get-value project); R=asia-south1
AR=asia-south1-docker.pkg.dev/$PROJECT/bookshelf
# 1 build the web image
(cd ../bookshelf-web && gcloud builds submit --tag $AR/bookshelf-web:1.0)
# 2 one identity per service, no roles
gcloud iam service-accounts create bookshelf-api-sa --display-name="bookshelf-api runtime"
gcloud iam service-accounts create bookshelf-web-sa --display-name="bookshelf-web runtime"
# 3 the api now requires authentication and runs as its own identity (new revision)
gcloud run services update bookshelf-api --region $R --service-account bookshelf-api-sa@$PROJECT.iam.gserviceaccount.com --no-allow-unauthenticated
API_URL=$(gcloud run services describe bookshelf-api --region $R --format='value(status.url)')
curl -s -o /dev/null -w "anonymous: HTTP %{http_code}\n" $API_URL/          # 403
# 4 only web's identity may invoke the api
gcloud run services add-iam-policy-binding bookshelf-api --region $R \
  --member=serviceAccount:bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --role=roles/run.invoker
# 5 deploy web, public, pointing at the api
gcloud run deploy bookshelf-web --image $AR/bookshelf-web:1.0 --region $R \
  --service-account bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com \
  --set-env-vars API_URL=$API_URL --allow-unauthenticated
WEB_URL=$(gcloud run services describe bookshelf-web --region $R --format='value(status.url)')
echo "open: $WEB_URL"; curl -s $WEB_URL/ | grep -o "<li>.*</li>" | head -4
# 6 prove the binding matters: remove it, reload, put it back
gcloud run services remove-iam-policy-binding bookshelf-api --region $R \
  --member=serviceAccount:bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --role=roles/run.invoker
sleep 20; curl -s $WEB_URL/ | grep -o "could not reach[^<]*"
gcloud run services add-iam-policy-binding bookshelf-api --region $R \
  --member=serviceAccount:bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --role=roles/run.invoker
# teardown (Lab 4 additions) — then bash ../teardown.sh
gcloud run services delete bookshelf-web --region $R --quiet
gcloud iam service-accounts delete bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --quiet
gcloud iam service-accounts delete bookshelf-api-sa@$PROJECT.iam.gserviceaccount.com --quiet
