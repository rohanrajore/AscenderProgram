#!/bin/bash
# Cloud Run session teardown — both services, both service accounts, the repository, local images. Safe to re-run.
PROJECT=$(gcloud config get-value project)
gcloud run services delete bookshelf-web --region asia-south1 --quiet 2>/dev/null || true
gcloud run services delete bookshelf-api --region asia-south1 --quiet || true
gcloud iam service-accounts delete bookshelf-web-sa@$PROJECT.iam.gserviceaccount.com --quiet 2>/dev/null || true
gcloud iam service-accounts delete bookshelf-api-sa@$PROJECT.iam.gserviceaccount.com --quiet 2>/dev/null || true
gcloud artifacts repositories delete bookshelf --location=asia-south1 --quiet || true
docker rm -f $(docker ps -aq) 2>/dev/null; docker image prune -af >/dev/null
gcloud run services list --region asia-south1; gcloud artifacts repositories list --location=asia-south1; docker images
echo "Cloud Run session resources removed."
