"""bookshelf-api 1.2 — the catalogue service, pipeline edition.
New in 1.2: FAULT_RATE (0.0–1.0, default 0) makes GET /books fail with HTTP 500 at that rate —
used ONLY to show a canary catching a bad release in the CI/CD session.
Supplied complete: nothing here is edited in the lab. New in 1.1: GET /config reports whether a secret
reached the container as a file (/secrets/db-password) or as an env var (DB_PASSWORD) — as a length and
a SHA-256 prefix only. The value itself is never returned or logged. Read it to see what the
container contract needs from an app: PORT, /healthz, clean shutdown, logs to stdout.
"""
import hashlib
import logging
import os
import random
import socket
import time

from flask import Flask, jsonify, request

logging.basicConfig(level=logging.INFO, format="%(message)s")  # Cloud Run collects stdout/stderr
log = logging.getLogger("bookshelf-api")
app = Flask(__name__)

BOOKS = [
    {"id": 1, "title": "The Pragmatic Programmer", "author": "Hunt & Thomas", "year": 1999},
    {"id": 2, "title": "Designing Data-Intensive Applications", "author": "Kleppmann", "year": 2017},
    {"id": 3, "title": "Site Reliability Engineering", "author": "Beyer et al.", "year": 2016},
    {"id": 4, "title": "Release It!", "author": "Nygard", "year": 2018},
]
VERSION = os.environ.get("APP_VERSION", "v1")          # runtime configuration, never baked into the image
GREETING = os.environ.get("GREETING", "Bookshelf catalogue")
FAULT_RATE = float(os.environ.get("FAULT_RATE", "0"))       # release-time fault injection for the canary lab
STARTED = time.time()
INSTANCE = socket.gethostname()                        # differs per container instance


@app.get("/")
def index():
    return jsonify({"service": "bookshelf-api", "version": VERSION, "greeting": GREETING, "books": len(BOOKS)})


@app.get("/books")
def list_books():
    if FAULT_RATE and random.random() < FAULT_RATE:
        log.error("simulated fault (FAULT_RATE=%s)", FAULT_RATE)
        return jsonify({"error": "simulated fault"}), 500
    return jsonify(BOOKS)


@app.get("/books/<int:book_id>")
def get_book(book_id: int):
    for book in BOOKS:
        if book["id"] == book_id:
            return jsonify(book)
    return jsonify({"error": f"book {book_id} not found"}), 404


@app.get("/healthz")
def healthz():
    # the health contract: cheap, no dependencies, 200 means "send me traffic"
    return jsonify({"status": "ok", "uptime_s": round(time.time() - STARTED, 1)})


@app.get("/whoami")
def whoami():
    # which instance answered, and how long it has been alive — makes scaling and cold starts visible
    return jsonify({"instance": INSTANCE, "uptime_s": round(time.time() - STARTED, 1), "version": VERSION})


@app.get("/config")
def config():
    """Fingerprints of the secret as the container sees it — never the value."""
    def fp(value):
        if value is None:
            return {"present": False}
        return {"present": True, "length": len(value), "sha256_8": hashlib.sha256(value.encode()).hexdigest()[:8]}
    file_value = None
    try:
        with open("/secrets/db-password") as f:            # mounted volume: fetched on every read
            file_value = f.read()
    except OSError:
        pass
    return jsonify({
        "instance": INSTANCE,
        "secret_file": fp(file_value),                       # follows a rotation without a redeploy
        "secret_env": fp(os.environ.get("DB_PASSWORD")),     # fixed for the life of this instance
        "config_env": {"APP_VERSION": VERSION, "GREETING": GREETING},
    })


@app.get("/slow")
def slow():
    # simulates long-running work: /slow?seconds=45 — used to demonstrate request timeouts
    seconds = min(int(request.args.get("seconds", 5)), 600)
    log.info("slow request started: %s s", seconds)
    time.sleep(seconds)
    return jsonify({"slept_s": seconds, "instance": INSTANCE})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
