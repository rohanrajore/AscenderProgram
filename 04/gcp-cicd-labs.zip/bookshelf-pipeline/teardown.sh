#!/bin/bash
# END OF PROGRAMME ONLY — removes the CI/CD session's additions (pipeline, staging service, images) — not Session C's state.
PROJECT=$(gcloud config get-value project); R=asia-south1
gcloud deploy delivery-pipelines delete bookshelf-api --region=$R --force --quiet 2>/dev/null || true
gcloud run services delete bookshelf-api-staging --region $R --quiet 2>/dev/null || true
gcloud projects remove-iam-policy-binding $PROJECT --member=serviceAccount:bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --role=roles/clouddeploy.jobRunner --quiet 2>/dev/null || true
echo "CI/CD session resources removed (bookshelf-api itself is left as Session C set it)."
