"""Unit tests for bookshelf-web — the page renders and reports an api failure honestly."""
import importlib.util
from pathlib import Path


def load(service: str, name: str):
    """Import a service's app.py under a unique module name (both services call the file app.py)."""
    path = Path(__file__).resolve().parents[2] / "services" / service / "app.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


web = load("bookshelf-web", "bookshelf_web")


def test_page_reports_unreachable_api_instead_of_crashing():
    web.API_URL = "http://localhost:1"          # nothing listens here
    html = web.app.test_client().get("/").get_data(as_text=True)
    assert "could not reach bookshelf-api" in html


def test_healthz_ok():
    assert web.app.test_client().get("/healthz").status_code == 200
