"""Unit tests for bookshelf-api — fast, no network, no container. Run: pytest tests/unit"""
import importlib.util
from pathlib import Path


def load(service: str, name: str):
    """Import a service's app.py under a unique module name (both services call the file app.py)."""
    path = Path(__file__).resolve().parents[2] / "services" / service / "app.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


api = load("bookshelf-api", "bookshelf_api")


def client():
    api.app.config["TESTING"] = True
    return api.app.test_client()


def test_index_reports_service_and_book_count():
    body = client().get("/").get_json()
    assert body["service"] == "bookshelf-api"
    assert body["books"] == 4


def test_books_returns_all_four_with_required_fields():
    books = client().get("/books").get_json()
    assert len(books) == 4
    for book in books:
        assert {"id", "title", "author", "year"} <= set(book)


def test_unknown_book_is_404():
    assert client().get("/books/999").status_code == 404


def test_healthz_is_cheap_and_ok():
    r = client().get("/healthz")
    assert r.status_code == 200


def test_config_never_returns_a_secret_value(monkeypatch):
    monkeypatch.setenv("DB_PASSWORD", "hunter2-do-not-leak")     # read at request time, no reload needed
    body = client().get("/config").get_json()
    assert "hunter2" not in str(body)
    assert body["secret_env"]["length"] == len("hunter2-do-not-leak")
