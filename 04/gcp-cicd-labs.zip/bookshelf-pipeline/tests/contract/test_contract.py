"""Contract test — does the api still produce the shape the web page consumes?
The web page reads `version` from GET / and `title`, `author`, `year` from each item of GET /books.
If the api renames a field, THIS test fails before anything is deployed."""
import importlib.util
from pathlib import Path


def load(service: str, name: str):
    """Import a service's app.py under a unique module name (both services call the file app.py)."""
    path = Path(__file__).resolve().parents[2] / "services" / service / "app.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


api = load("bookshelf-api", "bookshelf_api_contract")

WEB_EXPECTS_ON_ROOT = {"version"}
WEB_EXPECTS_ON_BOOK = {"title", "author", "year"}


def test_root_has_the_fields_the_web_page_reads():
    body = api.app.test_client().get("/").get_json()
    assert WEB_EXPECTS_ON_ROOT <= set(body), f"missing {WEB_EXPECTS_ON_ROOT - set(body)}"


def test_each_book_has_the_fields_the_web_page_reads():
    for book in api.app.test_client().get("/books").get_json():
        assert WEB_EXPECTS_ON_BOOK <= set(book), f"missing {WEB_EXPECTS_ON_BOOK - set(book)}"
