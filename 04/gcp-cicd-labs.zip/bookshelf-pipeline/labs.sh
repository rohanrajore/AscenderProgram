#!/bin/bash
# CI/CD — Tests, Artifact Promotion and Safe Releases — command sheet for Labs 1–4.
# Same steps as the lab manual. Run BLOCK BY BLOCK from the kit root (this folder), never end to end.
PROJECT=$(gcloud config get-value project)
PN=$(gcloud projects describe $PROJECT --format='value(projectNumber)')
R=asia-south1
AR=$R-docker.pkg.dev/$PROJECT/bookshelf
echo "project=$PROJECT region=$R registry=$AR"

# =====================================================================
# LAB 1 — the gates, in order, and what happens when one fails
# =====================================================================
# 1 — APIs, and a git history so every build has a commit to be named after
gcloud services enable cloudbuild.googleapis.com artifactregistry.googleapis.com containerscanning.googleapis.com \
  ondemandscanning.googleapis.com clouddeploy.googleapis.com run.googleapis.com
git init -q -b main && git add -A && git -c user.name=grad -c user.email=grad@example.com commit -q -m "bookshelf pipeline kit"
git log --oneline | head -1

# 2 — read the pipeline: twelve steps, each a gate
grep -E "^- id:" cloudbuild.yaml

# 3 — run it. Every step passes; an image tagged with the commit is pushed and scanned.
SHA=$(git rev-parse --short HEAD); GOOD_SHA=$SHA
gcloud builds submit --config cloudbuild.yaml --substitutions=_SHA=$SHA .
# expect (tail): Step #11 - "digest": sha256:…   STATUS: SUCCESS   ~4–6 min

# 4 — break a unit test on purpose (an expected value), commit, run again: it stops at unit-tests
sed -i 's/assert body\["books"\] == 4/assert body["books"] == 5/' tests/unit/test_api.py
git commit -qam "break: wrong expected book count"
SHA=$(git rev-parse --short HEAD)
gcloud builds submit --config cloudbuild.yaml --substitutions=_SHA=$SHA . ; echo "exit=$?"
# expect: Step #3 - "unit-tests": FAILED tests/unit/test_api.py::test_index_reports_service_and_book_count — assert 4 == 5
#         no build step ran, no image for this SHA exists:
gcloud artifacts docker images list $AR --include-tags --filter="tags:$SHA" --format='value(tags)'   # empty

# 5 — fix it (revert), and prove the order matters: read step timings from the two builds
git revert -q --no-edit HEAD
gcloud builds list --limit 2 --format='table(id,status,duration,substitutions._SHA)'
BUILD=$(gcloud builds list --limit 1 --format='value(id)')
gcloud builds describe $BUILD --format='table(steps.id,steps.status,steps.timing.startTime.date("%H:%M:%S"),steps.timing.endTime.date("%H:%M:%S"))'
# lint fails in seconds; a failing vulnerability scan would fail after the 3-minute build — fastest gates first is a real saving

# 6 — the contract test: rename a field the web page reads, and watch the contract gate catch it
sed -i 's/"title": "The Pragmatic Programmer"/"name": "The Pragmatic Programmer"/' services/bookshelf-api/app.py
pip install --user -q -r requirements-dev.txt -r services/bookshelf-api/requirements.txt -r services/bookshelf-web/requirements.txt
python3 -m pytest -q tests/contract 2>&1 | tail -3
# expect: FAILED tests/contract/test_contract.py::test_each_book_has_the_fields_the_web_page_reads — missing {'title'}
git checkout -- services/bookshelf-api/app.py     # undo; nothing was committed

# =====================================================================
# LAB 2 — build once: digest, immutable tag, scan, and "latest" refused
# =====================================================================
# 1 — the image the good build pushed: SHA tag and digest are two names for one immutable thing
SHA=${GOOD_SHA:-$(git rev-parse --short HEAD~2)}     # the first (passing) commit
gcloud artifacts docker images list $AR --include-tags --format='table(package,tags,version,createTime)'
DIGEST=$(gcloud artifacts docker images describe $AR/bookshelf-api:$SHA --format='value(image_summary.digest)')
echo "bookshelf-api@$DIGEST"

# 2 — the vulnerability scan the pipeline ran, read again by hand
SCAN=$(gcloud artifacts docker images scan $AR/bookshelf-api:$SHA --remote --format='value(response.scan)')
gcloud artifacts docker images list-vulnerabilities $SCAN --format='value(vulnerability.effectiveSeverity)' | sort | uniq -c
# expect: a handful of LOW/MEDIUM in the Debian base, zero CRITICAL — the gate in cloudbuild.yaml is CRITICAL

# 3 — lower the gate to HIGH and re-run only the scan step logic: does the same image pass?
N=$(gcloud artifacts docker images list-vulnerabilities $SCAN --format='value(vulnerability.effectiveSeverity)' | grep -c '^HIGH$' || true); echo "HIGH findings: $N"
# if N > 0: the gate at HIGH would have failed this build — the decision is a policy, not a fact

# 4 — "latest" is a defect: tag it, then see why the pipeline never uses it
gcloud artifacts docker tags add $AR/bookshelf-api:$SHA $AR/bookshelf-api:latest
gcloud artifacts docker images list $AR --include-tags --format='value(tags,version)'
# 'latest' points at this digest today; after the next push it silently points elsewhere. A rollout that says
# 'latest' cannot be rolled back to — there is nothing to name. Cloud Deploy (Lab 3) accepts only a digest.
gcloud artifacts docker tags delete $AR/bookshelf-api:latest --quiet

# 5 — provenance: who built this image and from what (Cloud Build attaches it automatically)
gcloud artifacts docker images describe $AR/bookshelf-api:$SHA --show-provenance --format='yaml(provenance_summary.provenance[0].build.intotoStatement.predicate.buildDefinition.externalParameters)' 2>/dev/null | head -20 || echo "(provenance appears for builds from Cloud Build with a SLSA level; not all builds show it)"

# =====================================================================
# LAB 3 — promotion: staging automatically, prod behind an approval, same digest in both
# =====================================================================
# 1 — the pipeline identity from Session C gets the Cloud Deploy job-runner role; fill the project id into the manifests
gcloud projects add-iam-policy-binding $PROJECT --member=serviceAccount:bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --role=roles/clouddeploy.jobRunner
gcloud projects add-iam-policy-binding $PROJECT --member=serviceAccount:bookshelf-deployer@$PROJECT.iam.gserviceaccount.com --role=roles/run.developer
sed -i "s/PROJECT_ID/$PROJECT/g" deploy/clouddeploy.yaml deploy/run-service-staging.yaml deploy/run-service-prod.yaml
grep -n "PROJECT_ID\|$PROJECT" deploy/clouddeploy.yaml | head -4

# 2 — register the pipeline and two targets
gcloud deploy apply --file=deploy/clouddeploy.yaml --region=$R
gcloud deploy delivery-pipelines describe bookshelf-api --region=$R --format='value(Targets)'
# console: Cloud Deploy → Delivery pipelines → bookshelf-api

# 3 — a release: the digest from Lab 2, substituted into both manifests. Staging deploys automatically.
gcloud deploy releases create r-$SHA --delivery-pipeline=bookshelf-api --region=$R \
  --source=deploy --images=bookshelf-api=$AR/bookshelf-api@$DIGEST
sleep 90; gcloud deploy rollouts list --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --format='table(name.basename(),targetId,state,approvalState)'
# expect: r-…-to-staging-0001  staging  SUCCEEDED
STG_URL=$(gcloud run services describe bookshelf-api-staging --region $R --format='value(status.url)')
curl -s -H "Authorization: Bearer $(gcloud auth print-identity-token)" $STG_URL/ ; echo                 # "version":"staging"

# 4 — promote to prod: the rollout waits for approval
gcloud deploy releases promote --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --quiet
sleep 15; gcloud deploy rollouts list --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --format='table(name.basename(),targetId,state,approvalState)'
# expect: r-…-to-prod-0001  prod  PENDING_APPROVAL  NEEDS_APPROVAL
ROLLOUT=$(gcloud deploy rollouts list --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --filter='targetId=prod' --format='value(name.basename())')
gcloud deploy rollouts approve $ROLLOUT --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --quiet
# console: Cloud Deploy → bookshelf-api → the prod rollout → Review → Approve

# 5 — the prod stage is a canary: 20 % first. Advance it to 100 %.
sleep 90; gcloud deploy rollouts describe $ROLLOUT --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --format='yaml(state,phases[].id,phases[].state)'
# expect: phases canary-20 SUCCEEDED, stable PENDING
gcloud deploy rollouts advance $ROLLOUT --release=r-$SHA --delivery-pipeline=bookshelf-api --region=$R --quiet
sleep 60; gcloud run services describe bookshelf-api --region $R --format='value(status.traffic)'

# 6 — the proof: staging and prod run the identical digest; prod kept Session C's identity, secret and ingress
for S in bookshelf-api-staging bookshelf-api; do
  echo "== $S"; gcloud run services describe $S --region $R --format='value(spec.template.spec.containers[0].image,spec.template.spec.serviceAccountName,metadata.annotations."run.googleapis.com/ingress")'
done

# =====================================================================
# LAB 4 — a bad release caught at 20 %, rolled back through the pipeline
# =====================================================================
WEB_URL=$(gcloud run services describe bookshelf-web --region $R --format='value(status.url)')
# 1 — baseline: 20 page loads, zero failures
for i in $(seq 1 20); do curl -s "$WEB_URL/" | grep -c "could not reach"; done | sort | uniq -c

# 2 — the "bad" release: same image, a config change that makes half the /books calls fail (FAULT_RATE)
python3 - <<'EOF'
import re
p='deploy/run-service-prod.yaml'; s=open(p).read()
s=s.replace('        - name: APP_VERSION\n          value: prod\n','        - name: APP_VERSION\n          value: prod\n        - name: FAULT_RATE\n          value: "0.5"\n',1)
open(p,'w').write(s)
EOF
git commit -qam "release: enable FAULT_RATE (deliberately bad)"
gcloud deploy releases create r-bad --delivery-pipeline=bookshelf-api --region=$R --source=deploy --images=bookshelf-api=$AR/bookshelf-api@$DIGEST
sleep 90; gcloud deploy releases promote --release=r-bad --delivery-pipeline=bookshelf-api --region=$R --quiet
sleep 15; BAD=$(gcloud deploy rollouts list --release=r-bad --delivery-pipeline=bookshelf-api --region=$R --filter='targetId=prod' --format='value(name.basename())')
gcloud deploy rollouts approve $BAD --release=r-bad --delivery-pipeline=bookshelf-api --region=$R --quiet
sleep 90; gcloud run services describe bookshelf-api --region $R --format='value(status.traffic)'          # 80 / 20

# 3 — watch the canary from the outside: roughly 1 load in 10 fails (20 % of traffic × 50 % fault rate)
for i in $(seq 1 30); do curl -s "$WEB_URL/" | grep -c "could not reach"; done | sort | uniq -c
gcloud run services logs read bookshelf-api --region $R --limit 20 | grep -c "simulated fault"

# 4 — do NOT advance. Roll back through the pipeline: the previous release is re-deployed to prod.
gcloud deploy targets rollback prod --delivery-pipeline=bookshelf-api --region=$R --quiet
sleep 90; gcloud deploy rollouts list --delivery-pipeline=bookshelf-api --region=$R --filter='targetId=prod' --format='table(name.basename(),state,phases[0].id)' | head -5
gcloud run services describe bookshelf-api --region $R --format='value(status.traffic)'                    # 100 % on the good revision
# (if the rollback rollout pauses at a canary phase, advance it: gcloud deploy rollouts advance <rollout> --release=<r-…> …)
for i in $(seq 1 20); do curl -s "$WEB_URL/" | grep -c "could not reach"; done | sort | uniq -c            # zero again

# 5 — fix forward: remove the fault, release r-fixed, promote, approve, advance — the normal path
sed -i '/FAULT_RATE/,+1d' deploy/run-service-prod.yaml && grep -c FAULT_RATE deploy/run-service-prod.yaml
git commit -qam "release: remove FAULT_RATE"
gcloud deploy releases create r-fixed --delivery-pipeline=bookshelf-api --region=$R --source=deploy --images=bookshelf-api=$AR/bookshelf-api@$DIGEST
# then: promote → approve → (canary 20 %) → advance, exactly as in Lab 3 steps 4–5

# Leave everything running: the Observability and Incident sessions use this pipeline. teardown.sh is for the end of the programme.
echo "Lab 4 complete."
