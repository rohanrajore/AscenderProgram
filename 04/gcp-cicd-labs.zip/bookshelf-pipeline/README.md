# bookshelf pipeline — CI/CD session kit (supplied complete; nothing is coded)
- cloudbuild.yaml            the pipeline: tooling → lint → typecheck → unit → contract → dependency scan → build → integration → push → vulnerability gate → digest
- services/bookshelf-api/    version 1.2 (adds FAULT_RATE for the canary lab) · services/bookshelf-web/
- tests/unit, tests/contract pytest suites the pipeline runs
- requirements-dev.txt, pyproject.toml   pinned tools: pytest, ruff, mypy, pip-audit
- deploy/                    Cloud Deploy: clouddeploy.yaml (pipeline + staging/prod targets, canary 20 %), skaffold.yaml, run-service-*.yaml
- labs.sh                    Labs 1–4 as one command sheet — run block by block from THIS folder
- teardown.sh                END OF PROGRAMME only
Upload to Cloud Shell (⋮ → Upload), then: unzip -q gcp-cicd-labs.zip && cd bookshelf-pipeline
Prerequisite: the state Session C (IAM & Secrets) left: bookshelf-api on bookshelf-api-min, secret db-password v2, bookshelf-deployer, bookshelf-web deployed.
