#!/usr/bin/env bash
# 01-create-datastore.sh — Part B. Create the data store (layout parser, chunk mode,
# 250-token chunks with ancestor headings) and wait until it answers a search.
#
# The curl is printed before it runs.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
[[ -f "$KIT/lab.env" ]] || { echo "lab.env not found. Run: cp $KIT/lab.env.example $KIT/lab.env, then fill it in." >&2; exit 1; }
# shellcheck source=../lab.env.example
source "$KIT/lab.env"
[[ -n "${PROJECT_ID:-}" ]] || { echo "PROJECT_ID is empty in lab.env. Set it and rerun." >&2; exit 1; }
: "${LOCATION:=global}"
: "${DATASTORE_ID:?DATASTORE_ID is empty in lab.env}"
: "${APP_ID:?APP_ID is empty in lab.env}"
command -v jq >/dev/null || { echo "jq is required (it is preinstalled in Cloud Shell)." >&2; exit 1; }

API="https://discoveryengine.googleapis.com/v1"
PARENT="projects/$PROJECT_ID/locations/$LOCATION/collections/default_collection"
RESP="$(mktemp)"; trap 'rm -f "$RESP"' EXIT
HTTP_CODE=""

# call METHOD URL [BODY_FILE]: prints the exact curl, runs it, leaves the body in $RESP
# and the status in $HTTP_CODE. Set QUIET=1 to skip the printing (used while polling).
call() {
  local method="$1" url="$2" body="${3:-}"
  if [[ -z "${QUIET:-}" ]]; then
    {
      echo "+ curl -sS -X $method \"$url\" \\"
      echo "    -H \"Authorization: Bearer \$(gcloud auth print-access-token)\" \\"
      echo "    -H \"X-Goog-User-Project: $PROJECT_ID\" \\"
      echo "    -H \"Content-Type: application/json\"${body:+ -d @$body}"
      if [[ -n "$body" ]]; then echo "  body:"; sed 's/^/    /' "$body"; fi
    } >&2
  fi
  local token; token="$(gcloud auth print-access-token)"
  HTTP_CODE="$(curl -sS -o "$RESP" -w '%{http_code}' -X "$method" "$url" \
    -H "Authorization: Bearer $token" \
    -H "X-Goog-User-Project: $PROJECT_ID" \
    -H "Content-Type: application/json" ${body:+-d @"$body"})"
}

# must_ok: exit with the response body shown unless the last call returned 2xx.
must_ok() { [[ "$HTTP_CODE" == 2* ]] || { echo "HTTP $HTTP_CODE:" >&2; cat "$RESP" >&2; echo >&2; exit 1; }; }

# poll_operation NAME: GET the long-running operation every 20 s until done, printing elapsed time.
poll_operation() {
  local name="$1" start=$SECONDS
  echo "polling every 20 s with:  curl -sS \"$API/$name\" -H \"Authorization: Bearer \$(gcloud auth print-access-token)\"" >&2
  while :; do
    QUIET=1 call GET "$API/$name"; must_ok
    if [[ "$(jq -r '.done // false' "$RESP")" == "true" ]]; then
      echo >&2; echo "operation done after $((SECONDS - start)) s" >&2
      if jq -e '.error' "$RESP" >/dev/null; then echo "operation FAILED:" >&2; jq '.error' "$RESP" >&2; exit 1; fi
      return 0
    fi
    printf '\r  waiting... %4d s elapsed' $((SECONDS - start)) >&2
    sleep 20
  done
}

echo "== create data store $DATASTORE_ID (body: datastore.json)"
call POST "$API/$PARENT/dataStores?dataStoreId=$DATASTORE_ID" "$KIT/datastore.json"
if [[ "$HTTP_CODE" == 409 ]]; then
  echo "data store $DATASTORE_ID already exists — continuing to the readiness check" >&2
else
  must_ok
  echo "response:"; jq . "$RESP"
  echo "operation: $(jq -r '.name // "(none)"' "$RESP")"
fi

# The create call returns a long-running operation, but the notebook's way to know the
# store is usable is simpler: search it until the API stops saying 404/400.
echo "== wait until the data store answers a search (chunk mode needs no documents yet)"
BODY="$(mktemp)"; trap 'rm -f "$RESP" "$BODY"' EXIT
echo '{"query": "dispute", "pageSize": 1}' > "$BODY"
call POST "$API/$PARENT/dataStores/$DATASTORE_ID/servingConfigs/default_search:search" "$BODY"
start=$SECONDS
while [[ "$HTTP_CODE" != 200 ]]; do
  if [[ "$HTTP_CODE" == 401 || "$HTTP_CODE" == 403 ]]; then echo; echo "HTTP $HTTP_CODE — not a readiness problem:" >&2; cat "$RESP" >&2; exit 1; fi
  printf '\r  HTTP %s, waiting... %4d s elapsed' "$HTTP_CODE" $((SECONDS - start)) >&2
  sleep 15
  QUIET=1 call POST "$API/$PARENT/dataStores/$DATASTORE_ID/servingConfigs/default_search:search" "$BODY"
done
echo >&2
echo "data store answers a search after $((SECONDS - start)) s (HTTP 200, $(jq -r '.totalSize // 0' "$RESP") results — 0 is expected before the import)"
echo "Next: scripts/02-patch-schema.sh"
