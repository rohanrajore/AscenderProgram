#!/usr/bin/env bash
# answer.sh — Part D-3 and E. Grounded answer from the app, with the caller's filter.
#
#   usage: scripts/answer.sh --user priya|daniel|mlro "question"
#          scripts/answer.sh --no-filter "question"          (Part D-1 comparison)
#          scripts/answer.sh --filter 'status: ANY("approved")' "question"
#
# Prints the curl, then: the answer text, one line per citation
# "[n] title — first 100 chars of the cited chunk", grounding: <score>, skipped: <reasons>.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
[[ -f "$KIT/lab.env" ]] || { echo "lab.env not found. Run: cp $KIT/lab.env.example $KIT/lab.env, then fill it in." >&2; exit 1; }
# shellcheck source=../lab.env.example
source "$KIT/lab.env"
[[ -n "${PROJECT_ID:-}" ]] || { echo "PROJECT_ID is empty in lab.env. Set it and rerun." >&2; exit 1; }
: "${LOCATION:=global}"
: "${DATASTORE_ID:?DATASTORE_ID is empty in lab.env}"
: "${APP_ID:?APP_ID is empty in lab.env}"
command -v jq >/dev/null || { echo "jq is required (it is preinstalled in Cloud Shell)." >&2; exit 1; }

API="https://discoveryengine.googleapis.com/v1"
PARENT="projects/$PROJECT_ID/locations/$LOCATION/collections/default_collection"
RESP="$(mktemp)"; trap 'rm -f "$RESP"' EXIT
HTTP_CODE=""

# call METHOD URL [BODY_FILE]: prints the exact curl, runs it, leaves the body in $RESP
# and the status in $HTTP_CODE. Set QUIET=1 to skip the printing (used while polling).
call() {
  local method="$1" url="$2" body="${3:-}"
  if [[ -z "${QUIET:-}" ]]; then
    {
      echo "+ curl -sS -X $method \"$url\" \\"
      echo "    -H \"Authorization: Bearer \$(gcloud auth print-access-token)\" \\"
      echo "    -H \"X-Goog-User-Project: $PROJECT_ID\" \\"
      echo "    -H \"Content-Type: application/json\"${body:+ -d @$body}"
      if [[ -n "$body" ]]; then echo "  body:"; sed 's/^/    /' "$body"; fi
    } >&2
  fi
  local token; token="$(gcloud auth print-access-token)"
  HTTP_CODE="$(curl -sS -o "$RESP" -w '%{http_code}' -X "$method" "$url" \
    -H "Authorization: Bearer $token" \
    -H "X-Goog-User-Project: $PROJECT_ID" \
    -H "Content-Type: application/json" ${body:+-d @"$body"})"
}

# must_ok: exit with the response body shown unless the last call returned 2xx.
must_ok() { [[ "$HTTP_CODE" == 2* ]] || { echo "HTTP $HTTP_CODE:" >&2; cat "$RESP" >&2; echo >&2; exit 1; }; }

# poll_operation NAME: GET the long-running operation every 20 s until done, printing elapsed time.
poll_operation() {
  local name="$1" start=$SECONDS
  echo "polling every 20 s with:  curl -sS \"$API/$name\" -H \"Authorization: Bearer \$(gcloud auth print-access-token)\"" >&2
  while :; do
    QUIET=1 call GET "$API/$name"; must_ok
    if [[ "$(jq -r '.done // false' "$RESP")" == "true" ]]; then
      echo >&2; echo "operation done after $((SECONDS - start)) s" >&2
      if jq -e '.error' "$RESP" >/dev/null; then echo "operation FAILED:" >&2; jq '.error' "$RESP" >&2; exit 1; fi
      return 0
    fi
    printf '\r  waiting... %4d s elapsed' $((SECONDS - start)) >&2
    sleep 20
  done
}
# The documented stable model string has this form; if the API rejects it, set ANSWER_MODEL=stable in lab.env.
: "${ANSWER_MODEL:=stable}"

# The Bookshelf system rule. evaluate.py sends the same text; keep the two identical.
PREAMBLE='You are the Meridian Bookshelf assistant for bank staff. Answer only from the documents provided to you and cite the passage for every fact you state. Quote the exact rule, figure or time limit. If the documents do not answer the question, reply with exactly: "The approved documents I can see do not answer this." Never use outside knowledge and never guess.'

USER=""; FILTER=""; MODE=""; QUESTION=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --user)      USER="$2"; MODE="user"; shift 2 ;;
    --filter)    FILTER="$2"; MODE="filter"; shift 2 ;;
    --no-filter) MODE="none"; shift ;;
    -h|--help)   sed -n '2,12p' "$0"; exit 0 ;;
    *)           QUESTION="$1"; shift ;;
  esac
done
[[ -n "$QUESTION" && -n "$MODE" ]] || { echo "usage: $0 --user NAME | --filter 'F' | --no-filter  \"question\"" >&2; exit 1; }

if [[ "$MODE" == "user" ]]; then
  FILTER="$(jq -r --arg u "$USER" '.[$u].filter // empty' "$KIT/callers.json")"
  [[ -n "$FILTER" ]] || { echo "unknown caller '$USER' — see callers.json" >&2; exit 1; }
  echo "caller:   $USER ($(jq -r --arg u "$USER" '.[$u].clearance' "$KIT/callers.json"))"
fi
echo "question: $QUESTION"
echo "filter:   ${FILTER:-(none)}"

BODY="$(mktemp)"; trap 'rm -f "$RESP" "$BODY"' EXIT
jq -n --arg q "$QUESTION" --arg f "$FILTER" --arg model "$ANSWER_MODEL" --arg preamble "$PREAMBLE" '
  {
    query: {text: $q},
    answerGenerationSpec: {
      modelSpec: {modelVersion: $model},
      promptSpec: {preamble: $preamble},
      includeCitations: true,
      ignoreLowRelevantContent: true,
      ignoreNonAnswerSeekingQuery: false
    },
    searchSpec: {
      searchParams: ({maxReturnResults: 5} + (if $f != "" then {filter: $f} else {} end))
    }
  }' > "$BODY"

# The answer endpoint is engine (app) level, not data-store level.
call POST "$API/$PARENT/engines/$APP_ID/servingConfigs/default_search:answer" "$BODY"
must_ok

echo
echo "answer:"
jq -r '.answer.answerText // "" | if . == "" then "(no answer text)" else . end' "$RESP"
echo
echo "citations:"
jq -r '
  .answer as $a |
  ([$a.citations[]?.sources[]?.referenceId] | unique) as $ids |
  if ($ids | length) == 0 then "  (none)" else
    $ids[] | . as $id |
    ($a.references[($id | tonumber)]? // {}) as $ref |
    "  [\(($id | tonumber) + 1)] \($ref.chunkInfo.documentMetadata.title // "?") — \(($ref.chunkInfo.content // "") | gsub("\\s+"; " ") | .[0:100])"
  end' "$RESP"
echo "grounding: $(jq -r '.answer.groundingScore // "(not returned)"' "$RESP")"
echo "skipped: $(jq -r '.answer.answerSkippedReasons // [] | if length == 0 then "none" else join(", ") end' "$RESP")"
[[ -n "${RAW:-}" ]] && jq . "$RESP"
exit 0
