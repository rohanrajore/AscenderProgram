#!/usr/bin/env python3
"""evaluate.py — Part F. Run the 40 golden questions through the answer API, each with
its caller's filter, score them, and check the thresholds in eval.yaml.

    python scripts/evaluate.py                     the real run (needs gcloud auth + lab.env)
    python scripts/evaluate.py --no-status-filter  the weakened run: drop status: ANY("approved")
    python scripts/evaluate.py --from-fixtures     no API calls: read fixtures/eval-sample.jsonl
    python scripts/evaluate.py --skip-judge        real answers, but no Vertex AI evaluation call
    python scripts/evaluate.py --out report.json   also write every record and score to a file

What is computed locally, from the answer API response alone:
  correctness           answerable questions whose answer contains every key fact (case-insensitive)
  abstained             answerSkippedReasons non-empty, or the refusal sentence, or an empty answer
  recall_at_5 / mrr     document level: relevant docs come from golden relevant_chunk_ids
                        ("POL-CR-014#1" -> "POL-CR-014"), retrieved docs from references[].uri
  correct_abstain_rate  of the unanswerable questions, the share that abstained
  false_abstain_rate    of the answerable questions, the share that abstained
  false_answer_rate     of the unanswerable questions, the share that got an answer
  zero_citation_rate    of the answers given, the share with no citation
What comes from the Vertex AI evaluation service (EvalTask): groundedness and
question_answering_quality, judged from prompt / response / context / reference.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
ABSTAIN_TEXT = "The approved documents I can see do not answer this."
STATUS_CLAUSE = 'status: ANY("approved")'
# The Bookshelf system rule. answer.sh sends the same text; keep the two identical.
PREAMBLE = (
    "You are the Meridian Bookshelf assistant for bank staff. Answer only from the documents "
    "provided to you and cite the passage for every fact you state. Quote the exact rule, figure "
    "or time limit. If the documents do not answer the question, reply with exactly: "
    f"\"{ABSTAIN_TEXT}\" Never use outside knowledge and never guess."
)
GENAI_CLIENT_NOTE = (
    "vertexai.evaluation could not be imported. The contract notes that a newer 'GenAI client' "
    "evaluation path exists under the Agent Platform SDK (its code could not be fetched when this "
    "kit was built). Try:  pip install --upgrade 'google-cloud-aiplatform[evaluation]'  and, if the "
    "import is gone for good, port the EvalTask call in run_judge() to the GenAI client's evaluate "
    "method. Rerun with --skip-judge to get the local metrics meanwhile."
)


# ----------------------------------------------------------------------------- config
def load_env(path: Path) -> dict:
    """Read KEY=VALUE lines from lab.env, expanding ${VAR} against earlier keys."""
    env = {}
    if not path.exists():
        return env
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        v = v.strip().strip('"').strip("'")
        for name, val in env.items():
            v = v.replace("${" + name + "}", val).replace("$" + name, val)
        env[k.strip()] = v
    return env


def load_yaml(path: Path) -> dict:
    """eval.yaml with PyYAML if present, else a small parser for its one shape."""
    text = path.read_text()
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text)
    except ImportError:
        pass
    out: dict = {"thresholds": {}}
    for line in text.splitlines():
        line = line.split("#", 1)[0].rstrip()
        m = re.match(r"^\s{2}(\w+):\s*\{(min|max):\s*([0-9.]+)\}", line)
        if m:
            out["thresholds"][m.group(1)] = {m.group(2): float(m.group(3))}
            continue
        m = re.match(r"^(\w+):\s*(\S+)\s*$", line)
        if m and m.group(1) != "thresholds":
            v = m.group(2)
            out[m.group(1)] = int(v) if v.isdigit() else v
    return out


def caller_filter(callers: dict, caller: str, no_status: bool) -> str:
    f = callers[caller]["filter"]
    if no_status:
        f = f.replace(STATUS_CLAUSE + " AND ", "").replace(" AND " + STATUS_CLAUSE, "")
        f = f.replace(STATUS_CLAUSE, "").strip()
    return f


# ----------------------------------------------------------------------------- the API call
def access_token() -> str:
    return subprocess.check_output(["gcloud", "auth", "print-access-token"], text=True).strip()


def answer_request(question: str, filt: str, model: str) -> dict:
    """The same body answer.sh builds."""
    params: dict = {"maxReturnResults": 5}
    if filt:
        params["filter"] = filt
    return {
        "query": {"text": question},
        "answerGenerationSpec": {
            "modelSpec": {"modelVersion": model},
            "promptSpec": {"preamble": PREAMBLE},
            "includeCitations": True,
            "ignoreLowRelevantContent": True,
            "ignoreNonAnswerSeekingQuery": False,
        },
        "searchSpec": {"searchParams": params},
    }


def call_answer(env: dict, body: dict, token: str) -> dict:
    import requests  # in the venv 00-setup.sh makes

    url = (
        "https://discoveryengine.googleapis.com/v1/projects/{PROJECT_ID}/locations/{LOCATION}/"
        "collections/default_collection/engines/{APP_ID}/servingConfigs/default_search:answer"
    ).format(**env)
    headers = {
        "Authorization": f"Bearer {token}",
        "X-Goog-User-Project": env["PROJECT_ID"],
        "Content-Type": "application/json",
    }
    # The :answer endpoint has a per-project quota of 10 LLM requests per minute.
    # Pace the calls to stay under it, and if a 429 still arrives, wait out the
    # minute and try again rather than abandoning the run.
    for attempt in range(6):
        r = requests.post(url, headers=headers, json=body, timeout=120)
        if r.status_code == 429:
            wait = 65
            print(f"    quota: 10 answer requests per minute — waiting {wait}s before retrying", flush=True)
            time.sleep(wait)
            continue
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code} from :answer — {r.text[:800]}")
        time.sleep(6.5)  # 9 requests per minute, under the quota
        return r.json()
    raise RuntimeError("HTTP 429 from :answer six times in a row — the quota is not clearing")


# ----------------------------------------------------------------------------- parsing
def doc_id_from_uri(uri: str) -> str:
    return re.sub(r"\.html$", "", uri.rsplit("/", 1)[-1]) if uri else ""


def parse_answer(resp: dict) -> dict:
    """Flatten an :answer response into what the metrics need."""
    a = resp.get("answer") or {}
    refs = []
    for ref in a.get("references") or []:
        ci = ref.get("chunkInfo") or {}
        dm = ci.get("documentMetadata") or {}
        refs.append({
            "doc_id": doc_id_from_uri(dm.get("uri", "")),
            "title": dm.get("title", ""),
            "uri": dm.get("uri", ""),
            "content": ci.get("content", ""),
            "relevance_score": ci.get("relevanceScore"),
        })
    cited = []
    for c in a.get("citations") or []:
        for s in c.get("sources") or []:
            rid = s.get("referenceId")
            if rid is not None and rid not in cited:
                cited.append(rid)
    return {
        "answer_text": a.get("answerText") or "",
        "references": refs,
        "cited_reference_ids": cited,
        "skipped": list(a.get("answerSkippedReasons") or []),
        "grounding_score": a.get("groundingScore"),
    }


# ----------------------------------------------------------------------------- local metrics
def is_abstention(rec: dict) -> bool:
    text = rec["answer_text"].strip()
    return bool(rec["skipped"]) or text == "" or ABSTAIN_TEXT.lower() in text.lower()


def key_facts_present(text: str, facts: list[str]) -> bool:
    low = text.lower()
    return all(f.lower() in low for f in facts)


def relevant_docs(item: dict) -> list[str]:
    seen: list[str] = []
    for cid in item.get("relevant_chunk_ids") or []:
        d = cid.split("#", 1)[0]
        if d not in seen:
            seen.append(d)
    return seen


def retrieved_docs(rec: dict, k: int) -> list[str]:
    seen: list[str] = []
    for r in rec["references"]:
        if r["doc_id"] and r["doc_id"] not in seen:
            seen.append(r["doc_id"])
    return seen[:k]


def recall_at_k(retrieved: list[str], relevant: list[str]) -> float | None:
    if not relevant:
        return None
    return len(set(retrieved) & set(relevant)) / len(relevant)


def reciprocal_rank(retrieved: list[str], relevant: list[str]) -> float | None:
    if not relevant:
        return None
    for i, d in enumerate(retrieved, start=1):
        if d in relevant:
            return 1.0 / i
    return 0.0


def mean(vals: list) -> float | None:
    vals = [v for v in vals if v is not None]
    return sum(vals) / len(vals) if vals else None


def score_item(item: dict, rec: dict, k: int) -> dict:
    answerable = item["expected"] == "answer"
    abstained = is_abstention(rec)
    rel = relevant_docs(item)
    got = retrieved_docs(rec, k)
    return {
        "id": item["id"],
        "caller": item["caller"],
        "expected": item["expected"],
        "abstained": abstained,
        "correct": (answerable and not abstained and key_facts_present(rec["answer_text"], item["key_facts"])),
        "recall_at_k": recall_at_k(got, rel) if answerable else None,
        "mrr": reciprocal_rank(got, rel) if answerable else None,
        "n_refs": len(rec["references"]),
        "n_cited": len(rec["cited_reference_ids"]),
        "skipped": ",".join(rec["skipped"]) or "-",
        "grounding_score": rec["grounding_score"],
        "relevant_docs": rel,
        "retrieved_docs": got,
    }


def summarise(scores: list[dict]) -> dict:
    answerable = [s for s in scores if s["expected"] == "answer"]
    unanswerable = [s for s in scores if s["expected"] == "abstain"]
    answered = [s for s in scores if not s["abstained"]]
    summary = {
        "n": len(scores),
        "n_answerable": len(answerable),
        "n_unanswerable": len(unanswerable),
        "recall_at_5": mean([s["recall_at_k"] for s in answerable]),
        "mrr": mean([s["mrr"] for s in answerable]),
        "correctness": mean([1.0 if s["correct"] else 0.0 for s in answerable]),
        "correct_abstain_rate": mean([1.0 if s["abstained"] else 0.0 for s in unanswerable]),
        "false_abstain_rate": mean([1.0 if s["abstained"] else 0.0 for s in answerable]),
        "false_answer_rate": mean([0.0 if s["abstained"] else 1.0 for s in unanswerable]),
        "zero_citation_rate": mean([1.0 if s["n_cited"] == 0 else 0.0 for s in answered]),
        "grounding_score_mean": mean([s["grounding_score"] for s in answered]),
    }
    return summary


# ----------------------------------------------------------------------------- the judge
def run_judge(env: dict, items: list[dict], records: dict, scores: list[dict], label: str) -> dict:
    """Vertex AI evaluation: groundedness and question_answering_quality on the answers given."""
    try:
        import pandas as pd
        import vertexai
        from vertexai.evaluation import EvalTask
    except ImportError as e:
        print(f"\n!! {e}\n!! {GENAI_CLIENT_NOTE}\n")
        return {}

    rows = []
    by_id = {s["id"]: s for s in scores}
    for item in items:
        rec = records[item["id"]]
        if by_id[item["id"]]["abstained"]:
            continue  # nothing to judge when the service refused
        rows.append({
            "prompt": item["question"],
            "response": rec["answer_text"],
            "context": "\n\n".join(r["content"] for r in rec["references"]),
            "reference": item["reference_answer"],
        })
    if not rows:
        print("no answers to judge (everything abstained)")
        return {}
    df = pd.DataFrame(rows)
    print(f"\n== Vertex AI evaluation on {len(df)} answers (project {env['PROJECT_ID']}, "
          f"location {env.get('VERTEX_LOCATION', 'europe-west2')})")
    vertexai.init(project=env["PROJECT_ID"], location=env.get("VERTEX_LOCATION", "europe-west2"))
    task = EvalTask(
        dataset=df,
        metrics=["groundedness", "question_answering_quality"],
        experiment=f"bookshelf-d1-{label}",
    )
    result = task.evaluate()
    summary = dict(result.summary_metrics)
    print("summary_metrics from the service:")
    for k2, v in summary.items():
        print(f"  {k2}: {v}")
    out = {}
    for metric in ("groundedness", "question_answering_quality"):
        for key, val in summary.items():
            if key.startswith(metric) and key.endswith("/mean"):
                out[metric] = float(val)
    # per-row scores back onto the table, if the service returned them
    try:
        table = result.metrics_table
        judged_ids = [item["id"] for item in items if not by_id[item["id"]]["abstained"]]
        for metric in ("groundedness", "question_answering_quality"):
            col = f"{metric}/score"
            if col in table.columns:
                for qid, val in zip(judged_ids, table[col].tolist()):
                    by_id[qid][metric] = val
    except Exception as e:  # noqa: BLE001 — the per-row table is a nicety
        print(f"(per-question judge scores not attached: {e})")
    return out


# ----------------------------------------------------------------------------- output
def fmt(v, width=6) -> str:
    if v is None:
        return "-".rjust(width)
    if isinstance(v, bool):
        return ("yes" if v else "no").rjust(width)
    if isinstance(v, float):
        return f"{v:.2f}".rjust(width)
    return str(v).rjust(width)


def print_table(scores: list[dict]) -> None:
    has_judge = any("groundedness" in s for s in scores)
    head = f"{'id':<4} {'caller':<7} {'expect':<8} {'abstain':>7} {'correct':>7} {'rec@5':>6} {'mrr':>6} {'refs':>4} {'cited':>5}"
    if has_judge:
        head += f" {'ground':>6} {'qaq':>6}"
    head += "  skipped"
    print(head)
    print("-" * len(head))
    for s in scores:
        line = (f"{s['id']:<4} {s['caller']:<7} {s['expected']:<8} {fmt(s['abstained'], 7)} {fmt(s['correct'], 7)} "
                f"{fmt(s['recall_at_k'])} {fmt(s['mrr'])} {fmt(s['n_refs'], 4)} {fmt(s['n_cited'], 5)}")
        if has_judge:
            line += f" {fmt(s.get('groundedness'))} {fmt(s.get('question_answering_quality'))}"
        line += f"  {s['skipped']}"
        print(line)


def check_thresholds(summary: dict, thresholds: dict) -> list[str]:
    breaches = []
    print("\n== thresholds (eval.yaml)")
    for name, rule in thresholds.items():
        val = summary.get(name)
        if val is None:
            print(f"SKIPPED          {name:<28} (no value this run)")
            continue
        if "min" in rule and val < rule["min"]:
            msg = f"BELOW THRESHOLD  {name:<28} = {val:.3f}  (min {rule['min']})"
            breaches.append(msg); print(msg)
        elif "max" in rule and val > rule["max"]:
            msg = f"BELOW THRESHOLD  {name:<28} = {val:.3f}  (max {rule['max']})"
            breaches.append(msg); print(msg)
        else:
            bound = f"min {rule['min']}" if "min" in rule else f"max {rule['max']}"
            print(f"ok               {name:<28} = {val:.3f}  ({bound})")
    return breaches


# ----------------------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--no-status-filter", action="store_true", help='drop status: ANY("approved") from every caller filter')
    ap.add_argument("--from-fixtures", action="store_true", help="read fixtures/eval-sample.jsonl; call nothing")
    ap.add_argument("--skip-judge", action="store_true", help="do not call the Vertex AI evaluation service")
    ap.add_argument("--limit", type=int, default=0, help="only the first N golden items (a quick live check)")
    ap.add_argument("--out", type=Path, default=None, help="write records, scores and summary as JSON")
    args = ap.parse_args()

    golden = json.loads((KIT / "golden.json").read_text())["items"]
    callers = json.loads((KIT / "callers.json").read_text())
    cfg = load_yaml(KIT / "eval.yaml")
    k = int(cfg.get("k", 5))
    thresholds = cfg.get("thresholds", {})
    if args.limit:
        golden = golden[: args.limit]

    env = load_env(KIT / "lab.env")
    env.setdefault("LOCATION", "global")
    env.setdefault("ANSWER_MODEL", "stable")
    label = "no-status-filter" if args.no_status_filter else "with-filter"

    records: dict[str, dict] = {}
    if args.from_fixtures:
        path = KIT / "fixtures" / "eval-sample.jsonl"
        print(f"== FIXTURE MODE: reading {path.relative_to(KIT)} — no API is called; the fixture is "
              "example data")
        if args.no_status_filter:
            print("   (--no-status-filter changes nothing in fixture mode: the fixture holds one set of answers)")
        for line in path.read_text().splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            records[row["id"]] = parse_answer(row["response"])
        missing = [it["id"] for it in golden if it["id"] not in records]
        if missing:
            print(f"fixture has no record for: {missing}")
            return 2
    else:
        if not env.get("PROJECT_ID"):
            print("PROJECT_ID is empty: copy lab.env.example to lab.env and fill it in.")
            return 2
        if not env.get("APP_ID"):
            print("APP_ID is empty in lab.env.")
            return 2
        print(f"== {len(golden)} questions -> :answer on app {env['APP_ID']} in {env['PROJECT_ID']} ({label})")
        print(f"   model {env['ANSWER_MODEL']}; filters from callers.json")
        for name in callers:
            if name.startswith("_"):
                continue
            print(f"   {name:<7} {caller_filter(callers, name, args.no_status_filter) or '(none)'}")
        token = access_token()
        t0 = time.time()
        for i, item in enumerate(golden, start=1):
            filt = caller_filter(callers, item["caller"], args.no_status_filter)
            body = answer_request(item["question"], filt, env["ANSWER_MODEL"])
            if i == 1:
                print("first request body (the others differ only in query.text and filter):")
                print(json.dumps(body, indent=2))
            resp = call_answer(env, body, token)
            records[item["id"]] = parse_answer(resp)
            records[item["id"]]["raw"] = resp
            rec = records[item["id"]]
            print(f"  [{i:>2}/{len(golden)}] {item['id']} {item['caller']:<7} "
                  f"skipped={','.join(rec['skipped']) or '-'} refs={len(rec['references'])} "
                  f"{int(time.time() - t0):>4}s")

    scores = [score_item(item, records[item["id"]], k) for item in golden]
    summary = summarise(scores)

    if args.from_fixtures:
        print("\n== Vertex AI evaluation (groundedness, question_answering_quality): SKIPPED in fixture mode")
    elif args.skip_judge:
        print("\n== Vertex AI evaluation: skipped (--skip-judge)")
    else:
        summary.update(run_judge(env, golden, records, scores, label))

    print(f"\n== per question ({label})")
    print_table(scores)

    print(f"\n== summary ({label})")
    for key in ("n", "n_answerable", "n_unanswerable", "recall_at_5", "mrr", "correctness",
                "correct_abstain_rate", "false_abstain_rate", "false_answer_rate",
                "zero_citation_rate", "grounding_score_mean", "groundedness", "question_answering_quality"):
        if key in summary:
            v = summary[key]
            print(f"  {key:<28} {v if not isinstance(v, float) else f'{v:.3f}'}")
        elif key in ("groundedness", "question_answering_quality"):
            print(f"  {key:<28} (not run)")

    breaches = check_thresholds(summary, thresholds)

    if args.out:
        args.out.write_text(json.dumps({"label": label, "fixture_mode": args.from_fixtures, "summary": summary,
                                        "scores": scores, "records": records}, indent=2, ensure_ascii=False))
        print(f"\nwrote {args.out}")

    if breaches:
        print(f"\n{len(breaches)} threshold breach(es) — exit 1")
        return 1
    print("\nall thresholds met — exit 0")
    return 0


if __name__ == "__main__":
    sys.exit(main())
