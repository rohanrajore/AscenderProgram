#!/usr/bin/env bash
# 00-upload.sh — Part A, the upload only. Rewrites the gs://BUCKET/ placeholder in
# metadata.jsonl to your bucket and uploads corpus-html/ and metadata.jsonl into it.
# The bucket must already exist (you create it in the console). Every command is
# printed with a "+ " in front before it runs.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
[[ -f "$KIT/lab.env" ]] || { echo "lab.env not found. Run: cp $KIT/lab.env.example $KIT/lab.env, then fill it in." >&2; exit 1; }
# shellcheck source=../lab.env.example
source "$KIT/lab.env"
[[ -n "${PROJECT_ID:-}" ]] || { echo "PROJECT_ID is empty in lab.env. Set it and rerun." >&2; exit 1; }
: "${BUCKET:?BUCKET is empty in lab.env}"

run() { echo "+ $*" >&2; "$@"; }

run gcloud config set project "$PROJECT_ID"

if ! gcloud storage buckets describe "gs://$BUCKET" --project "$PROJECT_ID" >/dev/null 2>&1; then
  echo "bucket gs://$BUCKET not found. Create it in the console first (Part A step 2), with exactly this name." >&2
  exit 1
fi

# metadata.jsonl ships with the placeholder prefix gs://BUCKET/corpus-html/ . Rewrite it
# into a temporary copy so the uploaded file points at your bucket.
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "+ sed \"s#gs://BUCKET/#gs://${BUCKET}/#g\" metadata.jsonl > $TMP/metadata.jsonl" >&2
sed "s#gs://BUCKET/#gs://${BUCKET}/#g" "$KIT/metadata.jsonl" > "$TMP/metadata.jsonl"
if grep -q 'gs://BUCKET/' "$TMP/metadata.jsonl"; then echo "uri rewrite failed" >&2; exit 1; fi
echo "first rewritten line:"; head -n 1 "$TMP/metadata.jsonl"
run gcloud storage cp -r "$KIT/corpus-html" "gs://$BUCKET/"
run gcloud storage cp "$TMP/metadata.jsonl" "gs://$BUCKET/metadata.jsonl"
run gcloud storage ls -r "gs://$BUCKET/"
echo
echo "Done. Next: Part A step 4 — enable the APIs in the console."
