#!/usr/bin/env bash
# 00-setup.sh — Part A. Enable the APIs, create the bucket, upload corpus-html and
# metadata.jsonl (with the uri prefix rewritten to your bucket), and make a Python venv
# for evaluate.py.
#
# Every command is printed before it runs.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
[[ -f "$KIT/lab.env" ]] || { echo "lab.env not found. Run: cp $KIT/lab.env.example $KIT/lab.env, then fill it in." >&2; exit 1; }
# shellcheck source=../lab.env.example
source "$KIT/lab.env"
[[ -n "${PROJECT_ID:-}" ]] || { echo "PROJECT_ID is empty in lab.env. Set it and rerun." >&2; exit 1; }
: "${BUCKET:?BUCKET is empty in lab.env}"
: "${BUCKET_LOCATION:=europe-west2}"

run() { echo "+ $*" >&2; "$@"; }

echo "== 1/5 project"
run gcloud config set project "$PROJECT_ID"

echo "== 2/5 enable APIs (Discovery Engine = the Agent Search API; Vertex AI for evaluate.py)"
run gcloud services enable discoveryengine.googleapis.com aiplatform.googleapis.com storage.googleapis.com --project "$PROJECT_ID"

echo "== 3/5 bucket gs://$BUCKET"
if gcloud storage buckets describe "gs://$BUCKET" --project "$PROJECT_ID" >/dev/null 2>&1; then
  echo "bucket exists, keeping it"
else
  run gcloud storage buckets create "gs://$BUCKET" --project "$PROJECT_ID" --location "$BUCKET_LOCATION" --uniform-bucket-level-access
fi

echo "== 4/5 upload the 13 HTML files and metadata.jsonl"
# metadata.jsonl ships with the placeholder prefix gs://BUCKET/corpus-html/ . Rewrite it
# into a temporary copy so the uploaded file points at your bucket.
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "+ sed \"s#gs://BUCKET/#gs://${BUCKET}/#g\" metadata.jsonl > $TMP/metadata.jsonl" >&2
sed "s#gs://BUCKET/#gs://${BUCKET}/#g" "$KIT/metadata.jsonl" > "$TMP/metadata.jsonl"
if grep -q 'gs://BUCKET/' "$TMP/metadata.jsonl"; then echo "uri rewrite failed" >&2; exit 1; fi
echo "first rewritten line:"; head -n 1 "$TMP/metadata.jsonl"
run gcloud storage cp -r "$KIT/corpus-html" "gs://$BUCKET/"
run gcloud storage cp "$TMP/metadata.jsonl" "gs://$BUCKET/metadata.jsonl"
run gcloud storage ls -r "gs://$BUCKET/"

echo "== 5/5 python venv for evaluate.py (in \$HOME so it survives Cloud Shell restarts)"
VENV="$HOME/regai-venv"
if [[ ! -x "$VENV/bin/python" ]]; then
  run python3 -m venv "$VENV"
fi
run "$VENV/bin/pip" install --quiet --upgrade pip
run "$VENV/bin/pip" install --quiet "google-cloud-aiplatform[evaluation]" pandas pyyaml requests
echo
echo "Done. Before Part F run:  source $VENV/bin/activate"
echo "Next: scripts/01-create-datastore.sh"
