#!/usr/bin/env bash
# 03-import.sh — Part B. Import the 13 documents (HTML in the bucket, metadata from
# metadata.jsonl) and poll the import operation, printing elapsed time.
#
# The curl is printed before it runs.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
[[ -f "$KIT/lab.env" ]] || { echo "lab.env not found. Run: cp $KIT/lab.env.example $KIT/lab.env, then fill it in." >&2; exit 1; }
# shellcheck source=../lab.env.example
source "$KIT/lab.env"
[[ -n "${PROJECT_ID:-}" ]] || { echo "PROJECT_ID is empty in lab.env. Set it and rerun." >&2; exit 1; }
: "${LOCATION:=global}"
: "${DATASTORE_ID:?DATASTORE_ID is empty in lab.env}"
: "${APP_ID:?APP_ID is empty in lab.env}"
command -v jq >/dev/null || { echo "jq is required (it is preinstalled in Cloud Shell)." >&2; exit 1; }

API="https://discoveryengine.googleapis.com/v1"
PARENT="projects/$PROJECT_ID/locations/$LOCATION/collections/default_collection"
RESP="$(mktemp)"; trap 'rm -f "$RESP"' EXIT
HTTP_CODE=""

# call METHOD URL [BODY_FILE]: prints the exact curl, runs it, leaves the body in $RESP
# and the status in $HTTP_CODE. Set QUIET=1 to skip the printing (used while polling).
call() {
  local method="$1" url="$2" body="${3:-}"
  if [[ -z "${QUIET:-}" ]]; then
    {
      echo "+ curl -sS -X $method \"$url\" \\"
      echo "    -H \"Authorization: Bearer \$(gcloud auth print-access-token)\" \\"
      echo "    -H \"X-Goog-User-Project: $PROJECT_ID\" \\"
      echo "    -H \"Content-Type: application/json\"${body:+ -d @$body}"
      if [[ -n "$body" ]]; then echo "  body:"; sed 's/^/    /' "$body"; fi
    } >&2
  fi
  local token; token="$(gcloud auth print-access-token)"
  HTTP_CODE="$(curl -sS -o "$RESP" -w '%{http_code}' -X "$method" "$url" \
    -H "Authorization: Bearer $token" \
    -H "X-Goog-User-Project: $PROJECT_ID" \
    -H "Content-Type: application/json" ${body:+-d @"$body"})"
}

# must_ok: exit with the response body shown unless the last call returned 2xx.
must_ok() { [[ "$HTTP_CODE" == 2* ]] || { echo "HTTP $HTTP_CODE:" >&2; cat "$RESP" >&2; echo >&2; exit 1; }; }

# poll_operation NAME: GET the long-running operation every 20 s until done, printing elapsed time.
poll_operation() {
  local name="$1" start=$SECONDS
  echo "polling every 20 s with:  curl -sS \"$API/$name\" -H \"Authorization: Bearer \$(gcloud auth print-access-token)\"" >&2
  while :; do
    QUIET=1 call GET "$API/$name"; must_ok
    if [[ "$(jq -r '.done // false' "$RESP")" == "true" ]]; then
      echo >&2; echo "operation done after $((SECONDS - start)) s" >&2
      if jq -e '.error' "$RESP" >/dev/null; then echo "operation FAILED:" >&2; jq '.error' "$RESP" >&2; exit 1; fi
      return 0
    fi
    printf '\r  waiting... %4d s elapsed' $((SECONDS - start)) >&2
    sleep 20
  done
}
: "${BUCKET:?BUCKET is empty in lab.env}"

BODY="$(mktemp)"; trap 'rm -f "$RESP" "$BODY"' EXIT
jq -n --arg uri "gs://$BUCKET/metadata.jsonl" \
  '{reconciliationMode: "INCREMENTAL", gcsSource: {inputUris: [$uri]}}' > "$BODY"

echo "== import documents into $DATASTORE_ID from gs://$BUCKET/metadata.jsonl"
call POST "$API/$PARENT/dataStores/$DATASTORE_ID/branches/default_branch/documents:import" "$BODY"
must_ok
echo "response:"; jq . "$RESP"
OP="$(jq -r '.name' "$RESP")"
START=$SECONDS
poll_operation "$OP"
echo "import took $((SECONDS - START)) s (record this in the checklist)"
echo "operation result:"
jq '{metadata: .metadata, response: .response}' "$RESP"

echo "== documents now in the branch"
call GET "$API/$PARENT/dataStores/$DATASTORE_ID/branches/default_branch/documents?pageSize=50"; must_ok
jq -r '.documents // [] | length as $n | "\($n) documents"' "$RESP"
jq -r '.documents // [] | .[] | "  \(.id)\t\(.structData.status)\t\(.structData.classification)"' "$RESP"
echo
echo "The operation being done does not mean indexing has finished. Run"
echo "  scripts/search.sh \"How long does a customer have to dispute a card transaction?\""
echo "and if it returns 0 results, wait a few minutes and try again."
echo "Next: scripts/04-create-app.sh"
