# regai-d1-gcp-kit — the Bookshelf on Google Cloud, Day 1

One lab, six parts. The whole retrieval pipeline is built from Google Cloud's managed
pieces: a data store that parses and chunks the documents, a search app that retrieves,
reranks and writes grounded answers, and the evaluation service that judges them. You
run scripts; you write no code.

Google has renamed Vertex AI Search to **Agent Search**. The API underneath did not
change: it is the **Discovery Engine API** (`discoveryengine.googleapis.com`), and
every script here calls it directly with `curl`. The console still says "AI
Applications" in places.

Every script prints the exact `curl` (or `gcloud`) command before running it, so you
always see the API call being made.

## What is here

```
README.md                this file
lab.env.example          copy to lab.env: PROJECT_ID, LOCATION, BUCKET, DATASTORE_ID, APP_ID, ANSWER_MODEL
corpus-html/             the 13 policies as HTML (the layout parser reads HTML, not markdown)
corpus-md/               the same 13 policies as markdown, for reading
metadata.jsonl           13 lines: id, structData {title, status, classification, department,
                         version, effective_date}, content {mimeType text/html, uri}
schema.json              the schema patch: status, classification, department filterable; title mapped
datastore.json           the data store create body: layout parser, 250-token chunks, ancestor headings
app.json                 the search app create body: Enterprise tier + LLM add-on
golden.json              the 40 questions (32 answerable, 8 that must be refused)
callers.json             priya / daniel / mlro: clearance and the filter string each one gets
eval.yaml                thresholds evaluate.py checks; Part F sets them from your with-filter run
scripts/
  00-setup.sh            Part A: enable APIs, make the bucket, upload corpus + metadata, make a venv
  00-upload.sh           Part A (console edition): the upload only — bucket made in the console
  01-create-datastore.sh Part B: create the data store, wait until it answers a search
  02-patch-schema.sh     Part B: mark the metadata fields filterable
  03-import.sh           Part B: import the 13 documents, poll the operation, print elapsed time
  04-create-app.sh       Part C: create the search app
  search.sh              Part D: search.sh "question" ['filter']   -> ranked chunks
  answer.sh              Part D/E: answer.sh --user daniel "question" -> answer, citations, score, skip reasons
  evaluate.py            Part F: the 40 questions, local metrics, Vertex AI judge, thresholds, exit code
  99-teardown.sh         delete the app, the data store and the bucket (asks first)
fixtures/                example responses in the documented shapes; evaluate.py --from-fixtures reads them
```

## The order

Upload the kit to Cloud Shell (zip, then `unzip regai-d1-gcp-kit.zip`), then:

```
cp lab.env.example lab.env      # fill in PROJECT_ID; the defaults for the rest are fine
scripts/00-setup.sh             # Part A
scripts/01-create-datastore.sh  # Part B
scripts/02-patch-schema.sh      # Part B
scripts/03-import.sh            # Part B — then read on while it runs
scripts/04-create-app.sh        # Part C
scripts/search.sh "Which form must a cardholder sign before a dispute can go to chargeback?"                                 # Part D-1
scripts/search.sh "Which form must a cardholder sign before a dispute can go to chargeback?" 'status: ANY("approved")'       # Part D-2
scripts/search.sh "Which form ..." "$(jq -r .priya.filter callers.json)"                                                     # Part D-2
scripts/answer.sh --user daniel "Which form must a cardholder sign before a dispute can go to chargeback?"                   # Part D-3
scripts/answer.sh --user priya  "Which form must a cardholder sign before a dispute can go to chargeback?"                   # Part D-3
# Part E is in the console: the app's preview pane, same question
source ~/regai-venv/bin/activate
python scripts/evaluate.py                     # Part F
python scripts/evaluate.py --no-status-filter  # Part F: the weakened run
scripts/99-teardown.sh                         # when you are done
```

Every script sources `lab.env` and stops if `PROJECT_ID` is empty. They all use
`set -euo pipefail`, get a token with `gcloud auth print-access-token`, and send
`X-Goog-User-Project` so the calls are billed to your project.

**Cost.** The search app is created with `SEARCH_TIER_ENTERPRISE` and
`SEARCH_ADD_ON_LLM`. Both are required for generated answers and both are charged
for. `evaluate.py` sends 40 answer requests per run and then calls the Vertex AI
evaluation service. Run `99-teardown.sh` at the end of the day.

## What each part shows

**Part A — set-up.** The bucket, the 13 HTML files and `metadata.jsonl`. The metadata
file ships with the placeholder uri prefix `gs://BUCKET/corpus-html/`; `00-setup.sh`
rewrites it with `sed` into a temporary copy before uploading, so the shipped file
never changes.

**Part B — data store and import.** `datastore.json` asks for the layout parser and
layout-based chunking: 250 tokens per chunk, with the headings above each chunk
included in it. That is what you can configure. What you cannot see is where the
chunk boundaries fall until you search. `02-patch-schema.sh` marks `status`,
`classification` and `department` as indexable so they can be used in filters.
`03-import.sh` prints elapsed time while the operation runs; the operation finishing
does not mean indexing has finished, so if `search.sh` returns nothing, wait and
retry.

**Part C — the app.** One data store, one search app on top. The answer endpoint is
at app level, the plain search endpoint works at data-store level; the scripts use
both.

**Part D — search and filter.** D-1 is the FRM question with no filter. The corpus
contains the superseded v2.4 of the dispute policy (`POL-CR-014-v2`, which names form
FRM-CD-6) next to the approved v3.2 (FRM-CD-7). Note where the v2 chunks rank. D-2
adds `status: ANY("approved")`, then priya's and daniel's filters from
`callers.json`. priya is cleared for internal only, so the confidential dispute policy
disappears from her list. D-3 asks the answer endpoint the same question as daniel
and as priya.

The filter is a metadata filter on indexable fields. It is not an access control:
whoever can call the API can send any filter. What you still own is the string in
`callers.json` and the code that chooses it.

**Part E — the preview pane.** The console's preview of the app, same question, with
citations highlighted. Console labels change; find the page by what it does.

**Part F — measuring.** `evaluate.py` sends every golden question with its caller's
filter and computes, from the response alone: key-fact correctness, abstention
(`answerSkippedReasons` non-empty or the refusal sentence), document-level recall@5
and MRR from `references[]`. It then sends prompt / response / context / reference to
the Vertex AI evaluation service for `groundedness` and
`question_answering_quality`, prints a per-question table and a summary, checks
`eval.yaml`, prints `BELOW THRESHOLD` for each breach, and exits 1 if there is one.
`--no-status-filter` drops `status: ANY("approved")` from every filter: the superseded
policy comes back into scope and the numbers move.

## What the scripts print — expected output

`search.sh` — expected output (values from `fixtures/search-sample.json`; yours will differ):

```
totalSize: 5
rank  document          chunk   content (first 90 chars)
1     POL-CR-014        c6      # Credit Card Dispute and Chargeback Handling Policy ## 6. Evidence and the cardholder dec
2     POL-CR-014-v2     c5      # Credit Card Dispute and Chargeback Handling Policy ## 6. Evidence 6.1 Every dispute othe
3     POL-CR-014        c7      # Credit Card Dispute and Chargeback Handling Policy ## 7. Roles and authority | Role | Au
```

`answer.sh --user daniel` — expected output (values from `fixtures/answer-sample.json`):

```
answer:
Every dispute other than "duplicate or incorrect amount" requires a completed Cardholder Dispute Declaration, form FRM-CD-7, ...

citations:
  [1] Credit Card Dispute and Chargeback Handling Policy — # Credit Card Dispute and Chargeback Handling Policy ## 6. Evidence and the cardholder declaration 6
grounding: 0.93
skipped: none
```

`answer.sh --user priya` — expected output (values from `fixtures/answer-skipped-sample.json`):

```
answer:
(no answer text)

citations:
  (none)
grounding: (not returned)
skipped: NO_RELEVANT_CONTENT
```

`evaluate.py` — expected output, from `python scripts/evaluate.py --from-fixtures`
(the example data deliberately contains one false abstain, one missing key fact, two
lower-ranked documents, one uncited answer and one false answer so that every column
and both `BELOW THRESHOLD` lines appear; exit code 1 is the expected result of that
run):

```
== per question (with-filter)
id   caller  expect   abstain correct  rec@5    mrr refs cited  skipped
-----------------------------------------------------------------------
G01  daniel  answer        no     yes   1.00   1.00    3     1  -
...
G07  daniel  answer       yes      no   0.00   0.00    0     0  LOW_GROUNDED_ANSWER
...
U01  priya   abstain       no      no      -      -    3     1  -
U02  priya   abstain      yes      no      -      -    0     0  NO_RELEVANT_CONTENT

== summary (with-filter)
  recall_at_5                  0.969
  mrr                          0.932
  correctness                  0.938
  correct_abstain_rate         0.875
  false_abstain_rate           0.031
  false_answer_rate            0.125
  zero_citation_rate           0.031
  groundedness                 (not run)
  question_answering_quality   (not run)

== thresholds (eval.yaml)
ok               recall_at_5                  = 0.969  (min 0.8)
BELOW THRESHOLD  false_answer_rate            = 0.125  (max 0.1)
SKIPPED          groundedness                 (no value this run)
2 threshold breach(es) — exit 1
```

## If something breaks

- `PROJECT_ID is empty` — you have not copied and filled in `lab.env`.
- HTTP 403 with `SERVICE_DISABLED` or a permission name — run `00-setup.sh` again,
  and check you have the Discovery Engine Admin role on the project.
- HTTP 400 on `:answer` mentioning the model — set `ANSWER_MODEL=stable` in `lab.env`
  and retry.
- `search.sh` returns 0 results after the import — indexing is still running; wait.
- `evaluate.py` cannot import `vertexai.evaluation` — it prints a note; try
  `pip install --upgrade "google-cloud-aiplatform[evaluation]"` in the venv, and if the
  import is gone for good, the newer GenAI-client evaluation path replaces it. Use
  `--skip-judge` for the local metrics meanwhile.
