# lab-parts — the defence switches each part turns on

Each file here is an `agent.env` fragment: the five defence switches set for one lab part.
Two uses:

1. **Jump to a part.** If you are behind, append a fragment to your `agent/agent.env` (the
   five lines override the copy you were editing):

   ```
   cat lab-parts/lab-a-part-c.env >> agent/agent.env
   ```

2. **Pick a config for the red-team runner.** `redteam.py --config <name>` reads
   `lab-parts/<name>.env`:

   ```
   python security/redteam.py --config full
   python security/redteam.py --config full-minus-guard
   ```

| File | WRAP | GUARD | ARMOR | REDACT | FILTER | Used in |
|---|---|---|---|---|---|---|
| `lab-a-part-a.env` | off | off | off | off | off | Lab A Part A — attack, no defences |
| `lab-a-part-b.env` | on | off | off | off | off | Lab A Part B — WRAP |
| `lab-a-part-c.env` | off | on | off | off | off | Lab A Part C — GUARD |
| `lab-a-part-d.env` | off | off | on | off | off | Lab A Part D — ARMOR |
| `lab-a-part-e.env` | off | off | off | on | off | Lab A Part E — REDACT |
| `lab-a-part-f.env` | on | on | on | on | on | Lab A Part F — full stack |
| `full.env` | on | on | on | on | on | the release gate config |
| `full-minus-wrap.env` | off | on | on | on | on | defence in depth: what WRAP alone catches |
| `full-minus-guard.env` | on | off | on | on | on | defence in depth: what GUARD alone catches |
| `full-minus-armor.env` | on | on | off | on | on | defence in depth: what ARMOR alone catches |
| `full-minus-redact.env` | on | on | on | off | on | defence in depth: what REDACT alone catches |
| `full-minus-filter.env` | on | on | on | on | off | defence in depth: what FILTER alone catches |

Parts B–E turn on a single layer, so each part shows exactly what that one layer catches.
Part F turns everything on, then the `full-minus-*` configs remove one layer at a time so
you can measure what each layer alone is responsible for — that is defence in depth, as a
number.
