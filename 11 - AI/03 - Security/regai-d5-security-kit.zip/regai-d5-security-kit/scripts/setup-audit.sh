#!/usr/bin/env bash
# setup-audit.sh — create the immutable audit trail: a locked Cloud Logging bucket, a sink
# that routes the agent's decision lines into it, and a log view whose read access is
# granted separately, so the writer of the audit cannot read or alter it.
#
#   PROJECT=my-project LOCATION=us bash scripts/setup-audit.sh
#
# ############################################################################
# #  WARNING — `--locked` IS IRREVERSIBLE.                                    #
# #  A locked bucket CANNOT be deleted, and its retention CANNOT be shortened,#
# #  until EVERY entry has met the retention period. On a real project a      #
# #  mistake here is permanent. For the lab, DO A DRY RUN FIRST (below) and   #
# #  lock only a THROWAWAY bucket you are willing to keep for RETENTION_DAYS. #
# ############################################################################
#
# LIVE-UNTESTED: these commands are written against the documented gcloud surface and were
# NOT run while building the kit. Read them, then run with DRY_RUN=1 to print only.
set -euo pipefail

PROJECT="${PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
LOCATION="${LOCATION:-us}"                 # a Cloud Logging bucket location (us, eu, ...)
BUCKET="${BUCKET:-bookshelf-audit}"
SINK="${SINK:-bookshelf-audit-sink}"
VIEW="${VIEW:-bookshelf-audit-view}"
RETENTION_DAYS="${RETENTION_DAYS:-400}"    # e.g. 400 days; must exceed your review cycle
VIEWER="${VIEWER:-group:audit-readers@example.com}"   # who may READ the view
DRY_RUN="${DRY_RUN:-0}"

run() {   # print every command; run it only when DRY_RUN is not 1
  echo "+ $*"
  [ "$DRY_RUN" = "1" ] || "$@"
}

echo "# project=$PROJECT location=$LOCATION bucket=$BUCKET retention=${RETENTION_DAYS}d"
[ "$DRY_RUN" = "1" ] && echo "# DRY RUN — commands are printed, not executed."
echo

# 1) The audit bucket, with retention. NOT locked yet — lock is the last, deliberate step.
#    Console: Logging > Logs Storage > Create log bucket.
run gcloud logging buckets create "$BUCKET" \
  --location="$LOCATION" \
  --retention-days="$RETENTION_DAYS" \
  --description="Immutable audit trail for the Bookshelf agent" \
  --project="$PROJECT"

# 2) A sink that routes only the agent's structured decision lines into the bucket.
#    Console: Logging > Log Router > Create sink (destination = the log bucket above).
DEST="logging.googleapis.com/projects/$PROJECT/locations/$LOCATION/buckets/$BUCKET"
run gcloud logging sinks create "$SINK" "$DEST" \
  --log-filter='jsonPayload.event="agent_decision" OR jsonPayload.event="tool_call"' \
  --project="$PROJECT"
echo "# grant the sink's writer identity permission to write to the bucket:"
echo "#   gcloud logging sinks describe $SINK --project=$PROJECT --format='value(writerIdentity)'"
echo "#   then add that member as roles/logging.bucketWriter on the bucket."

# 3) A log view over the bucket, and read access granted ONLY on the view. Separation of
#    duties: the agent's service account can write; only VIEWER can read.
#    Console: Logging > Logs Storage > the bucket > Log views > Create.
run gcloud logging views create "$VIEW" \
  --bucket="$BUCKET" --location="$LOCATION" \
  --log-filter='jsonPayload.event="agent_decision"' \
  --project="$PROJECT"
run gcloud logging views add-iam-policy-binding "$VIEW" \
  --bucket="$BUCKET" --location="$LOCATION" \
  --member="$VIEWER" --role="roles/logging.viewAccessor" \
  --project="$PROJECT"

# 4) LOCK IT — LAST, and only once you are sure. This is the irreversible step.
echo
echo "############################################################################"
echo "#  The next command LOCKS the bucket. It is IRREVERSIBLE. The bucket then   #"
echo "#  cannot be deleted until every entry has met ${RETENTION_DAYS}-day retention.        #"
echo "############################################################################"
if [ "${CONFIRM_LOCK:-}" = "yes" ]; then
  run gcloud logging buckets update "$BUCKET" \
    --location="$LOCATION" --locked --project="$PROJECT"
else
  echo "+ (skipped) gcloud logging buckets update $BUCKET --location=$LOCATION --locked"
  echo "# to actually lock, re-run with CONFIRM_LOCK=yes (throwaway bucket only)."
fi

echo
echo "# Immutability (locked + retention) + access control (view + viewAccessor) = an"
echo "# audit trail the agent can write but cannot read or alter. That is the point."
