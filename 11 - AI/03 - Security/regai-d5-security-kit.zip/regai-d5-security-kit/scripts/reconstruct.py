#!/usr/bin/env python3
"""reconstruct.py — rebuild the full decision trail for one audit id.

    python scripts/reconstruct.py aud_1a2b3c4d5e            # from agent/audit.jsonl
    python scripts/reconstruct.py aud_1a2b3c4d5e --file x.jsonl
    python scripts/reconstruct.py aud_1a2b3c4d5e --live     # from Cloud Logging

Lab B Part C: run an attack, take the audit id it printed, and reconstruct the incident —
who called, what they asked, what evidence was retrieved, which tools ran (and which the
guard blocked), which defence layers fired, and the outcome. This is what "reconstruct the
incident from the audit trail" means, and why the trail must be complete and immutable.

Offline it reads the local audit.jsonl the agent also writes. --live reads the same JSON
lines back from Cloud Logging (the locked bucket set up by setup-audit.sh); that path is
LIVE-UNTESTED here.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import textwrap
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
DEFAULT_AUDIT = KIT / "agent" / "audit.jsonl"


def from_file(path: Path, audit_id: str) -> list[dict]:
    if not path.exists():
        sys.exit(f"no audit file at {path} — run an attack first, or pass --file")
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if rec.get("id") == audit_id:
            rows.append(rec)
    return rows


def from_live(audit_id: str) -> list[dict]:
    """LIVE-UNTESTED. Read the structured entries back from the locked audit bucket."""
    flt = ('resource.type="cloud_run_revision" '
           'AND jsonPayload.event="agent_decision" '
           f'AND jsonPayload.id="{audit_id}"')
    out = subprocess.check_output(
        ["gcloud", "logging", "read", flt, "--limit", "10", "--format", "json"],
        text=True)
    return [e.get("jsonPayload", {}) for e in json.loads(out)]


def field(label: str, value: str) -> None:
    """Print a label + value, wrapping the value to keep lines short."""
    lines = textwrap.wrap(value, width=76) or [""]
    print(f"{label:12} {lines[0]}")
    for extra in lines[1:]:
        print(f"{'':12} {extra}")


def show(rec: dict) -> None:
    print(f"audit id     {rec.get('id')}")
    print(f"caller       {rec.get('caller')}")
    print(f"decision     {rec.get('decision')}")
    layers = rec.get("layers") or []
    print(f"layers fired {', '.join(layers) if layers else '(none — no defence acted)'}")
    field("request", str(rec.get("message", "")))
    ev_ids = rec.get("evidence_ids") or []
    field("evidence", ", ".join(ev_ids) if ev_ids else "(no documents retrieved)")
    print("tool calls:")
    for tc in rec.get("tool_calls") or []:
        status = "ok" if tc.get("ok") else f"BLOCKED ({tc.get('blocked', 'error')})"
        args = json.dumps(tc.get("args", {}), ensure_ascii=False)
        if len(args) > 60:
            args = args[:57] + "...}"
        print(f"  - {tc.get('name')}({args})  -> {status}")
    if not (rec.get("tool_calls")):
        print("  (no tools called)")
    field("outcome", str(rec.get("outcome", "")))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("audit_id", help="the aud_... id the agent printed")
    ap.add_argument("--file", default=str(DEFAULT_AUDIT), help="audit.jsonl path")
    ap.add_argument("--live", action="store_true", help="read from Cloud Logging instead")
    a = ap.parse_args(argv)

    rows = from_live(a.audit_id) if a.live else from_file(Path(a.file), a.audit_id)
    if not rows:
        print(f"no audit record for id {a.audit_id}")
        return 1
    print(f"# reconstructed decision trail for {a.audit_id} "
          f"({len(rows)} record{'s' if len(rows) != 1 else ''})\n")
    for i, rec in enumerate(rows):
        if i:
            print()
        show(rec)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
