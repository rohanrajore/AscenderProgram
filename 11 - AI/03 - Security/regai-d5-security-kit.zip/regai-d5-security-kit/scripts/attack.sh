#!/usr/bin/env bash
# attack.sh — fire ONE attack from attacks.yaml at the agent and show what each layer did.
#
#   bash scripts/attack.sh i1-exfil-evidence                 # no defences (Part A)
#   bash scripts/attack.sh i1-exfil-evidence lab-a-part-c    # with WRAP+GUARD... etc
#   bash scripts/attack.sh a1-agency-lookup-reserve full     # the full stack
#
# The second argument is a config name from lab-parts/ (default: lab-a-part-a, no
# defences). Offline: FAKE_MODEL FAKE_API ARMOR_FAKE REDACT_FAKE, so it is deterministic
# and needs no cloud. Live: drop the FAKE_* exports and set MCP_URL / PROJECT_ID etc. in
# agent/agent.env, and it fires at the real agent.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
PY="${PYTHON:-python3}"
ID="${1:-}"
CONFIG="${2:-lab-a-part-a}"
[ -n "$ID" ] || { echo "usage: bash scripts/attack.sh <attack-id> [config]"; exit 2; }

FRAG="$KIT/lab-parts/$CONFIG.env"
[ -f "$FRAG" ] || { echo "no such config: $FRAG (see lab-parts/)"; exit 2; }

# Pull this attack's caller and input out of attacks.yaml.
read -r CALLER INPUT < <("$PY" - "$KIT/attacks.yaml" "$ID" <<'EOF'
import sys, yaml
data = yaml.safe_load(open(sys.argv[1], encoding="utf-8"))["attacks"]
atk = next((a for a in data if a["id"] == sys.argv[2]), None)
if not atk:
    sys.exit(f"no attack id {sys.argv[2]} in attacks.yaml")
print(atk["caller"], atk["input"])
EOF
)
[ -n "${CALLER:-}" ] || exit 1

# Load the config fragment's switches into the environment.
set -a; # shellcheck disable=SC1090
. "$FRAG"; set +a

echo "# attack:  $ID"
echo "# config:  $CONFIG   (WRAP=$WRAP GUARD=$GUARD ARMOR=$ARMOR REDACT=$REDACT FILTER=$FILTER)"
echo "# caller:  $CALLER"
echo "# input:   $INPUT"
echo

STATE="$(mktemp)"; AUD="$(mktemp)"; OUT="$(mktemp)"
trap 'rm -f "$STATE" "$AUD" "$OUT"' EXIT
env FAKE_MODEL=1 FAKE_API=1 ARMOR_FAKE=1 REDACT_FAKE=1 TOOLS=on AGENT_ENV=/nonexistent \
    WRAP="$WRAP" GUARD="$GUARD" ARMOR="$ARMOR" REDACT="$REDACT" FILTER="$FILTER" \
    FAKE_API_STATE="$STATE" AUDIT_FILE="$AUD" \
    "$PY" "$KIT/agent/agent.py" --user "$CALLER" "$INPUT" 2>&1 | tee "$OUT"

echo
echo "# what each layer did (the defence signatures above):"
grep -E "wrapped:|blocked:|armor:|redacted:|filter:|bound:" "$OUT" \
  || echo "  (no defence layer acted — with no defences on, that is the breach)"
