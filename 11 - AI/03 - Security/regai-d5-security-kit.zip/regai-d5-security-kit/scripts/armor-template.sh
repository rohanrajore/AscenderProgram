#!/usr/bin/env bash
# armor-template.sh — create the Model Armor template the agent's ARMOR layer uses, with
# the prompt-injection/jailbreak, Sensitive Data Protection, and malicious-URI filters on.
# Prints the template id to put in agent/agent.env (ARMOR_TEMPLATE / ARMOR_LOCATION).
#
#   PROJECT=my-project LOCATION=us-central1 bash scripts/armor-template.sh
#
# LIVE-UNTESTED: written against the documented Model Armor surface; NOT run while building
# the kit. Model Armor is regional — the template lives in a location such as us-central1,
# and the agent calls modelarmor.<LOCATION>.rep.googleapis.com.
set -euo pipefail

PROJECT="${PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
LOCATION="${LOCATION:-us-central1}"
TEMPLATE="${TEMPLATE:-bookshelf-armor}"
DRY_RUN="${DRY_RUN:-0}"

run() { echo "+ $*"; [ "$DRY_RUN" = "1" ] || "$@"; }

echo "# project=$PROJECT location=$LOCATION template=$TEMPLATE"
[ "$DRY_RUN" = "1" ] && echo "# DRY RUN — commands printed, not executed."
echo

# Enable the API (once per project).
run gcloud services enable modelarmor.googleapis.com --project="$PROJECT"

# Create the template with the three filters on. Console: Security > Model Armor >
# Templates > Create. The gcloud surface (2026) takes the filters as flags:
run gcloud model-armor templates create "$TEMPLATE" \
  --location="$LOCATION" \
  --project="$PROJECT" \
  --pi-and-jailbreak-filter-settings-enforcement=enabled \
  --pi-and-jailbreak-filter-settings-confidence-level=LOW_AND_ABOVE \
  --malicious-uri-filter-settings-enforcement=enabled \
  --basic-config-filter-enforcement=enabled \
  --template-metadata-log-sanitize-operations
# The Sensitive Data Protection (sdp) filter is turned on in basic mode by the flag above;
# for advanced mode, attach a DLP inspect template with:
#   --advanced-config-inspect-template=projects/$PROJECT/locations/$LOCATION/inspectTemplates/<id>

echo
echo "# Put these in agent/agent.env:"
echo "ARMOR_TEMPLATE=$TEMPLATE"
echo "ARMOR_LOCATION=$LOCATION"
echo
echo "# The agent then calls, for every turn and answer:"
echo "#   POST https://modelarmor.$LOCATION.rep.googleapis.com/v1/projects/$PROJECT/\\"
echo "#        locations/$LOCATION/templates/$TEMPLATE:sanitizeUserPrompt"
echo "#     body {\"userPromptData\":{\"text\":\"<evidence + turn>\"}}"
echo "#   POST ...:sanitizeModelResponse"
echo "#     body {\"modelResponseData\":{\"text\":\"<answer>\"}}"
echo "# A response with filterMatchState=MATCH_FOUND (pi_and_jailbreak / sdp /"
echo "# malicious_uris) is what makes the ARMOR layer refuse."
