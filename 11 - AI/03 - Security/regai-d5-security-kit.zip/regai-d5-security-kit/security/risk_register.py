#!/usr/bin/env python3
"""risk_register.py — the ranked risk register for the Bookshelf agent.

    python security/risk_register.py

Reads security/risks.yaml (the risks) and security/threat_model.yaml (to check every
STRIDE threat has a risk row), prints the register ranked by likelihood x impact, and
then the "accepted" rows on their own as the sign-off list — the risks a named owner has
accepted in writing (Lab B Part B).
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
RISKS = HERE / "risks.yaml"
THREATS = HERE / "threat_model.yaml"

BANDS = [(20, "critical"), (12, "high"), (6, "medium"), (0, "low")]


def band(score: int) -> str:
    for threshold, name in BANDS:
        if score >= threshold:
            return name
    return "low"


def main() -> int:
    risks = yaml.safe_load(RISKS.read_text(encoding="utf-8"))["risks"]
    for r in risks:
        r["score"] = int(r["likelihood"]) * int(r["impact"])
    risks.sort(key=lambda r: (-r["score"], r["id"]))

    print("# Risk register — Bookshelf agent")
    print(f"# {len(risks)} risks, ranked by likelihood x impact "
          "(L1-5 x I1-5). Source: security/risks.yaml\n")
    row = "%-4s %-40s %-6s %4s %-9s %-22s"
    print(row % ("id", "threat", "owasp", "LxI", "residual", "owner"))
    print("-" * 90)
    for r in risks:
        threat = r["threat"]
        threat = threat if len(threat) <= 40 else threat[:37] + "..."
        owner = r["owner"] if len(r["owner"]) <= 22 else r["owner"][:19] + "..."
        print(row % (r["id"], threat, r["owasp"],
                     f"{r['likelihood']}x{r['impact']}", r["residual"], owner))
    print("-" * 90)

    mitigated = sum(1 for r in risks if r["residual"] == "mitigated")
    accepted = [r for r in risks if r["residual"] == "accepted"]
    still_open = [r for r in risks if r["residual"] == "open"]
    print(f"\ntotals: {mitigated} mitigated, {len(accepted)} accepted, "
          f"{len(still_open)} open")
    if still_open:
        print("open (need a control or a decision): "
              + ", ".join(r["id"] for r in still_open))

    print("\n# Sign-off list — residual risks accepted in writing")
    if not accepted:
        print("(none accepted yet — Lab B Part B: accept one residual risk with a reason)")
    for r in accepted:
        reason = " ".join(str(r.get("accept_reason", "")).split())
        print(f"\n{r['id']}  {r['threat']}")
        print(f"    score {r['score']} ({band(r['score'])}), owner: {r['owner']}")
        print("    accepted because:")
        for line in textwrap.wrap(reason, width=80):
            print(f"      {line}")
        print("    signed: ______________________   date: __________")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
