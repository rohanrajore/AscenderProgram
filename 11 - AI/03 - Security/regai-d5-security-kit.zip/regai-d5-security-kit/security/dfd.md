# Data-flow diagram — Meridian Bookshelf assistant

This is the security artefact for Lab B Part A. It shows where data crosses a trust
boundary, because that is where a threat lives. Read it with `threat_model.yaml`: every
boundary here has a STRIDE row and a control there.

## The diagram

```mermaid
flowchart TB
    staff["Bank staff<br/>(priya / daniel / mlro)"]

    subgraph trusted["Trust boundary: our deployment"]
        agent["Agent loop<br/>(agent.py + defence layers)"]
        armor["Model Armor<br/>sanitize in / out"]
        model["Gemini<br/>(Vertex AI)"]
        guard["Tool guard<br/>provenance + allowlist + approval"]
        redact["DLP de-identify"]
        subgraph cloudrun["Cloud Run (IAM + ID token)"]
            mcp["bookshelf-mcp<br/>server (tools/list, tools/call)"]
        end
        api["bookshelf-api<br/>(stock, reservations)"]
        ds["Agent Search<br/>data store (policies)"]
        audit[("Locked audit bucket<br/>+ log view")]
    end

    author["Document author<br/>(can plant hidden text)"]:::untrusted
    ext["External attacker"]:::untrusted

    staff -- "1 user turn (E1)" --> armor
    armor -- "sanitised turn" --> agent
    agent <--> model
    agent -- "3 search / lookup / reserve (E3)" --> guard
    guard -- "tools/call + ID token" --> mcp
    mcp --> api
    mcp -- "answer query, caller filter" --> ds
    ds -- "2 retrieved evidence (E2)" --> armor
    author -. "plants hidden instruction" .-> ds
    ext -. "unauthenticated call (E4)" .-> mcp
    agent -- "decision record" --> redact
    redact -- "de-identified line" --> audit

    classDef untrusted fill:#fff,stroke:#b00,stroke-width:2px,stroke-dasharray:4 3;
```

## The flows, and where they cross a boundary

1. **User turn (E1)** — the caller's message crosses from the person into our deployment.
   *Control:* Model Armor `:sanitizeUserPrompt`; the caller's clearance filter is set from
   the verified identity in code, never by the model.

2. **Retrieved evidence (E2)** — content from the data store enters the model's context.
   This is the dangerous one: a document author (untrusted) can plant a hidden instruction
   that the model would otherwise trust. *Control:* WRAP labels it as data; Model Armor
   scans it; GUARD provenance stops any tool call justified only by it.

3. **Tool calls and results (E3)** — the model asks to read stock, search, reserve, or (the
   attack tool) email a record out. *Control:* allowlist + approval gate + GUARD provenance;
   the caller is the session's, not the model's; the MCP server takes identity from the token.

4. **MCP endpoint (E4)** — the server is reachable on Cloud Run. *Control:* Cloud Run IAM
   and ID-token verification (issuer `accounts.google.com`, audience, expiry).

5. **Audit write** — every decision is recorded. *Control:* DLP de-identify before write; a
   locked bucket makes the record immutable; the agent can write but reads go through a
   separate log view (`roles/logging.viewAccessor`), so the writer cannot alter the trail.

## What learners add in Lab B Part A

- The assets, actors and entry points specific to your deployment (region, project, who
  the callers really are).
- One STRIDE row per component in `threat_model.yaml` (a worked example per component is
  pre-filled) — look for the flow on this diagram, name the threat, name the control.
