"""tools_impl.py — the client-side tool implementations agent.py runs.

Three functions, each returning a plain dict that becomes the function_response:

    lookup_stock(book_id)                    GET  {BOOKSHELF_API_URL}/books/{id}
    reserve_book(book_id, copies, caller)    POST {BOOKSHELF_API_URL}/books/{id}/reserve
    search_bookshelf(question, caller)       the Day 1 :answer call, caller's filter

bookshelf-api is IAM-protected, so every call carries a Google identity token from
`gcloud auth print-identity-token`. The :answer endpoint takes an access token instead.

FAKE_API=1 replaces both services with an in-process copy of the catalogue (13 books,
3 copies each) kept in a small JSON file, so the whole kit runs without a network.
Learners never edit this file.

Day 4 adds the MCP section at the end: with MCP=on the tools come from a server's
tools/list and every call goes through tools/call, carrying the caller's own ID token.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import time
import uuid
from pathlib import Path

KIT = Path(__file__).resolve().parent
CALLERS = json.loads((KIT / "callers.json").read_text(encoding="utf-8"))
HTTP_TIMEOUT = 10  # seconds; a slow bookshelf-api surfaces as a timeout, not a hang

# The same 13 documents bookshelf-api loads from its corpus folder. Only the fields the
# tools return are kept; classification matters because the fake :answer applies the
# caller's filter the way the real data store does.
CATALOGUE = [
    ("HB-BLB-001", "Buy Local Bonds — Product Handbook", "restricted", "approved"),
    ("HB-LN-004", "Personal Loan — Product Handbook", "internal", "approved"),
    ("HB-SAV-002", "Everyday Saver Account — Product Handbook", "internal", "approved"),
    ("POL-AML-007", "Suspicious Activity Reporting Policy", "restricted", "approved"),
    ("POL-CR-014", "Credit Card Dispute and Chargeback Handling Policy", "confidential",
     "approved"),
    ("POL-CR-014-v2", "Credit Card Dispute and Chargeback Handling Policy (superseded)",
     "confidential", "superseded"),
    ("POL-DP-002", "Data Protection and Records Retention Policy", "internal",
     "approved"),
    ("POL-HR-005", "Business Expenses and Travel Policy", "internal", "approved"),
    ("PRC-COMP-009", "Complaints Handling Procedure (DRAFT — not for use)", "internal",
     "draft"),
    ("PRC-CR-030", "Card Block and Replacement Procedure", "internal", "approved"),
    ("PRC-IT-021", "Access Request and Privileged Access Procedure", "internal",
     "approved"),
    ("PRC-KYC-003", "Customer Identification and Verification Procedure", "internal",
     "approved"),
    ("PRC-OPS-011", "Branch Cash Handling Procedure", "confidential", "approved"),
]
TITLES = {row[0]: row[1] for row in CATALOGUE}

# The one grounded answer the fake :answer knows, taken from the Day 1 fixture
# (fixtures/answer-sample.json in regai-d1-gcp-kit). The document is confidential, so a
# caller whose filter stops at "internal" (priya) gets the refusal, as on Day 1.
FRM_ANSWER = (
    'Every dispute other than "duplicate or incorrect amount" requires a completed '
    "Cardholder Dispute Declaration, form FRM-CD-7, signed by the cardholder; an "
    "electronic signature through the app is acceptable. A dispute cannot progress to "
    "chargeback without FRM-CD-7 on file."
)
FRM_CHUNK = {
    "title": "Credit Card Dispute and Chargeback Handling Policy",
    "uri": "gs://BUCKET/corpus-html/POL-CR-014.html",
    "text": "## 6. Evidence and the cardholder declaration 6.1 Every dispute other than "
            '"duplicate or incorrect amount" requires a completed Cardholder Dispute '
            "Declaration, form FRM-CD-7, signed by the cardholder.",
}
REFUSAL = "The approved documents I can see do not answer this."
PREAMBLE = (
    "You are the Meridian Bookshelf assistant for bank staff. Answer only from the "
    "documents provided to you and cite the passage for every fact you state. Quote the "
    "exact rule, figure or time limit. If the documents do not answer the question, "
    f'reply with exactly: "{REFUSAL}" Never use outside knowledge and never guess.'
)


def fake_api() -> bool:
    return os.environ.get("FAKE_API", "0") == "1"


def is_dispute_question(question: str) -> bool:
    q = question.lower()
    return "form" in q and ("dispute" in q or "chargeback" in q)


# ------------------------------------------------------------------ fake catalogue
def _state_path() -> Path:
    return Path(os.environ.get("FAKE_API_STATE", KIT / ".fake-api.json"))


def _fresh_state() -> dict:
    return {"books": {bid: 3 for bid, *_ in CATALOGUE}, "keys": {}, "reservations": []}


def _load_state() -> dict:
    p = _state_path()
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return _fresh_state()


def _save_state(state: dict) -> None:
    _state_path().write_text(json.dumps(state, indent=1), encoding="utf-8")


def reset_catalogue() -> dict:
    """`agent.py --reset`: 13 books, 3 copies each (POST /reset on the real API)."""
    if fake_api():
        _save_state(_fresh_state())
        return {"status": "reset", "books": len(CATALOGUE), "api": "FAKE"}
    r = _requests().post(f"{_api_url()}/reset", headers=_id_headers(),
                         timeout=HTTP_TIMEOUT)
    r.raise_for_status()
    return r.json()


# ------------------------------------------------------------------ real transport
def _requests():
    import requests  # imported here so FAKE_API=1 runs without it installed
    return requests


def _api_url() -> str:
    url = os.environ.get("BOOKSHELF_API_URL", "").rstrip("/")
    if not url:
        raise RuntimeError("BOOKSHELF_API_URL is empty in agent.env")
    return url


_TOKENS: dict[str, str] = {}


def _gcloud_token(kind: str) -> str:
    """identity token for Cloud Run, access token for Discovery Engine; one per process.
    BOOKSHELF_TOKEN, when set, is sent as-is (a local bookshelf-api, no gcloud)."""
    if kind == "identity" and os.environ.get("BOOKSHELF_TOKEN"):
        return os.environ["BOOKSHELF_TOKEN"]
    if kind not in _TOKENS:
        cmd = ["gcloud", "auth", f"print-{kind}-token"]
        _TOKENS[kind] = subprocess.check_output(cmd, text=True).strip()
    return _TOKENS[kind]


def _id_headers() -> dict:
    return {"Authorization": f"Bearer {_gcloud_token('identity')}"}


def _http_error(r) -> dict:
    """Turn a non-2xx response into the dict the model (or the loop) sees."""
    try:
        detail = r.json().get("detail", r.text)
    except ValueError:
        detail = r.text[:200]
    return {"error": f"HTTP {r.status_code} from bookshelf-api: {detail}"}


# ------------------------------------------------------------------ the tools
def lookup_stock(book_id: str) -> dict:
    """Read-only: how many copies of one document are available right now."""
    if fake_api():
        state = _load_state()
        if book_id not in state["books"]:
            return {"error": f"HTTP 404 from bookshelf-api: no book {book_id}"}
        return {"book_id": book_id, "title": TITLES[book_id],
                "copies_available": state["books"][book_id], "copies_total": 3}
    r = _requests().get(f"{_api_url()}/books/{book_id}", headers=_id_headers(),
                        timeout=HTTP_TIMEOUT)
    if not r.ok:
        return _http_error(r)
    b = r.json()
    return {"book_id": b["id"], "title": b["title"],
            "copies_available": b["copies_available"], "copies_total": b["copies_total"]}


def reserve_book(book_id: str, copies: int, caller: str,
                 idempotency_key: str | None = None) -> dict:
    """Side effect: reserve 1-3 copies for a member of staff. The Idempotency-Key header,
    when the loop passes one, lets bookshelf-api recognise a retry of the same request."""
    if fake_api():
        return _fake_reserve(book_id, copies, caller, idempotency_key)
    headers = _id_headers()
    if idempotency_key:
        headers["Idempotency-Key"] = idempotency_key
    r = _requests().post(f"{_api_url()}/books/{book_id}/reserve", headers=headers,
                         json={"staff_id": caller, "copies": copies},
                         timeout=HTTP_TIMEOUT)
    if not r.ok:
        return _http_error(r)
    b = r.json()
    return {"reservation_id": b["id"], "book_id": b["book_id"], "copies": b["copies"],
            "copies_available": b["copies_available"],
            "replayed": b.get("replayed", False)}


def _fake_reserve(book_id: str, copies, caller: str, key: str | None) -> dict:
    """Mirrors bookshelf-api's /reserve exactly: 404, 422 on copies, 409, key replay."""
    state = _load_state()
    if book_id not in state["books"]:
        return {"error": f"HTTP 404 from bookshelf-api: no book {book_id}"}
    if not isinstance(copies, int) or not 1 <= copies <= 3:
        return {"error": "HTTP 422 from bookshelf-api: copies: Input should be "
                         "between 1 and 3"}
    if key and key in state["keys"]:
        return {**state["keys"][key], "replayed": True}
    if state["books"][book_id] < copies:
        return {"error": f"HTTP 409 from bookshelf-api: only {state['books'][book_id]} "
                         "copies available"}
    state["books"][book_id] -= copies
    n = len(state["reservations"]) + 1
    out = {"reservation_id": f"res_fake{n:04d}", "book_id": book_id, "copies": copies,
           "copies_available": state["books"][book_id]}
    state["reservations"].append({**out, "staff_id": caller, "created": time.time()})
    if key:
        state["keys"][key] = out
    _save_state(state)
    return {**out, "replayed": False}


def search_bookshelf(question: str, caller: str) -> dict:
    """The Day 1 answer endpoint as a function tool. The filter string comes from
    callers.json in this code; the model names the caller, it never writes a filter."""
    who = CALLERS.get(caller)
    if not who:
        return {"error": f"unknown caller {caller!r}; see callers.json"}
    if fake_api():
        return _fake_answer(question, who)
    project, app_id = os.environ.get("PROJECT_ID", ""), os.environ.get("APP_ID", "")
    if not project or not app_id:
        return {"error": "PROJECT_ID and APP_ID must be set in agent.env"}
    url = (f"https://discoveryengine.googleapis.com/v1/projects/{project}/locations/"
           f"global/collections/default_collection/engines/{app_id}/servingConfigs/"
           "default_search:answer")
    body = {
        "query": {"text": question},
        "answerGenerationSpec": {
            "modelSpec": {"modelVersion": os.environ.get("ANSWER_MODEL", "stable")},
            "promptSpec": {"preamble": PREAMBLE},
            "includeCitations": True, "ignoreLowRelevantContent": True,
            "ignoreNonAnswerSeekingQuery": False,
        },
        "searchSpec": {"searchParams": {"maxReturnResults": 5, "filter": who["filter"]}},
    }
    headers = {"Authorization": f"Bearer {_gcloud_token('access')}",
               "X-Goog-User-Project": project}
    r = _requests().post(url, headers=headers, json=body, timeout=30)
    if not r.ok:
        return {"error": f"HTTP {r.status_code} from :answer: {r.text[:200]}"}
    a = r.json().get("answer", {})
    refs = a.get("references", [])
    cites = []
    for i, ref in enumerate(refs):
        md = ref.get("chunkInfo", {}).get("documentMetadata", {})
        cites.append({"n": i + 1, "title": md.get("title", "?"),
                      "uri": md.get("uri", "")})
    return {"answer": a.get("answerText", "") or REFUSAL, "citations": cites,
            "skipped": a.get("answerSkippedReasons", []), "filter": who["filter"]}


def _fake_answer(question: str, who: dict) -> dict:
    if is_dispute_question(question) and "confidential" in who["filter"]:
        return {"answer": FRM_ANSWER, "citations": [{"n": 1, **FRM_CHUNK}], "skipped": [],
                "filter": who["filter"]}
    # Every other question, or a caller whose filter excludes POL-CR-014.
    return {"answer": REFUSAL, "citations": [], "skipped": ["NO_RELEVANT_CONTENT"],
            "filter": who["filter"]}


def new_idempotency_key() -> str:
    """One key per logical request; the loop reuses it for every retry of that request."""
    return f"agent-{uuid.uuid4().hex[:12]}"


IMPLEMENTATIONS = {
    "lookup_stock": lookup_stock,
    "reserve_book": reserve_book,
    "search_bookshelf": search_bookshelf,
}


# ------------------------------------------------------------------ MCP (Day 4)
# MCP=on: the tool definitions come from the server (tools/list) and every call runs
# there (tools/call). The loop in agent.py does not change; these are what impl_for()
# returns for a tool the server declared. Each function opens a short-lived connection:
# the server is stateless, so a call is two HTTP requests (server/discover, then the
# call) and nothing is kept between them.
def mcp_token() -> str | None:
    """The caller's own Google ID token, the same one a person shows Cloud Run. The
    server maps its email to a caller; the model never names one. MCP_AUTH=off sends
    nothing (a local server started with AUTH=off)."""
    if os.environ.get("MCP_AUTH", "on").lower() in ("off", "0", "false", "no"):
        return None
    return _gcloud_token("identity")


def _mcp_client(url: str):
    """An `mcp.Client` over Streamable HTTP with the Authorization header set. Imported
    here so the Day 2 and Day 3 labs run without the mcp package installed."""
    from mcp import Client
    from mcp.client.streamable_http import streamable_http_client
    from mcp.shared._httpx_utils import create_mcp_http_client
    token = mcp_token()
    http = create_mcp_http_client(
        headers={"Authorization": f"Bearer {token}"} if token else None)
    return http, Client(streamable_http_client(url, http_client=http))


def _run(coro):
    """asyncio.run, re-raising the first real error out of anyio's ExceptionGroups so
    the loop's failure handling sees `MCPError: 401 …`, not `ExceptionGroup`."""
    try:
        return asyncio.run(coro)
    except BaseExceptionGroup as group:
        err = group
        while isinstance(err, BaseExceptionGroup):
            err = err.exceptions[0]
        raise err from None


def mcp_list_tools(url: str) -> tuple[list[dict], dict]:
    """tools/list in the shape the Day 2 registry expects — [{name, description,
    parameters}] — plus the server's cache hints. "read_only" comes from the tool's
    annotations: the server says what changes things, so the loop's approval gate
    applies to reserve_book here exactly as it did when tools.json declared it."""
    async def go():
        http, client = _mcp_client(url)
        async with http, client as c:
            r = await c.list_tools()
            tools = [{"name": t.name, "description": t.description or "",
                      "parameters": t.input_schema, "mcp": True,
                      "read_only": bool(t.annotations and t.annotations.read_only_hint)}
                     for t in r.tools]
            hints = {"ttlMs": r.ttl_ms, "cacheScope": r.cache_scope,
                     "protocol": c.protocol_version}
            return tools, hints
    return _run(go())


def mcp_call_tool(url: str, name: str, idempotency_key: str | None = None,
                  **args) -> dict:
    """tools/call; the structured result becomes the function_response. A tool error
    (unknown tool, bad arguments) comes back as {"error": …} like any other tool."""
    async def go():
        http, client = _mcp_client(url)
        async with http, client as c:
            meta = {"idempotencyKey": idempotency_key} if idempotency_key else None
            r = await c.call_tool(name, args, meta=meta)
            text = " ".join(getattr(b, "text", "") for b in r.content).strip()
            if r.is_error:
                return {"error": text[:200]}
            if r.structured_content is not None:
                return r.structured_content
            return {"text": text}
    return _run(go())
