#!/usr/bin/env bash
# gemini-config.sh — put the two MCP servers into ~/.gemini/settings.json.
#
#   bash scripts/gemini-config.sh          # agent-search + bookshelf (once deployed)
#   INCLUDE_TOOLS=lookup_stock,search_bookshelf bash scripts/gemini-config.sh   # Part D
#
# "agent-search": Google's Agent Search MCP server, reached with your own Google
#   credentials (authProviderType google_credentials, cloud-platform scope).
# "bookshelf":    our server on Cloud Run, reached with a Google ID token in the
#   Authorization header. The token lasts about an hour: when Gemini CLI reports a 401,
#   run this script again and the token is fresh.
# Other settings in the file are kept; only mcpServers.agent-search and
# mcpServers.bookshelf are written.
set -euo pipefail
PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-south1}"
[ -n "$PROJECT" ] || { echo "No project: gcloud config set project <id>"; exit 1; }

URL="${BOOKSHELF_MCP_URL:-$(gcloud run services describe bookshelf-mcp \
  --region "$REGION" --project "$PROJECT" --format='value(status.url)' 2>/dev/null \
  || true)}"
TOKEN=""
[ -z "$URL" ] || TOKEN="$(gcloud auth print-identity-token)"

mkdir -p ~/.gemini
SETTINGS=~/.gemini/settings.json
[ -f "$SETTINGS" ] || echo '{}' > "$SETTINGS"

PROJECT="$PROJECT" URL="$URL" TOKEN="$TOKEN" INCLUDE_TOOLS="${INCLUDE_TOOLS:-}" \
SETTINGS="$SETTINGS" python3 - <<'EOF'
import json, os
path = os.environ["SETTINGS"]
settings = json.load(open(path))
servers = settings.setdefault("mcpServers", {})
servers["agent-search"] = {
    "httpUrl": "https://discoveryengine.googleapis.com/mcp",
    "authProviderType": "google_credentials",
    "oauth": {"scopes": ["https://www.googleapis.com/auth/cloud-platform"]},
    "headers": {"X-Goog-User-Project": os.environ["PROJECT"]},
    "timeout": 60000,
}
url = os.environ["URL"]
if url:
    bookshelf = {
        "httpUrl": f"{url}/mcp",
        "headers": {"Authorization": f"Bearer {os.environ['TOKEN']}"},
        "timeout": 30000,
        "trust": False,
    }
    include = [t for t in os.environ["INCLUDE_TOOLS"].split(",") if t]
    if include:
        bookshelf["includeTools"] = include   # the client-side fence (Part D)
    servers["bookshelf"] = bookshelf
else:
    servers.pop("bookshelf", None)
json.dump(settings, open(path, "w"), indent=2)
print(f"wrote {path}")
for name, s in servers.items():
    extra = f"  includeTools={s['includeTools']}" if "includeTools" in s else ""
    print(f"  {name}: {s.get('httpUrl', s.get('url', s.get('command')))}{extra}")
if not url:
    print("  (bookshelf not added: no bookshelf-mcp service found yet — run this again "
          "after bookshelf-mcp/deploy.sh)")
EOF
echo "Start Gemini CLI with: gemini   then type /mcp to see both servers and their tools."
