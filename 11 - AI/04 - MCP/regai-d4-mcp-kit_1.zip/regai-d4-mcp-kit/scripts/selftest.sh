#!/usr/bin/env bash
# selftest.sh — every part of the Day 4 lab, offline: the MCP server runs on this
# machine with AUTH=off (or AUTH=on with no token, to see the 401) and FAKE_API=1; the
# agent runs with FAKE_MODEL=1. Nothing touches Google Cloud.
#
#   bash scripts/selftest.sh                       # run and check
#   MEASURED=out.txt bash scripts/selftest.sh      # also keep every printout in out.txt
#
# Needs: python3 with the mcp package (pip install mcp), uvicorn (it comes with mcp),
# google-auth and cryptography for the token check. Ports 8765 and 8766 must be free
# (PORT_A / PORT_B override them). The Day 2 kit is not needed: the agent-patch files
# run from a temporary folder with callers.json beside them.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
SRV="$KIT/bookshelf-mcp"
PY="${PYTHON:-python3}"
PORT_A="${PORT_A:-8765}"
PORT_B="${PORT_B:-8766}"
TMP="$(mktemp -d)"
LOG="$TMP/log.txt"
AGENT="$TMP/agent"
PASS=0; FAIL=0; LAST=""; SERVER_PID=""; SERVER_LOG=""; SERVER_PORT=""
export PYTHONDONTWRITEBYTECODE=1
cd "$KIT"   # so the printed commands work as written from the kit folder
unset AUTH EXPOSE_RESERVE FAKE_API SERVICE_URL PORT TOOLS MCP MCP_URL MCP_AUTH

cleanup() { stop_server; rm -rf "$TMP"; }
trap cleanup EXIT

log() { printf '%s\n' "$*" | tee -a "$LOG"; }
expect() {  # expect DESCRIPTION REGEX — the last output must contain a match
  if grep -qE -- "$2" <<<"$LAST"; then echo "   ok   $1"; PASS=$((PASS + 1))
  else echo "   FAIL $1  (wanted /$2/)"; FAIL=$((FAIL + 1)); fi
}
refute() {
  if grep -qE -- "$2" <<<"$LAST"; then echo "   FAIL $1  (found /$2/)"; FAIL=$((FAIL + 1))
  else echo "   ok   $1"; PASS=$((PASS + 1)); fi
}
quoted() {
  local out="" a
  for a in "$@"; do
    [[ "$a" == *" "* || "$a" == *"{"* ]] && out+="'$a' " || out+="$a "
  done
  printf '%s' "${out% }"
}
# run NAME [VAR=value ...] -- COMMAND ARGS...   runs it, prints and records the output
run() {
  local name="$1"; shift
  local envs=()
  while [[ "$1" != "--" ]]; do envs+=("$1"); shift; done; shift
  log "## $name"
  local shown=("$@"); [[ "${shown[0]}" == "$PY" ]] && shown[0]=python  # as typed
  log "\$ ${envs[*]:+${envs[*]} }$(quoted "${shown[@]}")"
  LAST="$(env "${envs[@]}" "$@" 2>&1)"
  log "$LAST"; log ""
}

# The server is started exactly as the Dockerfile's CMD runs it — `uvicorn server:app
# --host 0.0.0.0 --port ${PORT:-8080}` — with PORT set, as Cloud Run sets it.
start_server() {  # start_server LABEL PORT [VAR=value ...]
  local label="$1" port="$2"; shift 2
  SERVER_LOG="$TMP/server-$port.log"; SERVER_PORT="$port"
  if listening "$port"; then
    echo "port $port is already in use — stop that server or set PORT_A/PORT_B"; exit 1
  fi
  log "## server: $label"
  log "\$ cd bookshelf-mcp && $* PORT=$port uvicorn server:app --host 0.0.0.0" \
      "--port \${PORT:-8080}"
  (cd "$SRV" && env "$@" PORT="$port" FAKE_API_STATE="$TMP/state-$port.json" \
     uvicorn server:app --host 0.0.0.0 --port "$port" >"$SERVER_LOG" 2>&1) &
  SERVER_PID=$!
  local i
  for i in $(seq 1 50); do listening "$port" && break; sleep 0.2; done
  log "(server up on :$port — stdout below is what Cloud Logging would receive)"
  log ""
}
stop_server() {
  [[ -n "$SERVER_PID" ]] || return 0
  # The subshell's child is the uvicorn process; stop both, then wait for the port to
  # close so the next server can bind it.
  pkill -TERM -P "$SERVER_PID" 2>/dev/null; kill "$SERVER_PID" 2>/dev/null
  wait "$SERVER_PID" 2>/dev/null; SERVER_PID=""
  local i
  for i in $(seq 1 50); do listening "$SERVER_PORT" || return 0; sleep 0.2; done
}
# A TCP connect, not an HTTP request: a probe of /mcp would itself be logged as a call.
listening() { (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; }
server_log() {  # the server's own stdout: the JSON audit lines
  log "## server stdout (audit lines) — $1"
  LAST="$(grep '"event"' "$SERVER_LOG" || true)"
  log "$LAST"; log ""
}

log "# Day 4 measured outputs — offline (AUTH=off or no token, FAKE_API=1, FAKE_MODEL=1)"
log "# generated $(date -u +%Y-%m-%dT%H:%MZ) by scripts/selftest.sh on $(uname -s)."
MCP_VERSION="$($PY -c 'import importlib.metadata as m; print(m.version("mcp"))')"
log "# mcp $MCP_VERSION, python $($PY -c 'import sys; print(sys.version.split()[0])')"
log "# The server is the real server.py; the catalogue is in-process; the model is the"
log "# scripted stand-in, not Gemini. URLs are localhost; live runs show the Cloud Run"
log "# URL."
log ""

# ================================================================ the image
log "# ---------------- the container"
run "python -m py_compile (what the image would run)" -- \
  "$PY" -m py_compile bookshelf-mcp/server.py bookshelf-mcp/tools_impl.py
expect "compiles" "^$"
if docker info >/dev/null 2>&1; then
  run "docker build" -- docker build -q -t bookshelf-mcp:selftest bookshelf-mcp
  expect "image built" "sha256|bookshelf-mcp"
else
  log "## docker build: skipped — no docker daemon here; the CMD is exercised below as a"
  log "## plain command instead (uvicorn server:app --host 0.0.0.0 --port \$PORT)."
  log ""
fi

# ================================================================ Part B offline
log "# ---------------- Lab Part B — our server: two tools, a call, the agent through MCP"
mkdir -p "$AGENT"
cp agent-patch/agent.py agent-patch/tools_impl.py bookshelf-mcp/callers.json "$AGENT/"
URL_A="http://localhost:$PORT_A/mcp"
start_server "AUTH=off FAKE_API=1 (local run)" "$PORT_A" AUTH=off FAKE_API=1
CALL=("$PY" scripts/mcp-call.py)

run "B-1 tools/list, no token" -- "${CALL[@]}" --url "$URL_A" --token none --list
expect "server/discover answered (2026-07-28)" \
  "server/discover: versions=\['2026-07-28'\]"
expect "two tools" "tools/list: 2 tools"
expect "cache hints on tools/list" "ttlMs=300000 cacheScope=public"
expect "lookup_stock with its description" "^- lookup_stock"
expect "search_bookshelf" "^- search_bookshelf"
refute "reserve_book withheld (EXPOSE_RESERVE=off)" "reserve_book"
expect "schema shown" 'book_id\*: \{"type": "string"\}'

run "B-1r resources/list and resources/read" -- "${CALL[@]}" --url "$URL_A" \
  --token none --resources --read bookshelf://catalogue
expect "one resource" "resources/list: 1 resources"
expect "the catalogue resource" "bookshelf://catalogue"
expect "cache hints on resources/read" "resources/read bookshelf://catalogue ttlMs=300000 cacheScope=public"
expect "the index, not document text" '"id": "PRC-KYC-003"'

run "B-1p prompts/list and prompts/get" -- "${CALL[@]}" --url "$URL_A" \
  --token none --prompts --get policy_lookup '{"topic": "card disputes"}'
expect "one prompt" "prompts/list: 1 prompts"
expect "the policy_lookup prompt" "^- policy_lookup"
expect "the filled prompt message" "approved guidance on: card disputes"

run "B-2 tools/call lookup_stock" -- "${CALL[@]}" --url "$URL_A" --token none \
  --call lookup_stock '{"book_id": "PRC-KYC-003"}'
expect "structured result" '"copies_available": 3, "copies_total": 3'

run "B-3 tools/call with a bad argument" -- "${CALL[@]}" --url "$URL_A" --token none \
  --call lookup_stock '{"book_id": 5}'
expect "the server validates the schema" "Input should be a valid string"
expect "reported as isError" "isError: true"

AG=(FAKE_MODEL=1 TOOLS=on MCP=on "MCP_URL=$URL_A" MCP_AUTH=off "AGENT_ENV=/nonexistent")
cd "$AGENT"
run "B-4 agent.py MCP=on: a lookup through MCP" "${AG[@]}" -- \
  "$PY" agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
expect "tools from the server" "tools from: $URL_A \(tools/list, 2 tools, ttlMs=300000"
expect "function_call" 'function_call lookup_stock\(\{"book_id": "PRC-KYC-003"\}\)'
expect "ran through tools/call" '⚙ run lookup_stock.*"copies_available": 3'
expect "answer" "text: PRC-KYC-003 — Customer Identification and Verification Procedure"

run "B-5 agent.py MCP=on: ask to reserve — no such tool" "${AG[@]}" -- \
  "$PY" agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
expect "only the two tools were offered" 'tools=\[lookup_stock, search_bookshelf\]'
expect "the model says so" "no tool for it is available"
refute "nothing ran" "⚙ run"

run "B-6 agent.py MCP=on: a policy question through search_bookshelf" "${AG[@]}" -- \
  "$PY" agent.py --user daniel \
  "Which form must a cardholder sign before a dispute can go to chargeback?"
expect "search ran on the server" "⚙ run search_bookshelf"
expect "the SERVER chose the filter: no identity → priya's" \
  'classification: ANY\(\\"internal\\"\)"\}'
cd "$KIT"
server_log "Part B"
expect "one JSON line per call, caller anonymous (AUTH=off)" \
  '"tool": "lookup_stock", "args": \{"book_id": "PRC-KYC-003"\}, "caller": "anonymous", '\
'"ok": true'
expect "the bad call logged as not ok" \
  '"ok": false, "ms": [0-9]+, "error": "Error executing tool'
stop_server

# ================================================================ Part D offline
log "# ---------------- Lab Part D — the withheld tool, then identity"
URL_B="http://localhost:$PORT_B/mcp"
start_server "EXPOSE_RESERVE=on AUTH=off FAKE_API=1" "$PORT_B" \
  AUTH=off EXPOSE_RESERVE=on FAKE_API=1
run "C-1 tools/list with EXPOSE_RESERVE=on" -- \
  "${CALL[@]}" --url "$URL_B" --token none --list
expect "three tools" "tools/list: 3 tools"
expect "reserve_book, not read-only" '^- reserve_book  \{"readOnlyHint": false'
expect "copies 1..3 in the schema" 'copies\*: .*"maximum": 3.*"minimum": 1' 

AG=(FAKE_MODEL=1 TOOLS=on MCP=on "MCP_URL=$URL_B" MCP_AUTH=off "AGENT_ENV=/nonexistent")
cd "$AGENT"
run "C-2 agent.py: the same request now reserves" "${AG[@]}" -- \
  "$PY" agent.py --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
expect "three tools from the server" "tools/list, 3 tools"
expect "reserve_book ran through tools/call" '⚙ run reserve_book.*"copies_available": 1'
expect "confirmation" "Reserved 2 of PRC-KYC-003"

run "C-3 agent.py: Day 3's approval gate, now in front of a server" "${AG[@]}" \
  APPROVE=ask -- "$PY" agent.py --user daniel \
  "Reserve one copy of PRC-KYC-003 for daniel" < <(echo n)
expect "the card" "approval needed"
expect "stock on the card came through MCP" '│ copies   1  \(1 available now, 0 after\)'
expect "declined" "blocked: declined by approver"

run "C-4 agent.py: VALIDATE=on rejects five copies before any call" "${AG[@]}" \
  VALIDATE=on -- "$PY" agent.py --user daniel \
  "Reserve five copies of PRC-KYC-003 for daniel"
expect "blocked in code" "blocked: invalid args: copies=5 > maximum 3"
cd "$KIT"
server_log "Part D, EXPOSE_RESERVE=on"
expect "the reservation is in the audit log" \
  '"tool": "reserve_book", "args": \{"book_id": "PRC-KYC-003", "copies": 2\}, '\
'"caller": "anonymous", "ok": true'
stop_server

start_server "AUTH=on FAKE_API=1 — identity required" "$PORT_B" AUTH=on FAKE_API=1 \
  SERVICE_URL=https://bookshelf-mcp-example.a.run.app
run "C-5 tools/list with no token → 401" -- \
  "${CALL[@]}" --url "$URL_B" --token none --list
expect "refused" "error: 401: no valid Google ID token"
expect "the HTTP status" "http: 401 Unauthorized"
refute "no tools shown" "tools/list:"

cd "$AGENT"
run "C-6 agent.py with MCP_AUTH=off against AUTH=on" FAKE_MODEL=1 TOOLS=on MCP=on \
  "MCP_URL=$URL_B" MCP_AUTH=off "AGENT_ENV=/nonexistent" -- \
  "$PY" agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
expect "stops at tools/list" "tools/list failed: 401"
cd "$KIT"
server_log "Part D, AUTH=on, no token"
expect "anonymous, not ok, in the audit log" \
  '"caller": "anonymous", "ok": false, "ms": 0, "error": "401: no valid Google ID token'
expect "the probe named the method" '"method": "server/discover"'
stop_server

# The token check itself, with Google's signing certificates replaced by a key made
# here: what the server accepts and what it refuses. This is the one live-only piece
# that can be exercised offline.
log "## C-7 verify_id_token: signature, issuer, audience, expiry (certificates mocked)"
log "\$ python - <<'EOF' … (see scripts/selftest.sh)"
LAST="$(cd "$SRV" && SERVICE_URL=https://bookshelf-mcp-example.a.run.app FAKE_API=1 \
  "$PY" - <<'EOF' 2>&1
import sys, time
sys.path.insert(0, ".")
try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
except ImportError:
    print("skipped: pip install cryptography"); sys.exit(0)
from google.auth import crypt, jwt
from google.oauth2 import id_token
import server
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                        serialization.NoEncryption())
pub = key.public_key().public_bytes(serialization.Encoding.PEM,
                                    serialization.PublicFormat.SubjectPublicKeyInfo)
signer = crypt.RSASigner.from_string(pem, key_id="k1")
id_token._fetch_certs = lambda request, url: {"k1": pub.decode()}   # Google's certs
now = int(time.time())
def token(aud, iss="https://accounts.google.com", exp=now + 600):
    claims = {"iss": iss, "aud": aud, "sub": "1", "email": "daniel@example.com",
              "iat": now, "exp": exp}
    return jwt.encode(signer, claims).decode()
cases = [("aud = SERVICE_URL", token(server.SERVICE_URL)),
         ("aud = gcloud client id (a person's token)", token(server.GCLOUD_CLIENT_ID)),
         ("aud = another service", token("https://other-service.a.run.app")),
         ("issuer not Google", token(server.SERVICE_URL, iss="https://evil.example")),
         ("expired", token(server.SERVICE_URL, exp=now - 10))]
for label, t in cases:
    try:
        print(f"{label:44} -> accepted, email {server.verify_id_token(t)['email']}")
    except Exception as e:
        print(f"{label:44} -> refused: {type(e).__name__}: {str(e)[:60]}")
EOF
)"
log "$LAST"; log ""
expect "service URL accepted" "aud = SERVICE_URL .*-> accepted, email daniel@example.com"
expect "gcloud user token accepted" "gcloud client id.*-> accepted"
expect "other audience refused" \
  "another service .*-> refused: InvalidValue: Token has wrong audience"
expect "wrong issuer refused" \
  "issuer not Google .*-> refused: GoogleAuthError: Wrong issuer"
expect "expired refused" "expired .*-> refused: InvalidValue: Token expired"

# ================================================================ scripts
log "# ---------------- scripts"
run "audit-log.sh on a saved entries file (the table Part D reads)" -- \
  bash scripts/audit-log.sh 20 scripts/sample-entries.json
expect "table" "time \(UTC\) +caller +tool +ok"
expect "a refused request shows as FAIL" "anonymous .*\(server/discover\) FAIL"
echo '{"theme": "keep-me"}' > "$TMP/settings.json"
MERGE="$(sed -n "/python3 - <<'EOF'\$/,/^EOF\$/p" scripts/gemini-config.sh | sed '1d;$d')"
log "## gemini-config.sh: the python merge step, on a settings file with other keys"
log "\$ SETTINGS=~/.gemini/settings.json PROJECT=demo-project TOKEN=ID_TOKEN" \
    "URL=https://bookshelf-mcp-example.a.run.app python - <<'EOF'" \
    "(the merge step of scripts/gemini-config.sh)"
LAST="$(env "SETTINGS=$TMP/settings.json" PROJECT=demo-project TOKEN=ID_TOKEN \
  INCLUDE_TOOLS= URL=https://bookshelf-mcp-example.a.run.app "$PY" -c "$MERGE" 2>&1)"
log "$LAST"; log ""
expect "wrote both servers" "agent-search: https://discoveryengine.googleapis.com/mcp"
expect "bookshelf with /mcp" "bookshelf: https://bookshelf-mcp-example.a.run.app/mcp"
LAST="$(cat "$TMP/settings.json")"
expect "other settings kept" '"theme": "keep-me"'
expect "the token in the Authorization header" '"Authorization": "Bearer ID_TOKEN"'
expect "google_credentials for agent-search" '"authProviderType": "google_credentials"'

# ================================================================ result
echo
echo "selftest: $PASS passed, $FAIL failed"
if [[ -n "${MEASURED:-}" ]]; then cp "$LOG" "$MEASURED"; echo "printouts: $MEASURED"; fi
[[ $FAIL -eq 0 ]]
