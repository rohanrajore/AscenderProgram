#!/usr/bin/env python3
"""mcp-call.py — one-shot MCP client: see tools/list and call one tool, from a terminal.

    python scripts/mcp-call.py --url URL --list
    python scripts/mcp-call.py --url URL --call lookup_stock '{"book_id": "PRC-KYC-003"}'
    python scripts/mcp-call.py --url URL --resources                # resources/list
    python scripts/mcp-call.py --url URL --read bookshelf://catalogue
    python scripts/mcp-call.py --url URL --prompts                  # prompts/list
    python scripts/mcp-call.py --url URL --get policy_lookup '{"topic": "card disputes"}'
    python scripts/mcp-call.py --url URL --token none --list        # no credential at all
    python scripts/mcp-call.py --url https://discoveryengine.googleapis.com/mcp \
        --token "$(gcloud auth print-access-token)" \
        --header "X-Goog-User-Project: $P" --list

--token auto (default) sends a Google ID token from `gcloud auth print-identity-token`;
--token none sends nothing; --token <string> sends that string (Agent Search wants an
access token). --header adds any other header. URL is the MCP endpoint (…/mcp). It
prints what the server said about itself (server/discover), then each tool with its
description and input schema, with the 2026-07-28 cache hints (ttlMs, cacheScope) when
the server sends them.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import subprocess
import sys

from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from mcp.shared._httpx_utils import create_mcp_http_client
from mcp.shared.exceptions import MCPError


def token_for(choice: str) -> str | None:
    if choice == "none":
        return None
    if choice == "auto":
        return subprocess.check_output(["gcloud", "auth", "print-identity-token"],
                                       text=True).strip()
    return choice


def leaves(e: BaseException):
    """The client raises ExceptionGroups (anyio task groups); walk to the real errors."""
    if isinstance(e, BaseExceptionGroup):
        for sub in e.exceptions:
            yield from leaves(sub)
    else:
        yield e


def print_discover(client: Client) -> None:
    d = client.session.discover_result
    info = client.server_info
    if d is None:
        # An older server: the initialize handshake was used instead of server/discover.
        print(f"server/discover: not supported — initialize handshake, "
              f"protocol {client.protocol_version}")
    else:
        print(f"server/discover: versions={d.supported_versions} ttlMs={d.ttl_ms} "
              f"cacheScope={d.cache_scope}")
    if info:
        print(f"server: {info.name} {info.version}")
    if client.instructions:
        print(f"instructions: {client.instructions}")
    caps = client.server_capabilities.model_dump(by_alias=True, exclude_none=True)
    print(f"capabilities: {json.dumps(caps)}")


def print_tools(result) -> None:
    hints = f" ttlMs={result.ttl_ms} cacheScope={result.cache_scope}" \
        if result.ttl_ms is not None else ""
    print(f"tools/list: {len(result.tools)} tools{hints}")
    for t in result.tools:
        ann = t.annotations.model_dump(by_alias=True, exclude_none=True) \
            if t.annotations else {}
        print(f"- {t.name}" + (f"  {json.dumps(ann)}" if ann else ""))
        for line in (t.description or "").splitlines():
            print(f"    {line}")
        props = t.input_schema.get("properties", {})
        required = t.input_schema.get("required", [])
        for name, p in props.items():
            extra = {k: v for k, v in p.items() if k not in ("title", "description")}
            print(f"    {name}{'*' if name in required else ''}: "
                  f"{json.dumps(extra)}  {p.get('description', '')}".rstrip())


def print_resources(result) -> None:
    hints = f" ttlMs={result.ttl_ms} cacheScope={result.cache_scope}" \
        if getattr(result, "ttl_ms", None) is not None else ""
    print(f"resources/list: {len(result.resources)} resources{hints}")
    for r in result.resources:
        print(f"- {r.uri}  ({r.name})  {r.mime_type or ''}".rstrip())
        for line in (r.description or "").splitlines():
            print(f"    {line}")


def print_prompts(result) -> None:
    print(f"prompts/list: {len(result.prompts)} prompts")
    for p in result.prompts:
        print(f"- {p.name}")
        for line in (p.description or "").splitlines():
            print(f"    {line}")
        for arg in (p.arguments or []):
            req = "*" if getattr(arg, "required", False) else ""
            print(f"    {arg.name}{req}: {arg.description or ''}".rstrip())


async def main(a) -> int:
    token = token_for(a.token)
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    for h in a.header:
        k, _, v = h.partition(":")
        headers[k.strip()] = v.strip()
    headers = headers or None
    print(f"url: {a.url}  token: {a.token if not token else 'sent'}")
    http = create_mcp_http_client(headers=headers)
    try:
        async with http, Client(streamable_http_client(a.url, http_client=http)) as c:
            print_discover(c)
            did = False
            if a.resources:
                print_resources(await c.list_resources()); did = True
            if a.read:
                rr = await c.read_resource(a.read)
                print(f"resources/read {a.read}"
                      + (f" ttlMs={rr.ttl_ms} cacheScope={rr.cache_scope}"
                         if getattr(rr, "ttl_ms", None) is not None else ""))
                for block in rr.contents:
                    print(getattr(block, "text", block))
                did = True
            if a.prompts:
                print_prompts(await c.list_prompts()); did = True
            if a.get:
                name, raw = a.get
                gp = await c.get_prompt(name, json.loads(raw) if raw else None)
                print(f"prompts/get {name}")
                for m in gp.messages:
                    print(f"[{m.role}] {getattr(m.content, 'text', m.content)}")
                did = True
            if a.list or (not a.call and not did):
                print_tools(await c.list_tools())
            if a.call:
                name, raw = a.call
                args = json.loads(raw)
                r = await c.call_tool(name, args)
                print(f"tools/call {name}({json.dumps(args)})")
                if r.structured_content is not None:
                    print(f"→ {json.dumps(r.structured_content, ensure_ascii=False)}")
                else:
                    for block in r.content:
                        print(f"→ {getattr(block, 'text', block)}")
                if r.is_error:
                    print("→ isError: true")
                    return 2
    except BaseException as e:
        for err in leaves(e):
            if isinstance(err, MCPError):
                print(f"error: {err.error.message} (code {err.error.code})")
            else:
                print(f"error: {type(err).__name__}: {err}")
        await explain_http(a.url, headers)
        return 1
    return 0


async def explain_http(url: str, headers: dict | None) -> None:
    """After a failure, one plain POST to show the HTTP status and body. Cloud Run's
    IAM check answers 403 with an HTML page before our server ever sees the request;
    the server's own check answers 401 with a JSON-RPC error."""
    import httpx2
    body = {"jsonrpc": "2.0", "id": 1, "method": "tools/list"}
    h = {"Content-Type": "application/json",
         "Accept": "application/json, text/event-stream", **(headers or {})}
    try:
        async with httpx2.AsyncClient(timeout=15) as http:
            r = await http.post(url, json=body, headers=h)
        text = " ".join(r.text.split())[:160]
        print(f"http: {r.status_code} {r.reason_phrase}  {text}")
    except Exception as e:
        print(f"http: {type(e).__name__}: {e}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--url", required=True, help="the MCP endpoint, e.g. https://…/mcp")
    ap.add_argument("--token", default="auto", help="auto | none | <token>")
    ap.add_argument("--header", action="append", default=[], metavar="NAME: VALUE",
                    help="an extra request header (repeatable)")
    ap.add_argument("--list", action="store_true", help="print tools/list")
    ap.add_argument("--call", nargs=2, metavar=("NAME", "JSON"), help="call one tool")
    ap.add_argument("--resources", action="store_true", help="print resources/list")
    ap.add_argument("--read", metavar="URI", help="read one resource by uri")
    ap.add_argument("--prompts", action="store_true", help="print prompts/list")
    ap.add_argument("--get", nargs=2, metavar=("NAME", "JSON"), help="get one prompt")
    sys.exit(asyncio.run(main(ap.parse_args())))
