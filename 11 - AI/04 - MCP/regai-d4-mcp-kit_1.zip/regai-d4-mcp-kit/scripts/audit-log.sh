#!/usr/bin/env bash
# audit-log.sh — the last N tool calls the bookshelf-mcp server recorded, as a table.
#
#   bash scripts/audit-log.sh          # last 20
#   bash scripts/audit-log.sh 50
#   bash scripts/audit-log.sh 20 entries.json   # from a saved `gcloud logging read` file
#
# The server prints one JSON line per call to stdout; Cloud Logging stores it as a
# structured entry (jsonPayload). This reads those entries back: who called which tool
# with what, and whether it worked. A refused request (no valid token) shows as
# caller "anonymous", ok FAIL. New entries take a few seconds to appear.
set -euo pipefail
N="${1:-20}"
FILE="${2:-}"
FILTER='resource.type="cloud_run_revision"'
FILTER="$FILTER"' AND resource.labels.service_name="bookshelf-mcp"'
FILTER="$FILTER"' AND jsonPayload.event="tool_call"'

if [ -n "$FILE" ]; then
  INPUT="$FILE"
else
  PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
  INPUT="$(mktemp)"; trap 'rm -f "$INPUT"' EXIT
  gcloud logging read "$FILTER" --limit "$N" --format json --project "$PROJECT" > "$INPUT"
fi

python3 - "$INPUT" <<'EOF'
import json, sys
entries = json.load(open(sys.argv[1]))
if not entries:
    print("no tool_call entries yet")
    sys.exit(0)
ROW = "%-20s %-30s %-17s %-4s %5s  %s"
print(ROW % ("time (UTC)", "caller", "tool", "ok", "ms", "args"))
for e in reversed(entries):                     # oldest first, as they happened
    p = e.get("jsonPayload", {})
    t = e.get("timestamp", "")[:19].replace("T", " ")
    tool = p.get("tool") or "(%s)" % (p.get("method") or "-")
    ok = "ok" if p.get("ok") else "FAIL"
    args = json.dumps(p.get("args"), ensure_ascii=False) if p.get("args") else ""
    err = "  " + p["error"][:60] if p.get("error") else ""
    row = (t, str(p.get("caller", "?"))[:30], tool[:17], ok, str(p.get("ms", "")), args)
    print(ROW % row + err)
EOF
