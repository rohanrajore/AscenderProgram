# lab-parts — the settings.json each part expects

`scripts/gemini-config.sh` writes these for you, with your project id, the deployed URL
and a fresh token filled in. The files here are the same fragments with placeholders, to
read on screen or to paste by hand into `~/.gemini/settings.json`.

| Part | File | What it adds |
|---|---|---|
| A | `part-a.settings.json` | `agent-search`: the Agent Search MCP server, with your own Google credentials |
| B | `part-b.settings.json` | plus `bookshelf`: our server on Cloud Run, your ID token in the `Authorization` header |
| C | (uses `part-b.settings.json`) | resources and prompts — read with `mcp-call.py`, no settings change |
| D | `part-d.settings.json` | `bookshelf` with `includeTools`: the client-side fence, on top of what the server exposes |
| E | (uses `agent.env`, not settings.json) | the agent reads its tools from the server: `MCP=on`, `MCP_URL=<your URL>` |

Tokens in `headers` last about an hour. When Gemini CLI reports a 401 from `bookshelf`,
run `bash scripts/gemini-config.sh` again.
