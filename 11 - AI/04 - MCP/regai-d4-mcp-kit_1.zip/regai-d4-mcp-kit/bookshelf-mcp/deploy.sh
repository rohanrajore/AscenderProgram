#!/usr/bin/env bash
# Deploy bookshelf-mcp to Cloud Run as its own service account. Idempotent: re-run it
# after a failure, or to roll out a code change. Takes a few minutes, mostly the build.
#
#   bash deploy.sh                      # gcloud's default project, REGION=asia-south1
#   REGION=us-central1 bash deploy.sh
#
# Needs: bookshelf-api deployed (Day 0) and the Day 1 data store and app ids.
set -euo pipefail
cd "$(dirname "$0")"

PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-south1}"
REPO="${REPO:-regai}"
SERVICE="bookshelf-mcp"
SA_NAME="bookshelf-mcp-sa"
SA="$SA_NAME@$PROJECT.iam.gserviceaccount.com"
DATASTORE_ID="${DATASTORE_ID:-bookshelf-ds}"
APP_ID="${APP_ID:-bookshelf-app}"
[ -n "$PROJECT" ] || { echo "No project: gcloud config set project <id>"; exit 1; }

# The MCP server calls bookshelf-api, so it needs that URL baked in as an env var.
API_URL="${BOOKSHELF_API_URL:-$(gcloud run services describe bookshelf-api \
  --region "$REGION" --project "$PROJECT" --format='value(status.url)' 2>/dev/null \
  || true)}"
[ -n "$API_URL" ] || { echo "bookshelf-api not found in $PROJECT/$REGION: deploy Day 0" \
  "first, or set BOOKSHELF_API_URL."; exit 1; }

echo "project      : $PROJECT"
echo "region       : $REGION"
echo "bookshelf-api: $API_URL"
echo

echo "1/6  enabling APIs…"
gcloud services enable run.googleapis.com artifactregistry.googleapis.com \
  cloudbuild.googleapis.com iam.googleapis.com discoveryengine.googleapis.com \
  aiplatform.googleapis.com --project "$PROJECT" -q

echo "2/6  service account $SA_NAME…"
# The server runs as this account, not as you: its calls to bookshelf-api and
# Discovery Engine carry the SERVICE's identity, and only the roles granted here.
gcloud iam service-accounts describe "$SA" --project "$PROJECT" >/dev/null 2>&1 \
  || gcloud iam service-accounts create "$SA_NAME" --display-name "bookshelf-mcp server" \
       --project "$PROJECT" -q

echo "3/6  roles: invoke bookshelf-api, use Vertex AI and Discovery Engine…"
gcloud run services add-iam-policy-binding bookshelf-api --region "$REGION" \
  --member "serviceAccount:$SA" --role roles/run.invoker --project "$PROJECT" -q \
  >/dev/null
for role in roles/aiplatform.user roles/discoveryengine.viewer; do
  gcloud projects add-iam-policy-binding "$PROJECT" --member "serviceAccount:$SA" \
    --role "$role" -q >/dev/null
done

echo "4/6  Artifact Registry repository…"
gcloud artifacts repositories describe "$REPO" --location "$REGION" --project "$PROJECT" \
  >/dev/null 2>&1 \
  || gcloud artifacts repositories create "$REPO" --repository-format=docker \
       --location="$REGION" --description="REGAI programme images" --project "$PROJECT" -q

IMAGE="$REGION-docker.pkg.dev/$PROJECT/$REPO/$SERVICE:v1"
echo "5/6  building the image with Cloud Build…"
gcloud builds submit --tag "$IMAGE" --project "$PROJECT" -q

echo "6/6  deploying to Cloud Run…"
# --no-allow-unauthenticated: Cloud Run IAM checks the caller's Google ID token before
#   the container sees the request (and it side-steps the org policy on public services).
#   The server checks the token again in code (AUTH=on) and logs the email.
# EXPOSE_RESERVE=off: reserve_book stays withheld until Lab Part C.
ENV="BOOKSHELF_API_URL=$API_URL,PROJECT_ID=$PROJECT,DATASTORE_ID=$DATASTORE_ID"
ENV="$ENV,APP_ID=$APP_ID,AUTH=on,EXPOSE_RESERVE=off"
gcloud run deploy "$SERVICE" \
  --image "$IMAGE" \
  --region "$REGION" \
  --platform managed \
  --no-allow-unauthenticated \
  --service-account "$SA" \
  --set-env-vars "$ENV" \
  --min-instances=0 --max-instances=2 \
  --memory=512Mi --cpu=1 --timeout=60 \
  --project "$PROJECT" -q

URL=$(gcloud run services describe "$SERVICE" --region "$REGION" --project "$PROJECT" \
  --format='value(status.url)')
# The server needs its own URL to check a token's audience; Cloud Run does not tell a
# container its URL, so it is set now that the URL exists (one more revision).
gcloud run services update "$SERVICE" --region "$REGION" --project "$PROJECT" \
  --update-env-vars "SERVICE_URL=$URL" -q

# Everyone in the class calls the server as themselves: grant the invoker role to
# the deploying account (the trainer adds learners the same way).
ME=$(gcloud config get-value account 2>/dev/null)
[ -z "$ME" ] || gcloud run services add-iam-policy-binding "$SERVICE" --region "$REGION" \
  --member "user:$ME" --role roles/run.invoker --project "$PROJECT" -q >/dev/null

echo
echo "=============================================================="
echo " bookshelf-mcp is deployed"
echo "   MCP endpoint: $URL/mcp"
echo "   runs as     : $SA"
echo
echo " Save it for the labs:"
echo "   export BOOKSHELF_MCP_URL=$URL"
echo " Then: bash verify.sh"
echo "=============================================================="
