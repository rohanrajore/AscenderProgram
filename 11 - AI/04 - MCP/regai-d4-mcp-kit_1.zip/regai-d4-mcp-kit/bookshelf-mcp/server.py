#!/usr/bin/env python3
"""server.py — the Bookshelf library as an MCP server over Streamable HTTP.

    AUTH=off FAKE_API=1 uvicorn server:app --port 8765     # local, no Google, no network
    uvicorn server:app --host 0.0.0.0 --port $PORT          # what the Dockerfile runs

The same three tools as the Day 2 kit, with one difference that is the whole point of
Day 4: the definitions live here, next to the system they act on. A client never reads
a tools.json — it sends tools/list and gets what this file chose to expose. This file is
meant to be read top to bottom: config → identity → audit → the server → the tools →
the HTTP app.

Switches (environment variables):
    AUTH             on | off  verify the caller's Google ID token; off for local runs
    SERVICE_URL      this service's own URL — the audience an ID token must name
    EXPOSE_RESERVE   on | off  register reserve_book (default off: withheld)
    FAKE_API         1         in-process catalogue instead of bookshelf-api
    BOOKSHELF_API_URL, PROJECT_ID, APP_ID   the live implementations (tools_impl.py)
    PORT             what `python server.py` listens on (default 8080)
"""
from __future__ import annotations

import contextvars
import inspect
import json
import os
import time
from typing import Annotated, Any

from mcp.server import CacheHint, MCPServer
from mcp.types import ToolAnnotations
from pydantic import Field
from starlette.concurrency import run_in_threadpool
from starlette.responses import JSONResponse

import tools_impl
from tools_impl import CALLERS, EMAILS


# ============================================================ config
def env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


def on(key: str, default: str = "off") -> bool:
    return env(key, default).lower() in ("on", "1", "true", "yes")


SERVICE_URL = env("SERVICE_URL").rstrip("/")
# `gcloud auth print-identity-token` for a person mints a token whose audience is
# gcloud's own OAuth client id, not our URL (only service accounts can choose an
# audience). Cloud Run's IAM check accepts that audience for people; so do we.
GCLOUD_CLIENT_ID = "32555940559.apps.googleusercontent.com"
AUDIENCES = [a for a in (SERVICE_URL, GCLOUD_CLIENT_ID) if a]
DEFAULT_CALLER = "priya"


# ============================================================ identity
# The verified email of whoever is calling, set once per HTTP request by the Auth
# middleware below and read by the tools. A contextvar, not a global: two requests in
# flight at once each see their own value.
CALLER = contextvars.ContextVar("caller", default="anonymous")


def caller_key() -> str:
    """Which callers.json entry (and so which filter string) this identity gets. The
    model never names the caller; an email not in the "emails" map is priya."""
    return EMAILS.get(CALLER.get().lower(), DEFAULT_CALLER)


_google_request = None   # one HTTP session for fetching Google's signing certificates


def verify_id_token(token: str) -> dict:
    """The claims of a valid Google ID token, or a ValueError. Checks signature,
    expiry, issuer (accounts.google.com) and audience — issuer validation and client
    identity, done concretely."""
    global _google_request
    from google.auth.transport import requests as google_requests
    from google.oauth2 import id_token
    if _google_request is None:
        _google_request = google_requests.Request()
    return id_token.verify_oauth2_token(token, _google_request, audience=AUDIENCES)


# ============================================================ audit
def log(**fields: Any) -> None:
    """One JSON line per call to stdout. Cloud Logging reads it as a structured entry,
    so `audit-log.sh` can filter on jsonPayload.event."""
    print(json.dumps({"event": "tool_call", **fields}, ensure_ascii=False), flush=True)


async def audit(ctx, call_next):
    """SDK middleware: wraps every request; records tools/call with who, what, how
    long, and whether it worked. A tool that answers {"error": …} counts as not ok."""
    if ctx.method != "tools/call":
        return await call_next(ctx)
    params = ctx.params or {}
    t0, ok, error = time.monotonic(), False, None
    try:
        result = await call_next(ctx)
        # The result here is already serialized: camelCase keys, as on the wire.
        r = result if isinstance(result, dict) else result.model_dump(by_alias=True)
        sc = r.get("structuredContent")
        if r.get("isError"):
            error = (r.get("content") or [{}])[0].get("text", "error")[:200]
        elif isinstance(sc, dict) and "error" in sc:
            error = str(sc["error"])[:200]
        ok = error is None
        return result
    except Exception as e:
        error = f"{type(e).__name__}: {str(e)[:160]}"
        raise
    finally:
        ms = round((time.monotonic() - t0) * 1000)
        log(tool=params.get("name"), args=params.get("arguments"), caller=CALLER.get(),
            ok=ok, ms=ms, **({"error": error} if error else {}))


# ============================================================ the server
mcp = MCPServer(
    "bookshelf",
    version="1.0",
    instructions="The Meridian Bookshelf library for bank staff: stock, reservations "
                 "and answers from the approved policies and procedures.",
    middleware=[audit],
    # tools/list, resources/list and resources/read are the same for everyone and change
    # only on redeploy: clients may cache them for five minutes and share the cache
    # (2026-07-28 ttlMs / cacheScope).
    cache_hints={
        "tools/list": CacheHint(ttl_ms=300_000, scope="public"),
        "resources/list": CacheHint(ttl_ms=300_000, scope="public"),
        "resources/read": CacheHint(ttl_ms=300_000, scope="public"),
    },
)

READ_ONLY = ToolAnnotations(read_only_hint=True)
WRITES = ToolAnnotations(read_only_hint=False, destructive_hint=False,
                         idempotent_hint=False)


def tool(fn=None, /, **kw):
    """Register a function as a tool. Type hints become the input schema; the docstring
    becomes the description the model reads. The SDK takes __doc__ verbatim, indentation
    included, so it is dedented here first."""
    def register(f):
        mcp.add_tool(f, description=inspect.cleandoc(f.__doc__ or ""), **kw)
        return f
    return register(fn) if fn else register


BookId = Annotated[str, Field(description="Document id, e.g. PRC-KYC-003")]


# ============================================================ the tools
@tool(annotations=READ_ONLY)
def lookup_stock(book_id: BookId) -> dict[str, Any]:
    """Read-only: how many copies of one document in the Bookshelf library are
    available right now. Use for questions about stock or copies left; needs the
    document id. Changes nothing."""
    return tools_impl.lookup_stock(book_id)


@tool(annotations=READ_ONLY)
def search_bookshelf(
    question: Annotated[str, Field(description="The question, in the caller's words")],
) -> dict[str, Any]:
    """Search Meridian's approved policies and procedures and answer a question from
    them, with citations. Use for questions about rules, forms, limits or procedures.
    The caller's clearance, taken from their verified identity, decides which documents
    are searched. Changes nothing."""
    # The filter string is chosen here from the verified identity — never by the model.
    return tools_impl.search_bookshelf(question, caller_key())


def reserve_book(
    book_id: BookId,
    copies: Annotated[int, Field(ge=1, le=3, description="Copies to reserve, 1 to 3")],
) -> dict[str, Any]:
    """Reserve 1 to 3 copies of a document for the calling member of staff. Use only
    when the caller asks to reserve, hold or book copies. This changes library records:
    stock goes down and a reservation is created in the caller's name."""
    return tools_impl.reserve_book(book_id, copies, caller_key())


# Defined above, registered only on request: what a server withholds, no client can
# call, whatever its prompt says. Part C flips this with one env var.
if on("EXPOSE_RESERVE"):
    tool(reserve_book, annotations=WRITES)


# ============================================================ resources
# A resource is read-only context a client fetches by URI — not a tool it calls. Here it
# is the library's own index: the documents that exist, by id and title. resources/list
# and resources/read carry the same ttlMs / cacheScope as tools/list above.
@mcp.resource(
    "bookshelf://catalogue",
    name="catalogue",
    title="Bookshelf catalogue",
    description="The index of Meridian policy and procedure documents: id, title, "
                "classification and status. Read-only reference, not document text.",
    mime_type="application/json",
)
def catalogue_resource() -> str:
    rows = [{"id": bid, "title": title, "classification": cls, "status": status}
            for bid, title, cls, status in tools_impl.CATALOGUE]
    return json.dumps({"documents": rows}, ensure_ascii=False, indent=2)


# ============================================================ prompts
# A prompt is a server-owned template a client can list and fill: the system, not the
# person at the keyboard, owns the wording of a common task. prompts/list shows the
# arguments; prompts/get returns the filled message.
@mcp.prompt(
    name="policy_lookup",
    title="Policy lookup",
    description="Frame a staff question about a Meridian policy or procedure so the "
                "answer stays grounded in the approved documents, with citations.",
)
def policy_lookup(topic: str) -> str:
    return (f"Using the Bookshelf, find Meridian's approved guidance on: {topic}. "
            "Answer only from the documents the caller is cleared to see, quote the "
            "document id for each point, and say plainly if nothing approved covers it.")


# ============================================================ the HTTP app
class Auth:
    """ASGI middleware: verify the bearer token once per HTTP request, before the MCP
    layer sees it. No valid token → 401 with a JSON-RPC error body (so an MCP client
    shows the reason) and an audit line with caller "anonymous"."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not on("AUTH", "on"):
            return await self.app(scope, receive, send)
        headers = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        token = headers.get("authorization", "")
        token = token[7:] if token.lower().startswith("bearer ") else ""
        try:
            if not token:
                raise ValueError("no bearer token")
            # Verification fetches Google's certificates; keep it off the event loop.
            claims = await run_in_threadpool(verify_id_token, token)
            CALLER.set(claims.get("email", claims.get("sub", "unknown")))
        except Exception as e:
            reason = f"401: no valid Google ID token ({str(e)[:120]})"
            # 2026-07-28 clients name the method and tool in headers; log what was tried.
            log(tool=headers.get("mcp-name"), args=None, caller="anonymous", ok=False,
                ms=0, error=reason, method=headers.get("mcp-method"))
            body = {"jsonrpc": "2.0", "id": None,
                    "error": {"code": -32001, "message": reason}}
            www = {"WWW-Authenticate": 'Bearer realm="bookshelf-mcp"'}
            resp = JSONResponse(body, status_code=401, headers=www)
            return await resp(scope, receive, send)
        return await self.app(scope, receive, send)


# stateless_http: no session ids — every request stands alone, as the 2026 core wants
# and as Cloud Run (several instances) needs. json_response: plain JSON replies rather
# than SSE, easier to read in curl. host="0.0.0.0" turns off the SDK's localhost-only
# Host check, which would reject Cloud Run's hostname.
app = Auth(mcp.streamable_http_app(host="0.0.0.0", stateless_http=True,
                                   json_response=True))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(env("PORT", "8080")))
