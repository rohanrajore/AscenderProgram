#!/usr/bin/env bash
# Check that bookshelf-mcp answers: server/discover, tools/list, one tools/call — all
# with your Google ID token, through the python MCP client. Run after deploy.sh.
set -uo pipefail
cd "$(dirname "$0")"
PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-south1}"
URL="${BOOKSHELF_MCP_URL:-$(gcloud run services describe bookshelf-mcp \
  --region "$REGION" --project "$PROJECT" --format='value(status.url)' 2>/dev/null)}"
[ -n "$URL" ] || { echo "FAIL: no bookshelf-mcp service in $PROJECT / $REGION"; exit 1; }
CALL="python3 ../scripts/mcp-call.py --url $URL/mcp"

echo "endpoint : $URL/mcp"
echo "as       : $(gcloud config get-value account 2>/dev/null)"
echo
echo "--- tools/list (with your ID token)"
$CALL --list || { echo "FAIL: tools/list"; exit 1; }
echo
echo "--- tools/call lookup_stock"
$CALL --call lookup_stock '{"book_id": "PRC-KYC-003"}' \
  || { echo "FAIL: tools/call"; exit 1; }
echo
echo "--- the same tools/list with no token (expect a refusal: 403 from Cloud Run IAM)"
$CALL --token none --list && { echo "FAIL: the server answered without a token"; exit 1; }
echo
echo "done — the server answers with a token and refuses without one."
echo "Your email is now in the audit log: bash ../scripts/audit-log.sh 5"
