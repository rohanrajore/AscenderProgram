# regai-d4-mcp-kit — the Bookshelf behind MCP

Earlier you told the model what tools exist: you wrote `tools.json` and the agent sent it
with every request. Today the systems tell it. Google's Agent Search publishes its tools
as an MCP server; then the Bookshelf does the same, from a small server you deploy. Same
data store, same API, same three tools — now owned by the system that runs them, called
with an identity, and written down.

One lab in five parts: **A** the Agent Search server, **B** deploy ours, **C** resources
and prompts, **D** identity and audit, **E** the agent through MCP. The lab manual carries
the full step-by-step; below is a condensed walkthrough.

## What is here

```
README.md
bookshelf-mcp/
  server.py            the MCP server: tools lookup_stock, search_bookshelf (reserve_book
                       defined but registered only when EXPOSE_RESERVE=on); the catalogue
                       resource and the policy_lookup prompt
  tools_impl.py        the tool implementations, calling bookshelf-api and the Agent Search
                       :answer endpoint as the SERVICE's own service account
  callers.json         priya / daniel / mlro with their filter strings, plus an "emails"
                       map: which Google account is which caller (unmapped = priya)
  Dockerfile, requirements.txt, .dockerignore
  deploy.sh            Cloud Build + Cloud Run, as bookshelf-mcp-sa, IAM-protected
  verify.sh            tools/list and one call with your ID token; then without (refused)
scripts/
  gemini-config.sh     writes ~/.gemini/settings.json: "agent-search" and "bookshelf"
  mcp-call.py          a one-shot MCP client: --list | --call NAME '{json}' |
                       --resources | --read URI | --prompts | --get NAME '{json}'
  audit-log.sh         the server's tool_call log lines from Cloud Logging, as a table
  selftest.sh          everything below, offline (local server, fake catalogue, fake model)
  sample-entries.json  what `gcloud logging read` returns, for audit-log.sh offline
agent-patch/
  agent.py             the agent kit's agent with MCP=on MCP_URL=… (copy over the agent kit)
  tools_impl.py        the agent kit's implementations plus the MCP client functions
lab-parts/             the settings.json fragment each part expects
```

## Set-up

In Cloud Shell, with the agent kit and its venv from before:

```
unzip regai-d4-mcp-kit.zip
source ~/regai-venv/bin/activate && pip install -q mcp google-auth requests
cp regai-d4-mcp-kit/agent-patch/*.py regai-d2-agent-kit/
gemini --version || npm install -g @google/gemini-cli
export GOOGLE_GENAI_USE_VERTEXAI=true GOOGLE_CLOUD_PROJECT=$(gcloud config get-value project)
export GOOGLE_CLOUD_LOCATION=us-central1
```

The two `.py` files replace the agent kit's own ones; everything the agent kit already did
still works (`bash scripts/selftest.sh` in the agent kit passes as before). `agent.env`
keeps `TOOLS=on`.

## Part A — Google's server

```
cd regai-d4-mcp-kit
bash scripts/gemini-config.sh
gemini
```

In Gemini CLI type `/mcp`. It lists `agent-search` with its tools — `search`,
`conversational_search`, `list_engines` — and, under each, the schema the server
published. Nobody wrote a `tools.json` for these: Gemini CLI asked the server. Then ask,
naming your Agent Search engine:

```
Using the bookshelf-app engine, which form must a cardholder sign before a dispute can go to chargeback?
```

The answer comes through MCP: Gemini CLI calls the server's tool with your Google
credentials, the server searches the Agent Search data store, and the cited answer comes back.

The same `tools/list`, without Gemini CLI, from the terminal:

```
P=$(gcloud config get-value project)
python scripts/mcp-call.py --url https://discoveryengine.googleapis.com/mcp --token "$(gcloud auth print-access-token)" --header "X-Goog-User-Project: $P" --list
```

Look at the first line — what the server says about itself (`server/discover`) — and at
`tools/list:`: the number of tools, `ttlMs` and `cacheScope` when the server sends them,
and the tools in a fixed order. That is the 2026-07-28 revision on the wire: no session
to set up, results a client may cache, one deterministic list.

## Part B — ours

Deploy the Bookshelf's MCP server (a few minutes, mostly the build; keep listening):

```
bash bookshelf-mcp/deploy.sh
bash bookshelf-mcp/verify.sh
```

`deploy.sh` creates the service account `bookshelf-mcp-sa`, grants it `roles/run.invoker`
on `bookshelf-api` plus `roles/aiplatform.user` and `roles/discoveryengine.viewer`,
builds the image with Cloud Build and deploys `bookshelf-mcp` to Cloud Run with
`--no-allow-unauthenticated`. `verify.sh` runs `tools/list` and one `tools/call` with your
ID token, then `tools/list` without a token, which is refused.

Now add it to Gemini CLI and look:

```
bash scripts/gemini-config.sh
gemini
```

`/mcp` shows `bookshelf` with two tools, `lookup_stock` and `search_bookshelf`, each with
the description and schema `server.py` declared. Ask:

```
How many copies of PRC-KYC-003 are left?
```

Gemini CLI calls `lookup_stock` on our server; our server calls `bookshelf-api` as
`bookshelf-mcp-sa`; the answer comes back. Then ask it to reserve a copy: there is no
such tool, and it says so. The server withheld it.

The agent, with the tools coming from the server instead of `tools.json`:

```
cd ../regai-d2-agent-kit
export BOOKSHELF_MCP_URL=$(gcloud run services describe bookshelf-mcp --region asia-south1 --format='value(status.url)')
MCP=on MCP_URL=$BOOKSHELF_MCP_URL/mcp python agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
MCP=on MCP_URL=$BOOKSHELF_MCP_URL/mcp python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
```

The third line of the printout is new:

```
tools from: https://bookshelf-mcp-….run.app/mcp (tools/list, 2 tools, ttlMs=300000, cacheScope=public, protocol 2026-07-28, token sent)
```

`tools.json` was never read. The lookup runs as `⚙ run lookup_stock(…)` exactly as before
— the loop cannot tell the difference — but the call went to the server with your ID
token, and the reservation is refused because the server offers no tool for it.

## Part C — resources and prompts

Tools are one of three MCP primitives. The server also publishes a **resource** — read-only
context a client fetches by URI — and a **prompt** — a template the server owns, not the
person at the keyboard. Neither is a tool call:

```
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --resources
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --read bookshelf://catalogue
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --prompts
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --get policy_lookup '{"topic": "card disputes"}'
```

`resources/list` shows `bookshelf://catalogue` — the library's index of documents (id,
title, classification, status), not document text — with `ttlMs`/`cacheScope`, the same
caching contract as `tools/list`. `resources/read` returns it. `prompts/list` shows
`policy_lookup` and its one argument; `prompts/get` fills it: the wording of the task lives
on the server, so every caller frames a policy question the same way. In Gemini CLI these
appear too — `/mcp` lists the resource and the prompt alongside the tools.

## Part D — identity and audit

**Who is calling.** Without a token the server refuses:

```
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --token none --list
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --list
```

The first is refused (Cloud Run's IAM check answers 403 before the container sees the
request; run the server locally with `AUTH=on` and the server's own check answers 401 —
`scripts/selftest.sh` shows that one). The second lists the tools: `--token auto` sends
`gcloud auth print-identity-token`. The server verifies the token's signature, issuer
(`accounts.google.com`), audience and expiry with `google.oauth2.id_token`, and takes the
`email` claim as the caller. That email decides the caller in `callers.json` and so the
filter string `search_bookshelf` sends — never the model, never the client.

**What was done.** Every call is one JSON line on the server's stdout, which Cloud Logging
stores as a structured entry:

```
{"event": "tool_call", "tool": "lookup_stock", "args": {"book_id": "PRC-KYC-003"}, "caller": "you@example.com", "ok": true, "ms": 212}
```

```
bash scripts/audit-log.sh 20
```

prints the last 20 as a table: time, caller, tool, arguments, ok. Your calls from Part B
are there with your email; the refused request is there as `anonymous`, `FAIL`.

**Two fences, two owners.** The server decides what exists; the client decides what it
will use. Expose the withheld tool on the server:

```
gcloud run services update bookshelf-mcp --region asia-south1 --update-env-vars EXPOSE_RESERVE=on
python scripts/mcp-call.py --url $BOOKSHELF_MCP_URL/mcp --list
```

Three tools now. In Gemini CLI, `/mcp` shows `reserve_book`; ask it to reserve one copy of
PRC-KYC-003 and it does. `bash scripts/audit-log.sh 5` shows who reserved. Then fence it
on the client side, whatever the server exposes:

```
INCLUDE_TOOLS=lookup_stock,search_bookshelf bash scripts/gemini-config.sh
```

`/mcp` shows two tools again; the server still has three (`mcp-call.py --list` proves it).
`lab-parts/part-d.settings.json` is the fragment that does it. In the agent,
`APPROVE=ask` puts the approval card in front of the server's `reserve_book`: the
server says the tool changes things (`readOnlyHint: false`) and the loop asks a person.

## Reading the printout

`python scripts/mcp-call.py --list` prints, in order: `server/discover` (protocol versions
and cache hints), the server's name, instructions and capabilities, then `tools/list:`
with `ttlMs`/`cacheScope`, and each tool: name, annotations, description, parameters
(`*` = required). `--call` adds the `tools/call` line and the structured result, or the
error text with `isError: true`.

The audit line's fields: `tool`, `args` (as sent), `caller` (verified email, or
`anonymous`), `ok` (false for a refused request, a tool error or a result carrying
`"error"`), `ms`, and `error` when not ok. A refused request also carries `method`,
from the `Mcp-Method` header a 2026-07-28 client sends.

## Running everything offline

```
bash scripts/selftest.sh
```

starts `server.py` on this machine (`AUTH=off FAKE_API=1`, then `EXPOSE_RESERVE=on`,
then `AUTH=on` with no token), runs `mcp-call.py` and the patched agent (`FAKE_MODEL=1`)
against it, checks the token verification against a locally signed token, and runs
`audit-log.sh` on a saved log sample. No project, no network. `MEASURED=out.txt` keeps
every printout.

## The switches

| Where | Switch | Effect |
|---|---|---|
| server | `AUTH=on/off` | verify the caller's Google ID token; `off` for local runs (caller `anonymous`) |
| server | `EXPOSE_RESERVE=on/off` | register `reserve_book`; `off` withholds it (default) |
| server | `SERVICE_URL` | the audience an ID token must name (set by `deploy.sh`) |
| server | `FAKE_API=1` | in-process catalogue instead of bookshelf-api |
| agent | `MCP=on/off` | tools from the server's `tools/list`, calls through `tools/call`; `tools.json` not read |
| agent | `MCP_URL` | the endpoint, `https://…/mcp` |
| agent | `MCP_AUTH=on/off` | send your ID token (`gcloud auth print-identity-token`); `off` for a local server |
| Gemini CLI | `includeTools` / `excludeTools` | the client-side fence, in `settings.json` |

## SDK facts (mcp 2.2.0, installed and read before this kit was written)

| What | Name |
|---|---|
| server class | `mcp.server.MCPServer(name, version=, instructions=, middleware=, cache_hints=)` |
| register a tool | `@server.tool()` or `server.add_tool(fn, description=, annotations=)`; type hints (and `Annotated[…, pydantic.Field(...)]`) are the input schema; a `-> dict[str, Any]` return gives `structuredContent`; `__doc__` is the description, taken verbatim (hence `inspect.cleandoc` in `server.py`) |
| annotations | `mcp.types.ToolAnnotations(read_only_hint=, destructive_hint=, idempotent_hint=)` |
| cache hints | `mcp.server.CacheHint(ttl_ms=, scope="public"/"private")`, per method: `cache_hints={"tools/list": …}` |
| the ASGI app | `server.streamable_http_app(host="0.0.0.0", stateless_http=True, json_response=True)` → a Starlette app, served by `uvicorn server:app --port $PORT`; the default `host="127.0.0.1"` enables a localhost-only Host check |
| per-request headers | inside a tool, `ctx: mcp.server.mcpserver.Context` gives `ctx.headers`; `server.py` verifies once per HTTP request in ASGI middleware instead and hands the email to the tools through a `contextvars.ContextVar` |
| request middleware | `middleware=[async fn(ctx, call_next)]` with `ctx.method`, `ctx.params`; the `tools/call` result reaches it serialized (`isError`, `structuredContent`) |
| client | `mcp.Client(url)` or `mcp.Client(streamable_http_client(url, http_client=create_mcp_http_client(headers={…})))` from `mcp.client.streamable_http` and `mcp.shared._httpx_utils`; `async with` |
| discover | `client.session.discover_result` → `supported_versions`, `ttl_ms`, `cache_scope`; `client.server_info`, `client.instructions`, `client.server_capabilities`, `client.protocol_version` |
| list / call | `await client.list_tools()` → `ListToolsResult(tools, ttl_ms, cache_scope)`; each `Tool` has `name`, `description`, `input_schema`, `annotations`; `await client.call_tool(name, args, meta=)` → `CallToolResult(content, structured_content, is_error)` |
| errors | `mcp.shared.exceptions.MCPError` with `.error.code` / `.error.message`; a non-2xx HTTP reply whose body is a JSON-RPC error is surfaced with that message |
| wire | the client sends `Mcp-Protocol-Version`, `Mcp-Method` and `Mcp-Name` headers on every POST; `mode="auto"` probes `server/discover` and falls back to `initialize` |
| token check | `google.oauth2.id_token.verify_oauth2_token(token, google.auth.transport.requests.Request(), audience=[…])` (google-auth 2.58.0) — a list of audiences is accepted |

## If something fails

| Symptom | Fix |
|---|---|
| Gemini CLI shows `bookshelf` as disconnected, or a 401 | rerun `bash scripts/gemini-config.sh` (tokens last about an hour) |
| `mcp-call.py` prints `http: 403` | your account needs `roles/run.invoker` on `bookshelf-mcp`: `gcloud run services add-iam-policy-binding bookshelf-mcp --member="user:$(gcloud config get-value account)" --role=roles/run.invoker --region=asia-south1` |
| `mcp-call.py` prints `error: 401` | the token reached the server but did not verify: get a fresh one (`--token auto` does) |
| `deploy.sh` fails in Cloud Build | your account needs `roles/cloudbuild.builds.editor`, or enable the API in the console and rerun; it is idempotent |
| `deploy.sh`: unauthenticated access refused by policy | the service is deployed with `--no-allow-unauthenticated`; nothing to change — every caller presents an ID token |
| `tools from: … tools/list failed: 401` in the agent | `gcloud auth login`, then run again; `MCP_AUTH=off` only for a local server started with `AUTH=off` |
| `bookshelf-api not found` in `deploy.sh` | deploy bookshelf-api first, or `export BOOKSHELF_API_URL=…` |
| Stock numbers look wrong | `python agent.py --reset` in the agent kit |
