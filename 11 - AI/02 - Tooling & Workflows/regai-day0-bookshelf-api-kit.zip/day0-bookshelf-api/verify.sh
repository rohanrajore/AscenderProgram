#!/usr/bin/env bash
# Check that bookshelf-api is up and answering. Run after deploy.sh.
set -uo pipefail
PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-south1}"
URL="${BOOKSHELF_API_URL:-$(gcloud run services describe bookshelf-api --region "$REGION" --project "$PROJECT" --format='value(status.url)' 2>/dev/null)}"
[ -n "$URL" ] || { echo "FAIL: no bookshelf-api service found in $PROJECT / $REGION"; exit 1; }
echo "url     : $URL"

# The service is IAM-protected, so every call carries a Google identity token.
TOKEN=$(gcloud auth print-identity-token)
H=(-H "Authorization: Bearer $TOKEN")

code=$(curl -s -o /tmp/h.json -w '%{http_code}' "${H[@]}" "$URL/health")
if [ "$code" = "200" ]; then echo "health  : OK  $(cat /tmp/h.json)"; else echo "health  : FAIL (HTTP $code)"; exit 1; fi

books=$(curl -s "${H[@]}" "$URL/books?q=POL&limit=20" | python3 -c "import sys,json; print(json.load(sys.stdin)['count'])" 2>/dev/null)
echo "catalogue: OK  ($books documents matching 'POL')"

echo "one book : $(curl -s "${H[@]}" "$URL/books/POL-CR-014" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['id'], '|', d['status'], '|', d['classification'])" 2>/dev/null)"
echo
echo "done — if every line says OK, day 1 can start."
