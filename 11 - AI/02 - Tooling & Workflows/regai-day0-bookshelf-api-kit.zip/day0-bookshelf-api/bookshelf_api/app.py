"""bookshelf-api — the internal library service the Bookshelf Assistant acts through.

Ready-made: learners run it, they do not edit it.

    uvicorn bookshelf_api.app:app --port 8080 --reload

Environment knobs (all optional):
    BOOKSHELF_TOKEN   if set, every request needs  Authorization: Bearer <token>
    BOOKSHELF_CHAOS   off | timeout | error | malformed | flaky   (Session 4 failure lab)
    REGAI_CORPUS      folder of the 13 corpus documents (default ../corpus)
"""
from __future__ import annotations

import asyncio
import os
import random
import re
import time
import uuid
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

app = FastAPI(title="bookshelf-api", version="2.0")

CORPUS = Path(os.environ.get("REGAI_CORPUS", Path(__file__).resolve().parent.parent / "corpus"))
FRONT = re.compile(r"^---\n(.*?)\n---\n", re.S)

# ---------------------------------------------------------------- data
BOOKS: dict[str, dict] = {}
RESERVATIONS: dict[str, dict] = {}
IDEMPOTENCY: dict[str, str] = {}      # idempotency key -> reservation id
RESERVE_KEYS: dict[str, dict] = {}    # Idempotency-Key header -> the /reserve response it produced
FLAGS: list[dict] = []
EVENTS: list[dict] = []               # everything that changed state, in order


def _load() -> None:
    for path in sorted(CORPUS.glob("*.md")):
        m = FRONT.match(path.read_text(encoding="utf-8"))
        meta = dict(line.partition(":")[::2] for line in m.group(1).splitlines())
        meta = {k.strip(): v.strip() for k, v in meta.items()}
        BOOKS[meta["id"]] = {
            "id": meta["id"], "title": meta["title"], "classification": meta["classification"],
            "department": meta["department"], "status": meta["status"], "version": meta.get("version", ""),
            "effective_date": meta.get("effective_date", ""), "owner": meta.get("owner", ""),
            "copies_total": 3, "copies_available": 3,
        }


_load()


def _event(kind: str, **data) -> None:
    EVENTS.append({"seq": len(EVENTS) + 1, "ts": time.time(), "kind": kind, **data})


# ---------------------------------------------------------------- auth + chaos
def auth(authorization: str | None = Header(default=None)) -> None:
    token = os.environ.get("BOOKSHELF_TOKEN")
    if token and authorization != f"Bearer {token}":
        raise HTTPException(status_code=401, detail="missing or invalid bearer token")


@app.middleware("http")
async def chaos(request: Request, call_next):
    mode = os.environ.get("BOOKSHELF_CHAOS", "off")
    if mode == "off" or request.url.path in ("/health", "/events"):
        return await call_next(request)
    if mode == "timeout":
        await asyncio.sleep(30)
    if mode == "error":
        return PlainTextResponse("internal error (chaos)", status_code=500)
    if mode == "malformed":
        return PlainTextResponse('{"id": "POL-CR-014", "title": ', status_code=200, media_type="application/json")
    if mode == "flaky" and random.random() < 0.5:
        return PlainTextResponse("upstream unavailable (chaos)", status_code=503)
    return await call_next(request)


# ---------------------------------------------------------------- models
class ReservationIn(BaseModel):
    staff_id: str = Field(min_length=1)
    idempotency_key: str | None = None


class ReserveIn(BaseModel):
    staff_id: str = Field(min_length=1)
    copies: int = Field(default=1, ge=1, le=3)


class FlagIn(BaseModel):
    staff_id: str
    reason: str = Field(min_length=5)


class UpdateIn(BaseModel):
    classification: str | None = None
    department: str | None = None
    owner: str | None = None


class RetireIn(BaseModel):
    staff_id: str
    reason: str = Field(min_length=5)
    approved_by: str | None = None


# ---------------------------------------------------------------- routes
@app.get("/health")
def health():
    return {"status": "ok", "books": len(BOOKS), "chaos": os.environ.get("BOOKSHELF_CHAOS", "off")}


@app.get("/books", dependencies=[Depends(auth)])
def list_books(q: str | None = None, department: str | None = None, classification: str | None = None,
               status: str | None = None, limit: int = 20):
    out = []
    for b in BOOKS.values():
        if q and q.lower() not in (b["title"] + " " + b["id"]).lower():
            continue
        if department and b["department"] != department:
            continue
        if classification and b["classification"] != classification:
            continue
        if status and b["status"] != status:
            continue
        out.append(b)
    return {"count": len(out[:limit]), "books": out[:limit]}


@app.get("/books/{book_id}", dependencies=[Depends(auth)])
def get_book(book_id: str):
    b = BOOKS.get(book_id)
    if not b:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    return b


@app.post("/books/{book_id}/reservations", dependencies=[Depends(auth)], status_code=201)
def reserve(book_id: str, body: ReservationIn):
    b = BOOKS.get(book_id)
    if not b:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    if body.idempotency_key and body.idempotency_key in IDEMPOTENCY:
        return {**RESERVATIONS[IDEMPOTENCY[body.idempotency_key]], "replayed": True}
    if b["copies_available"] <= 0:
        raise HTTPException(status_code=409, detail="no copies available")
    rid = f"res_{uuid.uuid4().hex[:8]}"
    b["copies_available"] -= 1
    RESERVATIONS[rid] = {"id": rid, "book_id": book_id, "staff_id": body.staff_id, "created": time.time()}
    if body.idempotency_key:
        IDEMPOTENCY[body.idempotency_key] = rid
    _event("reservation.created", reservation=rid, book=book_id, staff=body.staff_id)
    return {**RESERVATIONS[rid], "replayed": False}


@app.post("/books/{book_id}/reserve", dependencies=[Depends(auth)], status_code=201)
def reserve_copies(book_id: str, body: ReserveIn,
                   idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    """Reserve 1-3 copies in one call (the day-2 assistant's reserve_book tool).

    Idempotency-Key: a repeated key returns the original reservation and does not reserve
    again, so a client that lost the response can retry safely. Keys live in memory."""
    b = BOOKS.get(book_id)
    if not b:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    if idempotency_key and idempotency_key in RESERVE_KEYS:
        return JSONResponse(status_code=200, content={**RESERVE_KEYS[idempotency_key], "replayed": True})
    if b["copies_available"] < body.copies:
        raise HTTPException(status_code=409, detail=f"only {b['copies_available']} copies available")
    rid = f"res_{uuid.uuid4().hex[:8]}"
    b["copies_available"] -= body.copies
    RESERVATIONS[rid] = {"id": rid, "book_id": book_id, "staff_id": body.staff_id,
                         "copies": body.copies, "created": time.time()}
    out = {**RESERVATIONS[rid], "copies_available": b["copies_available"]}
    if idempotency_key:
        RESERVE_KEYS[idempotency_key] = out
    _event("reservation.created", reservation=rid, book=book_id, staff=body.staff_id,
           copies=body.copies, idempotency_key=idempotency_key)
    return {**out, "replayed": False}


@app.get("/reservations", dependencies=[Depends(auth)])
def reservations(book_id: str | None = None):
    rows = [r for r in RESERVATIONS.values() if not book_id or r["book_id"] == book_id]
    return {"count": len(rows), "reservations": rows}


@app.post("/books/{book_id}/flags", dependencies=[Depends(auth)], status_code=201)
def flag(book_id: str, body: FlagIn):
    if book_id not in BOOKS:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    f = {"id": f"flag_{uuid.uuid4().hex[:8]}", "book_id": book_id, "staff_id": body.staff_id, "reason": body.reason}
    FLAGS.append(f)
    _event("flag.created", book=book_id, staff=body.staff_id)
    return f


@app.patch("/books/{book_id}", dependencies=[Depends(auth)])
def update(book_id: str, body: UpdateIn):
    b = BOOKS.get(book_id)
    if not b:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    changes = {k: v for k, v in body.model_dump().items() if v is not None}
    b.update(changes)
    _event("book.updated", book=book_id, changes=changes)
    return b


@app.post("/books/{book_id}/retire", dependencies=[Depends(auth)])
def retire(book_id: str, body: RetireIn):
    """Irreversible: withdraws a document from the library. The API does NOT check who approved —
    that is the assistant's job (Session 4) — it only records what it was told."""
    b = BOOKS.get(book_id)
    if not b:
        raise HTTPException(status_code=404, detail=f"no book {book_id}")
    if b["status"] == "withdrawn":
        raise HTTPException(status_code=409, detail="already withdrawn")
    b["status"] = "withdrawn"
    _event("book.retired", book=book_id, staff=body.staff_id, approved_by=body.approved_by, reason=body.reason)
    return b


@app.get("/events")
def events():
    return {"count": len(EVENTS), "events": EVENTS}


@app.post("/reset", dependencies=[Depends(auth)])
def reset():
    BOOKS.clear(); RESERVATIONS.clear(); IDEMPOTENCY.clear(); RESERVE_KEYS.clear(); FLAGS.clear(); EVENTS.clear()
    _load()
    return {"status": "reset", "books": len(BOOKS)}
