#!/usr/bin/env bash
# Deploy bookshelf-api to Cloud Run. Run once, in your own sandbox project,
# before day 1 of the programme. Idempotent — safe to re-run.
set -euo pipefail
cd "$(dirname "$0")"

PROJECT="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-asia-south1}"
REPO="${REPO:-regai}"
SERVICE="bookshelf-api"
[ -n "$PROJECT" ] || { echo "No project. Run: gcloud config set project <your-project>"; exit 1; }

echo "project : $PROJECT"
echo "region  : $REGION"
echo

echo "1/4  enabling APIs (about a minute the first time)…"
gcloud services enable run.googleapis.com artifactregistry.googleapis.com \
  cloudbuild.googleapis.com --project "$PROJECT" -q

echo "2/4  Artifact Registry repository…"
gcloud artifacts repositories describe "$REPO" --location "$REGION" --project "$PROJECT" >/dev/null 2>&1 \
  || gcloud artifacts repositories create "$REPO" \
       --repository-format=docker --location="$REGION" \
       --description="REGAI programme images" --project "$PROJECT" -q

IMAGE="$REGION-docker.pkg.dev/$PROJECT/$REPO/$SERVICE:v1"

echo "3/4  building the image with Cloud Build…"
gcloud builds submit --tag "$IMAGE" --project "$PROJECT" -q

echo "4/4  deploying to Cloud Run…"
# --no-allow-unauthenticated: the service is reachable only with a Google identity
#   token. This also side-steps the Domain-restricted-sharing org policy, which
#   blocks public Cloud Run services in sandbox orgs created after May 2024.
# --min/--max-instances=1: the catalogue is held in memory, so one instance keeps
#   reservations stable for the duration of the class. Not how you would run it for
#   real — and that is a conversation worth having with the room.
gcloud run deploy "$SERVICE" \
  --image "$IMAGE" \
  --region "$REGION" \
  --platform managed \
  --no-allow-unauthenticated \
  --min-instances=1 --max-instances=1 \
  --memory=512Mi --cpu=1 --timeout=60 \
  --project "$PROJECT" -q

URL=$(gcloud run services describe "$SERVICE" --region "$REGION" --project "$PROJECT" --format='value(status.url)')
echo
echo "=============================================================="
echo " bookshelf-api is deployed"
echo "   URL: $URL"
echo
echo " Save it for the labs:"
echo "   export BOOKSHELF_API_URL=$URL"
echo "=============================================================="
