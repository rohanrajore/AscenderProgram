---
id: PRC-CR-030
title: Card Block and Replacement Procedure
classification: internal
department: Cards Operations
status: approved
version: 2.2
effective_date: 2025-10-01
owner: Head of Cards Operations
---

# Card Block and Replacement Procedure

## 1. Purpose

This procedure describes how a Meridian credit or debit card is blocked and replaced when it is lost, stolen, damaged, compromised, or when a cardholder reports an unauthorised transaction under POL-CR-014. It applies to Customer Contact, Branch Network and Cards Operations.

## 2. When to block a card

A card must be blocked **immediately**, before any other action, when the cardholder reports it lost or stolen, when the cardholder reports a transaction they did not make, when Fraud Operations flags the card as compromised in a data breach, or when the card has been retained by an ATM outside the Meridian network. A card is blocked in the Cards console using the reason code that matches the report: **LST** (lost), **STL** (stolen), **FRD** (fraud or unauthorised transaction), **CMP** (compromised in breach), **DMG** (damaged).

## 3. Temporary freeze versus permanent block

3.1 A cardholder who has mislaid a card and expects to find it may **freeze** the card in the app for up to **7 days**. A frozen card declines all new transactions but continues to allow recurring payments already set up. After 7 days the freeze becomes a permanent block with reason LST and a replacement is issued.

3.2 A permanent block cannot be reversed. If the original card is found after a permanent block, it must be destroyed.

## 4. Replacement

4.1 A replacement card is ordered automatically when a permanent block is applied with reason LST, STL, FRD, CMP or DMG. The replacement carries a **new card number, expiry date and security code**; the PIN is unchanged unless the cardholder requests a new one.

4.2 Standard delivery is by post within **5 business days** to the registered address. Where the address has changed in the last 30 days, the replacement is held for collection in branch with ID&V under PRC-KYC-003.

4.3 **Emergency replacement** by next-day courier is available for cardholders travelling abroad or in hardship, approved by a Customer Contact team leader. There is no fee for the first emergency replacement in a 12-month period; subsequent emergency replacements carry a **£15** fee.

4.4 A digital version of the replacement card is available in the mobile wallet **immediately** on ordering, so the cardholder can continue to pay while the physical card is in transit.

## 5. Recurring payments and merchants

Where the card scheme's account updater service is enabled, recurring payments set up on the old card are transferred to the new card automatically within 3 business days. Colleagues must tell the cardholder to check any recurring payment to a merchant not covered by the updater service (the Cards console shows a list) and update it themselves.

## 6. Fraud referrals

When the block reason is FRD or CMP, the Cards console creates a Fraud Operations referral automatically. Colleagues must not discuss the details of a fraud investigation with the cardholder beyond confirming that the card has been blocked and a replacement ordered. The dispute itself follows POL-CR-014, including the Cardholder Dispute Declaration form FRM-CD-7.

## 7. Record keeping

Block and replacement events are recorded automatically in the card history and retained with the account record for 7 years under POL-DP-002.

## 8. Related documents

POL-CR-014 Credit Card Dispute and Chargeback Handling Policy; PRC-KYC-003 Customer Identification and Verification Procedure; PRC-FR-002 Fraud Operations Referral Procedure.
