---
id: POL-AML-007
title: Suspicious Activity Reporting Policy
classification: restricted
department: Financial Crime Compliance
status: approved
version: 4.1
effective_date: 2025-11-01
owner: Money Laundering Reporting Officer
---

# Suspicious Activity Reporting Policy

## 1. Purpose

This policy sets out the obligations of every Meridian Financial colleague to identify and report suspicious activity, and the process by which the Money Laundering Reporting Officer (MLRO) assesses internal reports and, where required, submits a Suspicious Activity Report (SAR) to the National Crime Agency. Access to this policy is restricted to colleagues with Financial Crime clearance because it describes detection thresholds and internal escalation routes.

## 2. The obligation to report

2.1 Every colleague must submit an **internal suspicious activity report (iSAR)** as soon as they know or suspect, or have reasonable grounds to know or suspect, that a person is engaged in money laundering or terrorist financing. Suspicion does not require proof; a reasonable, articulable concern is sufficient.

2.2 The iSAR must be submitted through the Sentinel case system on the **same business day** the suspicion arises. Colleagues must not delay a report to gather further evidence.

2.3 A colleague who has submitted an iSAR must not tell the customer, or anyone outside the Financial Crime team, that a report has been made. Doing so is the criminal offence of **tipping off**.

## 3. Indicators of suspicious activity

The following indicators are not exhaustive and none is conclusive on its own. Repeated cash deposits just below **£8,000**, the threshold at which enhanced identification applies under PRC-KYC-003. Rapid movement of funds through an account with no apparent business rationale. A customer who is unwilling to explain the source of funds, or whose explanation is inconsistent with their known profile. Use of multiple accounts to structure a single transaction. Payments to or from jurisdictions on the Bank's high-risk country list. A newly opened account receiving a large third-party credit followed by immediate onward transfer. Reluctance to provide identification, or the provision of documents that appear altered.

## 4. Assessment by the MLRO

4.1 The MLRO, or a nominated deputy, reviews every iSAR within **2 business days** of submission and records one of three outcomes in Sentinel: **no further action**, **monitor** (the account is placed on enhanced transaction monitoring for 90 days), or **external SAR** (a report is submitted to the National Crime Agency).

4.2 Where the MLRO decides that a transaction requires a **Defence Against Money Laundering (DAML)** request, the transaction must be held until consent is received or the statutory 7 working-day notice period expires. The customer is told only that the transaction is subject to a "processing delay"; template letter FC-L03 is the only approved wording.

4.3 The MLRO's decision and reasoning are recorded in Sentinel. The reporting colleague is told that the report has been received but is not told the outcome.

## 5. Account restrictions

5.1 Where an external SAR has been submitted, the MLRO may restrict the account to credits only, block specific payees, or freeze the account pending a DAML decision. Restrictions are applied through the Account Controls console with the reason code **FC-SAR**, which is visible only to colleagues with Financial Crime clearance; other colleagues see the generic code **REV-01** ("account under review").

5.2 A colleague in Customer Contact or a branch who sees REV-01 on an account must not speculate to the customer about the reason and must not attempt to lift the restriction. Enquiries are routed to Financial Crime through the Sentinel referral form.

## 6. Training and awareness

All colleagues complete the AML awareness module annually. Colleagues in Customer Contact, Branch Network, Payments Operations and Onboarding complete the enhanced module every 12 months and a refresher within 30 days of joining the team.

## 7. Record keeping

iSARs, MLRO assessments, external SARs and DAML correspondence are retained for **5 years** from the date of the report, or longer where a law enforcement request is open. These records are held in Sentinel only. They must never be copied to email, shared drives, ticketing systems or any AI-assisted tool.

## 8. Related documents

POL-AML-001 Anti-Money Laundering Policy; PRC-KYC-003 Customer Identification and Verification Procedure; POL-DP-002 Data Protection and Records Retention Policy.
