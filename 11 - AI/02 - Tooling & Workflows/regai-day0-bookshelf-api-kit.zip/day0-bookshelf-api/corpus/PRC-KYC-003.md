---
id: PRC-KYC-003
title: Customer Identification and Verification Procedure
classification: internal
department: Compliance
status: approved
version: 5.0
effective_date: 2026-01-15
owner: Head of Financial Crime Compliance
---

# Customer Identification and Verification Procedure

## 1. Purpose

This procedure describes the steps colleagues must follow to identify and verify the identity of a customer before an account is opened or a product is provided, in line with POL-AML-001 (Anti-Money Laundering Policy). It covers individual customers, sole traders and small businesses onboarded through branch, telephone, the mobile app and the web.

## 2. When identification is required

Identification and verification (ID&V) must be completed before any of the following: opening a current, savings or credit card account; granting a personal loan or overdraft; adding a joint account holder; changing the registered address or mobile number for an existing customer; and any single cash transaction of £8,000 or more by a customer who has not been verified in the last 12 months.

## 3. Standard identification — individuals

3.1 Collect the customer's full legal name, date of birth, current residential address, and nationality.

3.2 Verify identity using **one document from List A** (passport, photocard driving licence, national identity card) and **one document from List B** (a utility bill, council tax bill or bank statement dated within the last 3 months, or a current tenancy agreement). A List A document verifies name and date of birth; a List B document verifies address.

3.3 In the mobile app and web channels, the electronic identity check (provider: Verifi-ID) replaces List A and List B when it returns a **pass** result with a confidence score of 85 or higher. A **refer** result (score 60 to 84) requires one List A document uploaded in the app. A **fail** result (below 60) requires the customer to complete verification in branch.

3.4 The document numbers, issuing authority and expiry date are recorded in the customer record. A copy of the document is stored in the Document Vault; copies must never be stored on local drives or sent by email.

## 4. Enhanced due diligence

4.1 Enhanced due diligence (EDD) applies where the customer is a politically exposed person (PEP) or a family member or close associate of a PEP; where the customer is resident in, or the transaction involves, a high-risk jurisdiction on the Bank's country list (Appendix C of POL-AML-001); where the source of funds for an opening deposit above £50,000 is unclear; and where the automated risk score places the customer in the **high** band.

4.2 EDD requires evidence of source of funds and source of wealth, approval by a Financial Crime Compliance officer before the account is activated, and an annual review of the relationship.

## 5. Sole traders and small businesses

5.1 For a sole trader, complete the individual ID&V in section 3 and obtain evidence of the trading name and business address (for example a VAT registration, a business rates bill or an HMRC letter).

5.2 For a limited company, obtain the certificate of incorporation, the registered office address, the names of all directors, and the identity of every beneficial owner holding 25% or more. Each beneficial owner and each director who will operate the account completes the individual ID&V.

## 6. Ongoing verification

6.1 Customer records are re-verified every **3 years** for standard-risk customers and every **12 months** for high-risk customers. Re-verification may be completed electronically where the Verifi-ID check passes.

6.2 If a customer cannot be re-verified within 60 days of the due date, the account is restricted to receiving credits only until verification is completed.

## 7. Failure to verify

Where a customer cannot provide acceptable documents, the application is declined and the customer is told which documents would be acceptable. Colleagues must not open an account "pending documents". Any attempt to provide forged or altered documents must be reported to Financial Crime Compliance under POL-AML-007 on the same day.

## 8. Record keeping

ID&V records, including copies of documents and the results of electronic checks, are retained for **5 years after the end of the customer relationship** in line with POL-DP-002.

## 9. Related documents

POL-AML-001 Anti-Money Laundering Policy; POL-AML-007 Suspicious Activity Reporting Policy; POL-DP-002 Data Protection and Records Retention Policy; PRC-KYC-004 Verifi-ID Operating Guide.
