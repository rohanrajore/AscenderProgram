---
id: PRC-COMP-009
title: Complaints Handling Procedure (DRAFT — not for use)
classification: internal
department: Customer Relations
status: draft
version: 3.0-draft
effective_date: 2026-11-01
owner: Head of Customer Relations
---

# Complaints Handling Procedure — DRAFT v3.0

> This draft is under review by the Conduct Risk Committee. Do not rely on it. The approved procedure remains v2.6 until this version is approved.

## 1. Purpose

This procedure describes how Meridian Financial records, investigates and resolves complaints from customers, and how it reports complaints to the regulator.

## 2. What counts as a complaint

Any expression of dissatisfaction, whether oral or written, and whether justified or not, about the provision of, or failure to provide, a financial service, that alleges the customer has suffered or may suffer financial loss, material distress or material inconvenience. A dispute about a card transaction is a **complaint** only if the customer is dissatisfied with how the dispute was handled; the dispute itself is handled under POL-CR-014.

## 3. Proposed time limits (draft)

3.1 Acknowledge every complaint within **1 business day** (currently 3 business days in v2.6).

3.2 Resolve simple complaints by the close of the **third business day** and send a summary resolution communication.

3.3 Send a final response within **8 weeks** of receipt (unchanged). Where a final response cannot be issued, write to the customer explaining why and informing them of their right to refer the matter to the Financial Ombudsman Service.

## 4. Proposed compensation bands (draft)

| Impact | Proposed band |
|---|---|
| Minor inconvenience | £25 to £75 |
| Material distress or inconvenience | £75 to £300 |
| Serious distress or repeated failure | £300 to £1,000 |
| Above £1,000 | Head of Customer Relations approval |

These bands are **proposed** and differ from the approved v2.6 bands. Colleagues must continue to apply the v2.6 bands until this draft is approved.

## 5. Root cause analysis

Every complaint is coded with a root cause from the Complaints Taxonomy. Root causes with more than 20 complaints in a quarter are escalated to the product owner for a remediation plan.

## 6. Related documents

POL-CR-014 Credit Card Dispute and Chargeback Handling Policy; POL-COND-005 Vulnerable Customers and Financial Difficulty Policy.
