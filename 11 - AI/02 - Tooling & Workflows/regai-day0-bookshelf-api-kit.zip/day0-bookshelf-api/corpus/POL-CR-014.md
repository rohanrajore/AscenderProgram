---
id: POL-CR-014
title: Credit Card Dispute and Chargeback Handling Policy
classification: confidential
department: Cards Operations
status: approved
version: 3.2
effective_date: 2026-04-01
supersedes: POL-CR-014 v2.4
owner: Head of Cards Operations
---

# Credit Card Dispute and Chargeback Handling Policy

## 1. Purpose and scope

This policy sets out how Meridian Financial ("the Bank") receives, assesses and resolves disputes raised by credit card customers, and how the Bank exercises its chargeback rights with the card schemes. It applies to all Meridian-issued consumer and small-business credit cards and to every colleague in Cards Operations, Customer Contact and Branch Network who handles a dispute at any stage. Debit card disputes are governed by POL-DB-009 and are out of scope here.

## 2. Definitions

A **dispute** is any assertion by a cardholder that a transaction on their statement is incorrect, unauthorised, or that goods or services paid for were not received or were not as described. A **chargeback** is the formal mechanism, operated under the rules of the relevant card scheme, by which the Bank reverses a transaction back to the merchant's acquirer. **Provisional credit** is a temporary credit applied to the cardholder's account while a dispute is investigated. The **dispute window** is the period within which a cardholder must notify the Bank of a dispute for the Bank to raise a chargeback.

## 3. Dispute window and time limits

3.1 A cardholder must notify the Bank of a disputed transaction within **120 days** of the transaction posting date. This is the scheme chargeback window applied by the Bank across all card products from the effective date of this version. Disputes notified after 120 days are logged and investigated as customer complaints under PRC-COMP-009 but cannot be pursued as a chargeback.

3.2 For recurring transactions (subscriptions), the 120-day window runs from the posting date of the most recent disputed instalment, not from the date the subscription was first set up.

3.3 The Bank must acknowledge every dispute in writing within **2 business days** of receipt and must reach a decision, or issue provisional credit, within **10 business days** of receipt. Where the scheme process requires a longer investigation, the cardholder must be informed in writing of the expected timeline.

3.4 Colleagues must record the date and channel of first notification in the dispute case system (Cardinal) at the moment the dispute is received. The notification date, not the case creation date, determines eligibility against the 120-day window.

## 4. Dispute categories

4.1 **Unauthorised transaction.** The cardholder states they did not make or authorise the transaction. The card must be blocked immediately and a replacement issued under PRC-CR-030. Fraud Operations is notified automatically by Cardinal.

4.2 **Goods or services not received.** The cardholder paid but did not receive the goods or service. The cardholder must first have attempted to resolve the matter with the merchant; evidence of that attempt (an email, chat transcript or call reference) must be attached to the case.

4.3 **Not as described or defective.** Goods or services materially differed from what was agreed. The case must include a description of the discrepancy and, where the goods were returned, proof of return.

4.4 **Duplicate or incorrect amount.** The transaction was processed twice or for the wrong amount. These cases are normally resolved directly with the merchant within 5 business days before any chargeback is raised.

4.5 **Credit not processed.** A refund agreed by the merchant has not appeared on the account within 15 business days of the merchant's confirmation.

## 5. Provisional credit

5.1 Provisional credit must be applied for unauthorised-transaction disputes within 10 business days of notification unless the Bank has reasonable grounds to suspect first-party fraud. For all other categories, provisional credit is at the discretion of a Dispute Officer (grade 4 or above) and must be justified in the case notes.

5.2 Provisional credit is reversed only if the investigation concludes against the cardholder, and the cardholder must be given 10 business days' written notice before the reversal is applied.

5.3 Interest and fees accrued on a disputed amount are refunded in full when a dispute is upheld.

## 6. Evidence and the cardholder declaration

6.1 Every dispute other than "duplicate or incorrect amount" requires a completed **Cardholder Dispute Declaration, form FRM-CD-7**, signed by the cardholder (electronic signature through the app is acceptable). A dispute cannot progress to chargeback without FRM-CD-7 on file.

6.2 Evidence must be stored in Cardinal against the case, never in personal drives or email folders. Evidence containing full card numbers must be redacted to the last four digits before storage (see POL-DP-002).

## 7. Roles and authority

| Role | Authority |
|---|---|
| Customer Contact agent | Log the dispute, collect FRM-CD-7, block card for unauthorised category |
| Dispute Officer (grade 4+) | Assess, apply provisional credit, raise chargeback, close cases up to £5,000 |
| Senior Dispute Officer (grade 6+) | Close cases above £5,000, approve exceptions to the dispute window |
| Head of Cards Operations | Approve write-offs above £25,000 and policy exceptions |

7.1 Exceptions to the 120-day window may be approved by a Senior Dispute Officer only where the cardholder was demonstrably prevented from notifying the Bank (for example hospitalisation) and the scheme rules still permit a chargeback.

## 8. Customer communication

Cardholders must be told, at first notification, what the Bank needs from them, the expected timeline, and that a provisional credit may be reversed. Template letters CR-L01 to CR-L06 in the Communications Library are the only approved wording. Colleagues must not promise an outcome before the investigation concludes.

## 9. Record keeping

Dispute records are retained for **7 years** from case closure under POL-DP-002. Chargeback documentation submitted to a scheme is retained for the same period.

## 10. Review

This policy is reviewed annually by the Head of Cards Operations and approved by the Retail Risk Committee. Version 3.2 extends the dispute window from 90 days to 120 days in line with the scheme rule change effective 1 April 2026 and replaces version 2.4 in full.
