---
id: PRC-OPS-011
title: Branch Cash Handling Procedure
classification: confidential
department: Branch Operations
status: approved
version: 7.0
effective_date: 2025-09-01
owner: Head of Branch Operations
---

# Branch Cash Handling Procedure

## 1. Purpose

This procedure sets out how cash is received, stored, counted, transported and reconciled in Meridian Financial branches. It is classified confidential because it describes holding limits and security routines. It applies to all branch colleagues and to the cash-in-transit contractor.

## 2. Cash limits

2.1 Each branch has an **overnight vault limit** set by Branch Operations based on the branch's insurance category. The limit is recorded in the branch profile on OpsHub and reviewed annually. Cash above the limit must be collected by the cash-in-transit contractor on the same day.

2.2 Each teller position may hold a maximum of **£15,000** in the till during the day. Cash above this is transferred to the vault using the till-to-vault transfer in the Teller system, witnessed by a second colleague.

2.3 A single cash withdrawal above **£5,000** requires ID&V of the customer under PRC-KYC-003 and approval by the branch manager or deputy in the Teller system. Withdrawals above **£10,000** require 24 hours' notice from the customer so that the branch can order cash.

2.4 Any single cash deposit of **£8,000** or more, or a series of deposits by the same customer totalling £8,000 or more in one day, triggers the enhanced identification step in PRC-KYC-003 and must be recorded with the source-of-funds question answered.

## 3. Opening and closing

3.1 The vault is opened under **dual control**: two colleagues, each holding one part of the combination, must be present. Neither part may be written down or shared.

3.2 On opening, each teller counts their till float and confirms it against the Teller system balance before serving the first customer. Discrepancies of any amount are reported to the branch manager before trading begins.

3.3 On closing, each teller balances their till. The branch manager or deputy reconciles all tills and the vault against the Teller system and records the result in the Daily Cash Reconciliation on OpsHub.

## 4. Discrepancies

4.1 A till difference of **£20 or less** is recorded and written off by the branch manager. A difference above £20 and up to **£250** requires a recount by a second colleague and a note of the likely cause. A difference above £250, or any pattern of repeated small differences at the same till, is reported to Branch Operations and Internal Audit on the same day through the Cash Discrepancy form on OpsHub.

4.2 Tellers must never make good a difference from their own money, and must never carry a difference forward to the next day.

## 5. Counterfeit notes

Suspected counterfeit notes are retained, not returned to the customer. The teller completes the Suspect Note form, gives the customer a receipt, and the note is sent to the Bank of England through the weekly cash-in-transit collection. The customer is not reimbursed unless the note is confirmed genuine.

## 6. Cash in transit

6.1 Collections and deliveries are made only by the contracted cash-in-transit provider and only to colleagues named on the branch's authorised signatory list. The courier's identity card is checked against the photograph on OpsHub before the door is opened.

6.2 Cash is packed in tamper-evident bags; the bag serial number is recorded in the Teller system and on the courier's manifest. Both the branch colleague and the courier sign the manifest.

## 7. Security routines

Tills are locked whenever the teller leaves the position, even briefly. Cash is never counted in view of the public area; large counts are done in the back office. Colleagues must not discuss cash holdings, delivery times or vault limits outside the branch, including in messaging apps. Any attempt by a customer or visitor to obtain this information is reported to the branch manager and logged as a security incident.

## 8. Record keeping

Daily Cash Reconciliation records, transfer records and discrepancy forms are retained for **6 years** on OpsHub in line with POL-DP-002.

## 9. Related documents

PRC-KYC-003 Customer Identification and Verification Procedure; POL-AML-007 Suspicious Activity Reporting Policy; PRC-OPS-014 Branch Physical Security Procedure.
