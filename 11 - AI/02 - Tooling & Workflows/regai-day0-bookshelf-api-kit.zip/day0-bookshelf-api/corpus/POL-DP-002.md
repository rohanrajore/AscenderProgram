---
id: POL-DP-002
title: Data Protection and Records Retention Policy
classification: internal
department: Legal and Data Protection
status: approved
version: 5.1
effective_date: 2026-01-01
owner: Data Protection Officer
---

# Data Protection and Records Retention Policy

## 1. Purpose

This policy sets out how Meridian Financial collects, uses, stores, shares and disposes of personal data and business records, in compliance with data protection law and the Bank's regulatory record-keeping obligations. It applies to all colleagues, contractors and suppliers who process data on the Bank's behalf, and to every system, including AI-assisted tools.

## 2. Data classification

Every document and data set is assigned one of three classifications by its owner, and the classification determines who may access it and how it must be handled.

| Classification | Meaning | Examples |
|---|---|---|
| **Internal** | For any Meridian colleague; not for external release | Product handbooks, most procedures, HR policies |
| **Confidential** | For colleagues with a business need; disclosure would harm the Bank or customers | Dispute handling rules, cash limits, pricing models |
| **Restricted** | For named individuals or a cleared team only; disclosure could cause serious harm or breach law | Financial crime detection rules, investigation files, unreleased results |

2.1 A document's classification, owning department and status (**draft**, **approved**, **superseded**, **withdrawn**) are recorded in its metadata in the Document Library. Only **approved** documents may be relied on for decisions or quoted to customers; drafts and superseded versions are retained for reference only.

2.2 Any system that indexes, searches or summarises Bank documents — including search tools and AI assistants — must apply the document's classification and status **at the point of retrieval**, so that a user only ever receives content they are cleared to see and that is currently approved. Indexing a restricted document into a tool available to uncleared users is a reportable data incident.

## 3. Lawful processing of personal data

3.1 Personal data is processed only for a documented purpose with a lawful basis recorded in the Record of Processing Activities. Colleagues must not use customer data for any purpose other than the one for which it was collected.

3.2 Special category data (health, ethnicity, religion, biometrics and similar) and criminal offence data require an additional condition and the approval of the Data Protection Officer before any new processing begins.

## 4. Data minimisation and personal data in systems

4.1 Collect only the data needed for the purpose. Forms, tool schemas and logs must not capture personal data "in case it is useful".

4.2 Full card numbers, account numbers, passwords, one-time codes and identity document numbers must never be written to application logs, chat transcripts, tickets or prompts sent to an AI model. Where a reference is required, use the last four digits or an internal token.

4.3 Customer data must remain within the Bank's approved UK and EEA hosting regions. Transfer to any other region, including through a supplier's or a model provider's infrastructure, requires a transfer risk assessment approved by the Data Protection Officer.

## 5. Individual rights

Customers may request access to their data, correction, erasure, restriction, portability and objection. Requests are logged in the Rights Request register and answered within **one month** (extendable by two months for complex requests). Colleagues who receive a request through any channel must forward it to the Data Protection team on the same day.

## 6. Records retention schedule

Records are retained for the period required by law or regulation and then securely destroyed. The principal periods are:

| Record | Retention period |
|---|---|
| Customer identification and verification records | 5 years after the end of the relationship |
| Account and transaction records | 7 years after the end of the relationship |
| Credit card dispute and chargeback records | 7 years from case closure |
| Suspicious activity reports and related correspondence | 5 years from the report date |
| Branch cash reconciliation records | 6 years |
| Complaint files | 5 years from closure |
| Employee records | 6 years after employment ends |
| Marketing consent records | For as long as the consent is relied on, plus 2 years |
| System audit logs for regulated processes | 7 years |

6.1 A record subject to a legal hold, a regulatory request or an open investigation is retained until the hold is lifted, regardless of the schedule.

## 7. Data incidents

Any actual or suspected loss, unauthorised disclosure or corruption of personal data is reported to the Data Protection team through the Incident form within **24 hours** of discovery. The Data Protection Officer decides within 72 hours whether the regulator must be notified.

## 8. Related documents

POL-IS-004 Information Security Policy; PRC-IT-021 Access Request and Privileged Access Procedure; POL-AML-007 Suspicious Activity Reporting Policy.
