---
id: HB-SAV-002
title: Everyday Saver Account — Product Handbook
classification: internal
department: Retail Products
status: approved
version: 2.1
effective_date: 2026-03-01
owner: Head of Savings Products
---

# Everyday Saver Account — Product Handbook

## 1. Product summary

The Everyday Saver is Meridian Financial's instant-access savings account for personal customers aged 16 and over who are resident in the UK. It pays a variable rate of interest, allows unlimited deposits and withdrawals without notice, and can be opened with a minimum of **£1**. The account is available through the mobile app, the web and branches. It is not available to businesses, trusts or customers who already hold two Everyday Saver accounts.

## 2. Eligibility

| Criterion | Requirement |
|---|---|
| Age | 16 or over |
| Residency | UK resident for tax purposes |
| Existing relationship | Not required — the account can be a customer's first Meridian product |
| Maximum accounts | Two per customer (sole or joint) |
| Joint accounts | Permitted, maximum two holders, both must complete ID&V |

## 3. Interest

3.1 Interest is variable and tiered by balance. The current tiers are published on the Rates page and in the app; colleagues must never quote a rate from memory. As at the effective date of this handbook the tiers are: **3.10% AER** on balances from £1 to £9,999.99; **3.40% AER** on balances from £10,000 to £49,999.99; **3.60% AER** on balances of £50,000 and above. The rate for the tier applies to the whole balance, not just the portion above the threshold.

3.2 Interest is calculated daily and paid **monthly** on the anniversary of the account opening date. Customers may choose to have interest paid into the Everyday Saver itself or into a Meridian current account.

3.3 The Bank may change the variable rate at any time. Decreases are notified to customers at least **14 days** in advance by app notification and email; increases may be applied without notice.

## 4. Deposits and withdrawals

4.1 Deposits may be made by transfer from any UK bank account, by standing order, by cash or cheque in branch, and by card payment in the app up to £5,000 per day.

4.2 Withdrawals are instant to a nominated Meridian current account and take one business day to an external UK account by Faster Payments. There is no withdrawal limit on the number of withdrawals, but a single external withdrawal is capped at **£25,000** per day for security reasons. Larger withdrawals must be split across days or requested in branch with ID&V.

4.3 The maximum balance is **£1,000,000**. Deposits that would take the balance above this limit are returned to the sending account.

## 5. Fees

The Everyday Saver has no monthly fee, no withdrawal fee and no closure fee. The only charge that can apply is the CHAPS fee of £20 for a same-day high-value withdrawal requested in branch.

## 6. Opening and closing

6.1 Opening in the app takes around 5 minutes for an existing customer. A new customer must complete ID&V under PRC-KYC-003 first.

6.2 Customers may close the account at any time with no penalty. Interest accrued to the closing date is paid on closure.

6.3 A customer may change their mind within **14 days** of opening (the cancellation period); on cancellation the balance and any interest accrued are returned in full.

## 7. Tax

Interest is paid **gross**. Customers are responsible for declaring interest above their Personal Savings Allowance to HMRC. The Bank reports interest paid to HMRC annually. Colleagues must not give tax advice; customers with questions are directed to gov.uk or a tax adviser.

## 8. Protection

Eligible deposits are protected by the Financial Services Compensation Scheme up to **£85,000** per depositor per authorised institution. Meridian Financial is one authorised institution, so the limit is shared across all a customer's Meridian accounts.

## 9. Dormancy

An account with no customer-initiated transaction for **15 years** is treated as dormant and transferred to the unclaimed assets scheme. Customers can reclaim the balance at any time with proof of identity.

## 10. Common customer questions

**Can I have a joint Everyday Saver with someone who is not a Meridian customer?** Yes, but they must complete ID&V before the account opens.

**Will my rate change if my balance drops below a tier threshold?** Yes — the tier is checked daily and the rate for that day follows the closing balance.

**Can I set up regular payments out?** Standing orders out of the account are not supported; customers should use a current account for regular payments.

## 11. Related documents

PRC-KYC-003 Customer Identification and Verification Procedure; POL-DP-002 Data Protection and Records Retention Policy; HB-SAV-003 Fixed Rate Saver Product Handbook.
