---
id: POL-CR-014-v2
title: Credit Card Dispute and Chargeback Handling Policy (superseded)
classification: confidential
department: Cards Operations
status: superseded
version: 2.4
effective_date: 2024-07-01
superseded_by: POL-CR-014 v3.2
owner: Head of Cards Operations
---

# Credit Card Dispute and Chargeback Handling Policy

## 1. Purpose and scope

This policy sets out how Meridian Financial ("the Bank") receives, assesses and resolves disputes raised by credit card customers, and how the Bank exercises its chargeback rights with the card schemes. It applies to all Meridian-issued consumer and small-business credit cards and to every colleague in Cards Operations, Customer Contact and Branch Network who handles a dispute at any stage.

## 2. Definitions

A **dispute** is any assertion by a cardholder that a transaction on their statement is incorrect, unauthorised, or that goods or services paid for were not received or were not as described. A **chargeback** is the formal mechanism, operated under the rules of the relevant card scheme, by which the Bank reverses a transaction back to the merchant's acquirer. **Provisional credit** is a temporary credit applied to the cardholder's account while a dispute is investigated.

## 3. Dispute window and time limits

3.1 A cardholder must notify the Bank of a disputed transaction within **90 days** of the transaction posting date. Disputes notified after 90 days are logged and investigated as customer complaints but cannot be pursued as a chargeback.

3.2 For recurring transactions the 90-day window runs from the posting date of the most recent disputed instalment.

3.3 The Bank must acknowledge every dispute in writing within **3 business days** of receipt and must reach a decision, or issue provisional credit, within **15 business days** of receipt.

3.4 Colleagues must record the date and channel of first notification in the dispute case system (Cardinal) at the moment the dispute is received.

## 4. Dispute categories

4.1 **Unauthorised transaction.** The cardholder states they did not make or authorise the transaction. The card must be blocked immediately and a replacement issued.

4.2 **Goods or services not received.** The cardholder paid but did not receive the goods or service. The cardholder must first have attempted to resolve the matter with the merchant.

4.3 **Not as described or defective.** Goods or services materially differed from what was agreed.

4.4 **Duplicate or incorrect amount.** The transaction was processed twice or for the wrong amount.

4.5 **Credit not processed.** A refund agreed by the merchant has not appeared on the account within 15 business days.

## 5. Provisional credit

5.1 Provisional credit must be applied for unauthorised-transaction disputes within 15 business days of notification unless the Bank has reasonable grounds to suspect first-party fraud.

5.2 Provisional credit is reversed only if the investigation concludes against the cardholder, with 10 business days' written notice.

## 6. Evidence

6.1 Every dispute other than "duplicate or incorrect amount" requires a completed Cardholder Dispute Declaration, form FRM-CD-6, signed by the cardholder.

6.2 Evidence must be stored in Cardinal against the case.

## 7. Roles and authority

Dispute Officers (grade 4+) may close cases up to £5,000; Senior Dispute Officers (grade 6+) above £5,000; the Head of Cards Operations approves write-offs above £25,000.

## 8. Record keeping

Dispute records are retained for 7 years from case closure.

## 9. Review

This policy is reviewed annually. Version 2.4 is effective from 1 July 2024.
