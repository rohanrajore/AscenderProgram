---
id: POL-HR-005
title: Business Expenses and Travel Policy
classification: internal
department: People
status: approved
version: 6.2
effective_date: 2026-01-01
owner: Head of Reward and Policy
---

# Business Expenses and Travel Policy

## 1. Purpose and principles

This policy explains what expenses Meridian Financial will reimburse, the limits that apply, and how to claim. Colleagues are expected to spend the Bank's money as carefully as their own: choose the most economical reasonable option, claim promptly, and keep receipts. The policy applies to all employees and to contractors whose contract allows expenses.

## 2. How to claim

2.1 Claims are submitted in the Expenses module of PeopleHub within **60 days** of the expense being incurred. Claims older than 60 days are rejected unless the line manager records an exceptional reason.

2.2 Every claim line must have an itemised receipt attached (a card slip alone is not sufficient). Receipts under **£10** are not required but the expense must still be itemised.

2.3 Claims are approved by the line manager. Claims above **£1,000** in a single submission also require approval by the cost-centre owner. Approved claims are paid with the next payroll run.

2.4 The corporate card must be used for travel, accommodation and hospitality wherever the colleague holds one. Personal card use is reimbursed but should be the exception.

## 3. Travel

3.1 **Rail.** Standard class for all journeys. First class may be booked only when the fare is equal to or lower than the standard fare available at the time of booking, and the comparison must be attached to the claim. Book through the travel portal (Voyager) at least 7 days ahead where possible to obtain advance fares.

3.2 **Air.** Economy class for flights under 6 hours. Premium economy is permitted for flights of 6 hours or more. Business class requires approval from an Executive Committee member. Flights must be booked through Voyager.

3.3 **Mileage.** Use of a private car for business travel is reimbursed at **45 pence per mile** for the first 10,000 business miles in the tax year and **25 pence per mile** thereafter. Mileage between home and the colleague's contractual place of work is commuting and is not claimable. Colleagues must hold business-use insurance.

3.4 **Taxis and ride-hailing.** Permitted where public transport is impractical, for journeys before 7am or after 9pm, or when carrying equipment. The reason must be stated on the claim.

3.5 **Parking and tolls.** Reimbursed with receipts. Parking fines and speeding penalties are never reimbursed.

## 4. Accommodation

4.1 Hotel stays are booked through Voyager. The nightly rate cap, room only, is **£150 in London** and **£110 elsewhere in the UK**. International caps are listed in Appendix A of this policy on PeopleHub.

4.2 Where the cap cannot be met (for example during a major event), the colleague must attach evidence of the search and obtain line manager approval before booking.

4.3 Staying with friends or family instead of a hotel may be claimed at a flat **£25 per night** without receipts.

## 5. Meals and subsistence

5.1 When travelling on business away from the normal place of work for a full day, meals are reimbursed up to **£10 for breakfast** (if travel starts before 7am), **£12 for lunch** and **£30 for dinner** (if the colleague is away after 8pm or staying overnight). Alcohol is not reimbursed with individual meals.

5.2 Meals at the colleague's normal place of work are not claimable.

## 6. Hospitality and entertaining

6.1 Entertaining customers or external partners requires prior approval from the line manager and must be recorded in the Gifts and Hospitality Register under POL-COND-002 when the value exceeds **£50 per head**.

6.2 Team events are funded from the team budget, up to **£40 per head** twice a year, approved by the cost-centre owner.

## 7. Working from home and equipment

7.1 The Bank provides a laptop, monitor, keyboard and chair for colleagues who work from home regularly. These are ordered through ServiceHub, not claimed as expenses.

7.2 Broadband and utility costs are not reimbursed. Colleagues may claim the HMRC working-from-home tax relief directly.

## 8. What is never reimbursed

Personal purchases, fines and penalties, commuting costs, expenses for family members or partners, alcohol outside approved hospitality, upgrades beyond the class limits in this policy, and any expense without a business purpose.

## 9. Breaches

Knowingly submitting a false or inflated claim is gross misconduct under the Disciplinary Procedure PRC-HR-011 and may be reported as fraud.

## 10. Related documents

POL-COND-002 Gifts and Hospitality Policy; PRC-HR-011 Disciplinary Procedure; Voyager travel portal user guide.
