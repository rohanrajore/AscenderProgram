---
id: PRC-IT-021
title: Access Request and Privileged Access Procedure
classification: internal
department: Technology
status: approved
version: 3.0
effective_date: 2026-02-10
owner: Head of Identity and Access Management
---

# Access Request and Privileged Access Procedure

## 1. Purpose

This procedure describes how colleagues request, obtain, review and lose access to Meridian Financial systems, and the additional controls that apply to privileged access. It implements POL-IS-004 (Information Security Policy) and applies to employees, contractors and third-party staff.

## 2. Principles

Access is granted on the basis of **least privilege**: a colleague receives the minimum access required for their current role and nothing more. Access is **role-based**: standard access is defined per job role in the Access Catalogue and is provisioned automatically when a colleague joins or changes role. Access that is not in the role profile requires an individual request and approval. All access is **time-bound**: contractor and privileged access expires and must be renewed.

## 3. Requesting standard access

3.1 Standard access requests are raised in the ServiceHub portal under "Access Request". The requester selects the application, the access level from the Access Catalogue, and the business justification.

3.2 The request is routed to the colleague's **line manager** for approval and then to the **application owner**. Both approvals are required. Approvals not completed within **5 business days** lapse and the request must be re-raised.

3.3 Access is provisioned automatically by the identity platform (Meridian IDP) on completion of the approvals, and the requester is notified. Where automation is not available for an application, the Access Operations team provisions manually within 2 business days.

## 4. Privileged access

4.1 Privileged access means any access that can change production configuration, read or modify production customer data outside the normal application interface, administer identities, or alter security controls. Examples include database administrator roles, cloud project owner or editor roles, domain administration, and root or sudo on production servers.

4.2 Privileged access is granted only to named individuals, never to shared accounts. It is provisioned as a **separate privileged identity** (suffix `-adm`) that must not be used for email, browsing or day-to-day work.

4.3 Privileged access requests require approval by the line manager, the application owner **and** the Information Security team. The maximum grant period is **90 days**, after which access is removed automatically unless renewed by a new request.

4.4 All privileged sessions are recorded by the privileged access management platform (Keep). Colleagues must connect through Keep; direct connections with privileged credentials are blocked at the network layer and generate a security alert.

4.5 Privileged access to production is **just-in-time**: the `-adm` identity holds no standing entitlements. A colleague activates a specific entitlement in Keep for a maximum of **8 hours**, citing a change record or incident number. Activation without a valid change or incident reference is refused.

## 5. Service accounts and machine identities

5.1 Service accounts are requested through ServiceHub under "Machine Identity" and are owned by a named colleague who is accountable for the account's use and credential rotation.

5.2 Service account credentials are stored in the enterprise secrets vault and rotated at least every **180 days**. Credentials must never be stored in source code, configuration files, tickets, chat messages or documents.

5.3 A service account is granted only the permissions the workload needs. Broad roles such as cloud project owner or editor are not permitted for service accounts; a custom role must be defined.

## 6. Access review

6.1 Line managers certify all access held by their direct reports every **6 months** through the access certification campaign in Meridian IDP. Uncertified access is removed automatically 10 business days after the campaign closes.

6.2 Privileged access is certified **quarterly** by the application owner and Information Security.

## 7. Leavers and movers

7.1 When a colleague leaves, all access is removed on the last working day. The HR system triggers de-provisioning automatically; line managers must confirm that no shared credentials were known to the leaver and rotate any that were.

7.2 When a colleague changes role, access from the previous role is removed **30 days** after the move unless the new line manager requests retention through a standard access request.

## 8. Emergency access

In an incident, the Incident Commander may authorise emergency privileged access ("break-glass") for a maximum of 4 hours. Break-glass use is reviewed by Information Security within 1 business day and must be followed by a retrospective access request.

## 9. Related documents

POL-IS-004 Information Security Policy; PRC-IT-022 Secrets Management Standard; PRC-IT-025 Incident Management Procedure.
