---
id: HB-BLB-001
title: Buy Local Bonds — Product Handbook
classification: restricted
department: Treasury Products
status: approved
version: 1.2
effective_date: 2026-06-01
owner: Head of Treasury Products
---

# Buy Local Bonds — Product Handbook

## 1. Product summary

Buy Local Bonds (BLB) is Meridian Financial's community investment product. Customers lend to a pool of vetted local infrastructure and small-business projects in their region and receive a fixed return over a fixed term. BLB is a **restricted** handbook because the product is in a limited regional launch and its pricing and project pipeline are commercially sensitive. Only colleagues in Treasury Products, the BLB launch team and cleared Customer Contact specialists may access this document.

## 2. Key terms

| Term | Detail |
|---|---|
| Minimum investment | £500 |
| Maximum investment | £50,000 per customer across all series |
| Term | 3 years or 5 years |
| Fixed return | 4.25% per year (3-year series), 4.75% per year (5-year series) |
| Interest payment | Annually, on the series anniversary |
| Early withdrawal | Not permitted, except on death or diagnosis of terminal illness |
| Launch regions | North West and South West England (Series 1) |

## 3. Eligibility

Investors must be aged 18 or over, UK resident, and hold a Meridian current account of at least 6 months' standing. BLB is **not** a savings account and is **not** covered by the Financial Services Compensation Scheme; every customer must confirm they have read the Key Information Document before investing. Customers who self-identify as vulnerable under POL-COND-005 are referred to a specialist before any investment is accepted.

## 4. How the money is used

Funds raised in each series are lent to projects selected by the BLB Investment Committee against the published criteria: located in the launch region, creating or protecting local employment, with independent credit assessment at grade B+ or better. The Bank retains a first-loss reserve of **5%** of each series to absorb project defaults before investor returns are affected.

## 5. Series calendar

Series 1 opens on 1 June 2026 and closes on 31 August 2026 or when the £20 million cap is reached, whichever is earlier. Series 2 is planned for the first quarter of 2027 in the North East and Scotland, subject to Executive Committee approval.

## 6. Customer communications

Only the approved BLB scripts (BLB-S01 to BLB-S04) may be used. Colleagues must not describe BLB as "savings", "guaranteed" or "protected". Any customer question the scripts do not cover is referred to the BLB launch team mailbox.

## 7. Related documents

POL-COND-005 Vulnerable Customers and Financial Difficulty Policy; BLB Key Information Document; PRC-KYC-003 Customer Identification and Verification Procedure.
