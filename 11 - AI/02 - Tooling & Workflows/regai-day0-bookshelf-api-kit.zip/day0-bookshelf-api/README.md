# Day 0 — get bookshelf-api running again

The assistant the cohort builds over three days acts on a library service. That service,
**bookshelf-api**, was deployed in the earlier Google Cloud sessions and is no longer running.
This puts it back, in each learner's own sandbox project, before day 1 starts.

Roughly ten minutes per project, most of it waiting for the build.

## What gets created

| Thing | Where |
|---|---|
| Artifact Registry repository `regai` | your region |
| Container image `bookshelf-api:v1` | that repository |
| Cloud Run service `bookshelf-api` | IAM-protected, one instance |

## Steps

```bash
cd ~/day0-bookshelf-api
gcloud config set project <your-sandbox-project>
export REGION=asia-south1          # or wherever the cohort's projects live
bash deploy.sh
bash verify.sh
```

`deploy.sh` enables the three APIs, creates the Artifact Registry repository if it is missing,
builds the image with Cloud Build and deploys to Cloud Run. It is idempotent — re-running it
after a failure is safe.

`verify.sh` should print `OK` on every line and show `POL-CR-014 | approved | confidential`.

Keep the URL it prints. Every learner needs it on day 2:

```bash
export BOOKSHELF_API_URL=https://bookshelf-api-xxxxx-el.a.run.app
```

## Two deliberate choices, both worth explaining to the room

**The service is not public.** It deploys with `--no-allow-unauthenticated`, so every call
carries a Google identity token:

```bash
curl -H "Authorization: Bearer $(gcloud auth print-identity-token)" "$BOOKSHELF_API_URL/health"
```

That is better practice than a public endpoint, and it avoids the Domain-restricted-sharing org
policy that blocks public Cloud Run services in sandbox orgs created after May 2024. It also
sets up day 2, where the assistant has to authenticate to this service as itself rather than
as a person.

**The catalogue lives in memory.** `--min-instances=1 --max-instances=1` keeps one instance
alive so reservations stay put for the three days. That is not how you would run it for real,
and saying so is a good five-minute conversation about stateless containers. `POST /reset`
puts the library back to thirteen books and three copies each.

## The reserve route the day-2 assistant uses

`POST /books/{id}/reserve` reserves one to three copies in a single call and accepts an
`Idempotency-Key` header. A repeated key returns the original reservation and does not
reserve again, so a client that lost the response can retry safely. Keys are kept in memory
(and cleared by `POST /reset`).

```bash
curl -X POST "$BOOKSHELF_API_URL/books/PRC-KYC-003/reserve" \
  -H "Authorization: Bearer $(gcloud auth print-identity-token)" \
  -H "Content-Type: application/json" -H "Idempotency-Key: demo-1" \
  -d '{"staff_id":"daniel","copies":1}'
```

Run the same command twice: the second response says `"replayed": true` and
`copies_available` does not move. If your service was deployed from an earlier copy of this
kit, run `bash deploy.sh` again; it rebuilds the image and rolls out a new revision.

## If something fails

| Symptom | Cause | Fix |
|---|---|---|
| `PERMISSION_DENIED` enabling services | Missing `roles/serviceusage.serviceUsageAdmin` | Ask the project owner, or enable the three APIs in the console |
| Build fails pulling `python:3.12-slim` | Egress restrictions on the build network | Use a Cloud Build private pool, or pre-pull into Artifact Registry |
| `403` from `verify.sh` | Your account lacks `roles/run.invoker` | `gcloud run services add-iam-policy-binding bookshelf-api --member="user:$(gcloud config get-value account)" --role=roles/run.invoker --region=$REGION` |
| Reservations reset mid-class | More than one instance served traffic | Confirm `--max-instances=1` on the deployed revision |

## Teardown, after the programme

```bash
gcloud run services delete bookshelf-api --region=$REGION -q
gcloud artifacts repositories delete regai --location=$REGION -q
```
