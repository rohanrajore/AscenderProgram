#!/usr/bin/env bash
# selftest.sh — every part of both labs, offline: FAKE_MODEL=1 FAKE_API=1.
#
#   bash scripts/selftest.sh                 # run and check
#   MEASURED=out.txt bash scripts/selftest.sh   # also keep every printout in out.txt
#
# Each part runs agent.py with that part's switches and checks the printed outcome, the
# same lines the lab manual tells learners to look for. The model is the scripted
# stand-in, so this proves the loop, the switches, the bounds and the failure handling;
# it says nothing about what Gemini itself will choose to do.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT="$(dirname "$HERE")"
PY="${PYTHON:-python3}"
cd "$KIT"          # so the printed commands work as written from the kit folder
FX="fixtures"
LOG="$(mktemp)"
STATE="$(mktemp)"
trap 'rm -f "$LOG" "$STATE"' EXIT

# Fresh defaults every run: no agent.env, a private catalogue file, no leftover switches.
export FAKE_MODEL=1 FAKE_API=1 FAKE_API_STATE="$STATE" AGENT_ENV=/nonexistent
export PYTHONDONTWRITEBYTECODE=1
for v in TOOLS GROUNDING MODE ALLOWED PARALLEL VALIDATE APPROVE APPROVE_CARD ROUTER \
         MAX_STEPS MAX_SECONDS MAX_COST_USD TOOLS_FOR_TASK FAULT RETURN_ERRORS RETRY \
         RETRY_BACKOFF IDEMPOTENCY FAKE_DELAY TOOLS_FILE; do unset "$v"; done

PASS=0; FAIL=0; LAST=""
FRM="Which form must a cardholder sign before a dispute can go to chargeback?"
RESERVE1="Reserve one copy of PRC-KYC-003 for daniel"
FOUR="Check how many copies of PRC-KYC-003 are left, reserve one copy for me, check again, then reserve one more"

log() { printf '%s\n' "$*" | tee -a "$LOG"; }
reset() { "$PY" agent.py --reset >/dev/null; }

quoted() {  # arguments as a person types them: quotes around anything with a space
  local out="" a
  for a in "$@"; do [[ "$a" == *" "* ]] && out+="\"$a\" " || out+="$a "; done
  printf '%s' "${out% }"
}
# run NAME [VAR=value ...] -- AGENT-ARGS...   runs agent.py, prints and records the output
run() {
  local name="$1"; shift
  local envs=()
  while [[ "$1" != "--" ]]; do envs+=("$1"); shift; done; shift
  log "## $name"
  log "\$ ${envs[*]:+${envs[*]} }python agent.py $(quoted "$@")"
  LAST="$(env "${envs[@]}" "$PY" agent.py "$@" 2>&1)"
  log "$LAST"; log ""
}
expect() {  # expect DESCRIPTION REGEX — the last output must contain a match
  if grep -qE -- "$2" <<<"$LAST"; then echo "   ok   $1"; PASS=$((PASS + 1))
  else echo "   FAIL $1  (wanted /$2/)"; FAIL=$((FAIL + 1)); fi
}
refute() {  # refute DESCRIPTION REGEX — the last output must not contain a match
  if grep -qE -- "$2" <<<"$LAST"; then echo "   FAIL $1  (found /$2/)"; FAIL=$((FAIL + 1))
  else echo "   ok   $1"; PASS=$((PASS + 1)); fi
}
count() {   # count DESCRIPTION REGEX N — exactly N matching lines
  local n; n="$(grep -cE -- "$2" <<<"$LAST")"
  if [[ "$n" == "$3" ]]; then echo "   ok   $1"; PASS=$((PASS + 1))
  else echo "   FAIL $1  ($n lines match /$2/, wanted $3)"; FAIL=$((FAIL + 1)); fi
}

log "# Day 2 and Day 3 measured outputs — FAKE_MODEL — offline (FAKE_MODEL=1 FAKE_API=1)"
log "# generated $(date -u +%Y-%m-%dT%H:%MZ) by scripts/selftest.sh. The model is the"
log "# scripted stand-in, not Gemini; the API is the in-process catalogue."
log ""

# ================================================================ Lab 1
log "# ---------------- Lab 1 — give the service a tool, and control when it fires"
reset
run "1-A no tools" -- --user daniel "$FRM"
expect "no tools sent" 'tools=\[\]'
expect "says it cannot" "cannot say"
refute "nothing ran on our side" "⚙ run"

run "1-B grounding on, daniel" GROUNDING=on -- --user daniel "$FRM"
expect "cited answer" "FRM-CD-7"
expect "grounding chunk listed" 'grounding: \[1\] Credit Card Dispute'
expect "server-side, no call from us" "no call from our side"
refute "nothing ran on our side" "⚙ run"
run "1-B grounding on, priya (filter stops at internal)" GROUNDING=on -- \
  --user priya "$FRM"
expect "refusal" "do not answer this"
expect "no chunks passed the filter" "no chunks returned"

reset
run "1-C reserve_book added" TOOLS=on TOOLS_FILE="$FX/tools.lab1c.json" -- \
  --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
expect "function_call" \
  'function_call reserve_book\(\{"book_id": "PRC-KYC-003", "copies": 2'
expect "ran, stock 3 -> 1" '⚙ run reserve_book.*"copies_available": 1'
expect "function_response" "← function_response reserve_book"
expect "confirmation" "text: Reserved 2 of PRC-KYC-003"
run "1-C lookup_stock already there" TOOLS=on TOOLS_FILE="$FX/tools.lab1c.json" -- \
  --user daniel "How many copies of PRC-KYC-003 are left?"
expect "lookup ran" "⚙ run lookup_stock"
expect "1 of 3 after the reservation" "1 of 3 copies available"

export TOOLS=on TOOLS_FILE="$FX/tools.lab1c.json"
reset
run "1-D MODE=NONE: talk only" MODE=NONE -- --user daniel "$RESERVE1"
expect "mode NONE sent" "mode=NONE"
refute "no tool ran" "⚙ run"
run "1-D MODE=ANY on hello: a pointless call" MODE=ANY -- --user daniel "hello"
expect "mode ANY sent" "mode=ANY"
expect "a call was forced" "⚙ run lookup_stock"
run "1-D ALLOWED=reserve_book: forced" MODE=ANY ALLOWED=reserve_book -- \
  --user daniel "hello"
expect "allowed list sent" 'allowed=\[reserve_book\]'
expect "reserve_book forced" "⚙ run reserve_book"
run "1-D two calls in one turn" -- --user daniel \
  "Reserve one copy of PRC-KYC-003 and PRC-CR-030 for daniel"
count "two function_calls" "← model  function_call reserve_book" 2
expect "both ran in one step" "steps=2 calls=2"
reset
run "1-D PARALLEL=off: one at a time" PARALLEL=off -- --user daniel \
  "Reserve one copy of PRC-KYC-003 and PRC-CR-030 for daniel"
expect "second call refused" "blocked: one action per turn"
expect "a second turn for the second call" "steps=3 calls=2"

reset
run "1-E description 'does things': wrong pick" TOOLS_FILE="$FX/tools.lab1e-bad.json" -- \
  --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
expect "lookup_stock chosen for a reserve request" "⚙ run lookup_stock"
refute "reserve_book not chosen" "⚙ run reserve_book"
run "1-E five near-duplicate names: collision" \
  TOOLS_FILE="$FX/tools.lab1e-dupes.json" -- \
  --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
expect "a look-alike chosen" "function_call reserve_book_for_staff"
expect "it has no implementation" "blocked: no implementation"
run "1-E pruned and renamed: fixed" TOOLS_FILE="$FX/tools.lab1e-fixed.json" -- \
  --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
expect "reserve_book ran" '⚙ run reserve_book.*"reservation_id"'

reset
run "1-F VALIDATE=on rejects in code" VALIDATE=on -- --user daniel \
  "Reserve five copies of PRC-KYC-003 for daniel"
expect "rejected before any call" "blocked: invalid args: copies=5 > maximum 3"
expect "no tool ran" "calls=0"
run "1-F VALIDATE=off: the API rejects instead" -- --user daniel \
  "Reserve five copies of PRC-KYC-003 for daniel"
expect "the network call was made and failed" "HTTP 422"
run "1-F APPROVE=off blocks reserve however asked" APPROVE=off -- \
  --user daniel "$RESERVE1"
expect "blocked" "blocked: needs approval"
FIRST=""
for i in 1 2 3; do
  run "1-F same request, run $i of 3" APPROVE=off -- --user daniel "$RESERVE1"
  BODY="$(grep -v '^steps=' <<<"$LAST")"   # everything but the elapsed-time line
  if [[ $i == 1 ]]; then FIRST="$BODY"
  elif [[ "$BODY" == "$FIRST" ]]; then expect "run $i identical to run 1" "."
  else echo "   FAIL run $i differs from run 1"; FAIL=$((FAIL + 1)); fi
done
run "1-F the caller was never the model's to choose" -- --user priya \
  "Reserve one copy of PRC-KYC-003 for daniel"
expect "caller mismatch blocked in code" "blocked: caller mismatch"

# ================================================================ Lab 2
log "# ---------------- Lab 2 — bound a workflow with approval and failure handling"
export TOOLS=on TOOLS_FILE="$FX/tools.lab2.json"
reset
run "2-A ROUTER=on: a stock question goes direct" ROUTER=on -- --user daniel \
  "how many copies of PRC-KYC-003 are left"
expect "route: direct" "route: direct"
expect "zero model calls" "steps=0 calls=1 tokens=0"
refute "no model turn" "→ model"
run "2-A ROUTER=on: a reservation goes to the model" ROUTER=on -- \
  --user daniel "$RESERVE1"
expect "route: model" "route: model"
expect "two model calls" "steps=2 calls=1"

reset
run "2-B MAX_STEPS=3: lookup, reserve, lookup — the fourth turn never happens" \
  MAX_STEPS=3 -- --user daniel "$FOUR"
expect "bound hit" "bound: MAX_STEPS=3 reached"
expect "three steps, three calls" "steps=3 calls=3"
count "lookup ran twice" "⚙ run lookup_stock" 2
count "reserve ran once" "⚙ run reserve_book" 1
expect "stock down by exactly one on the second lookup" \
  '⚙ run lookup_stock.*"copies_available": 2, "copies_total": 3'
reset
run "2-B MAX_SECONDS=1 (fake model takes 0.4s a turn)" MAX_SECONDS=1 FAKE_DELAY=0.4 -- \
  --user daniel "$FOUR"
expect "bound hit" "bound: MAX_SECONDS=1 reached"
refute "never reached the second reserve" "steps=[45]"
reset
run "2-B MAX_COST_USD=0.0003 (fake model: trips after turn 2)" MAX_COST_USD=0.0003 -- \
  --user daniel "$FOUR"
expect "bound hit" 'bound: MAX_COST_USD=0.0003 reached \(\$0\.000338\)'
expect "two steps, two calls" "steps=2 calls=2"
count "reserve ran once" "⚙ run reserve_book" 1

reset
run "2-C TOOLS_FOR_TASK=on: a lookup gets no reserve_book" TOOLS_FOR_TASK=on -- \
  --user daniel "How many copies of PRC-KYC-003 are left, and reserve it for daniel"
expect "tools sent shown, without reserve_book" \
  'task=lookup  tools=\[lookup_stock, search_bookshelf\]'
refute "no reservation possible" "⚙ run reserve_book"
expect "the model says so" "no tool for it is available"
run "2-C TOOLS_FOR_TASK=off: the same request reserves" -- \
  --user daniel "How many copies of PRC-KYC-003 are left, and reserve it for daniel"
expect "reserve_book ran" "⚙ run reserve_book"

reset
run "2-D APPROVE=ask, approved" APPROVE=ask -- --user daniel "$RESERVE1" < <(echo y)
expect "the card" "approval needed"
expect "copies left on the card" '│ copies   1  \(3 available now, 2 after\)'
expect "caller on the card" "│ caller   daniel — Daniel Okafor"
expect "approved and ran" "approval: y"
expect "reservation made" '"reservation_id"'
run "2-D APPROVE=ask, declined" APPROVE=ask -- --user daniel "$RESERVE1" < <(echo n)
expect "declined" "blocked: declined by approver"
run "2-D APPROVE_CARD=minimal: the bad card" APPROVE=ask APPROVE_CARD=minimal -- \
  --user daniel "$RESERVE1" < <(echo n)
expect "nothing to judge" 'approve reserve_book\? \[y/n\]'
refute "no book on the card" "│ book"

reset
for f in timeout 500 garbage; do
  run "2-E FAULT=$f RETURN_ERRORS=on" FAULT="$f" -- --user daniel "$RESERVE1"
  expect "fault injected" "fault: $f"
  expect "error returned to the model" '← function_response reserve_book \{"error"'
  expect "the model reports it" "I could not reserve"
done
run "2-E FAULT=500 RETURN_ERRORS=off" FAULT=500 RETURN_ERRORS=off -- \
  --user daniel "$RESERVE1"
expect "the run stops" "stop: not returned to the model"
refute "nothing sent back" "← function_response"
expect "one step only" "steps=1"

reset
run "2-F timeout-after-success, RETRY=2, IDEMPOTENCY=off" FAULT=timeout-after-success \
  RETRY=2 RETRY_BACKOFF=0.1 -- --user daniel "$RESERVE1"
expect "retried" "retry 1/2"
expect "the retry reserved again" '"copies_available": 1, "replayed": false'
run "2-F lookup_stock proves two reservations" -- --user daniel \
  "How many copies of PRC-KYC-003 are left?"
expect "stock down by 2" "1 of 3 copies available"
reset
run "2-F timeout-after-success, RETRY=2, IDEMPOTENCY=on" FAULT=timeout-after-success \
  RETRY=2 RETRY_BACKOFF=0.1 IDEMPOTENCY=on -- --user daniel "$RESERVE1"
expect "one key for the request" "idempotency-key: agent-"
expect "the retry was replayed, not repeated" '"copies_available": 2, "replayed": true'
run "2-F lookup_stock proves one reservation" -- --user daniel \
  "How many copies of PRC-KYC-003 are left?"
expect "stock down by 1" "2 of 3 copies available"

# ================================================================ result
echo
echo "selftest: $PASS passed, $FAIL failed"
if [[ -n "${MEASURED:-}" ]]; then cp "$LOG" "$MEASURED"; echo "printouts: $MEASURED"; fi
[[ $FAIL -eq 0 ]]
