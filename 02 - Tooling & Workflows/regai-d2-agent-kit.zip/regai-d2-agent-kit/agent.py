#!/usr/bin/env python3
"""agent.py — the Bookshelf assistant as a tool-using loop on Gemini (Vertex AI).

    python agent.py --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
    python agent.py --reset          # catalogue back to 3 copies of every book
    python agent.py --selftest       # every lab part offline (FAKE_MODEL=1 FAKE_API=1)

Learners edit tools.json and agent.env only. This file is meant to be read top to bottom:
config → tools registry → the model (real and fake) → the loop → printing → main.

Every switch in agent.env is one lab step; a switch given on the command line overrides
the file for that run, e.g.  MODE=NONE python agent.py --user daniel "hello".
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path
from types import SimpleNamespace as NS

import tools_impl
from tools_impl import CALLERS, FRM_ANSWER, FRM_CHUNK, REFUSAL, TITLES

KIT = Path(__file__).resolve().parent

# ============================================================ config
# Defaults are the Lab 1 Part A state. agent.env overrides these; the process environment
# overrides agent.env (so scripts/selftest.sh can flip one switch per run).
DEFAULTS = {
    "PROJECT_ID": "", "LOCATION": "global", "MODEL": "gemini-2.5-flash",
    "DATASTORE_ID": "bookshelf-ds", "APP_ID": "bookshelf-app", "BOOKSHELF_API_URL": "",
    "TOOLS": "off", "GROUNDING": "off", "MODE": "AUTO", "ALLOWED": "", "PARALLEL": "on",
    "VALIDATE": "off", "APPROVE": "auto", "APPROVE_CARD": "full", "ROUTER": "off",
    "MAX_STEPS": "10", "MAX_SECONDS": "60", "MAX_COST_USD": "0.05",
    "PRICE_INPUT_PER_M": "0.30", "PRICE_OUTPUT_PER_M": "2.50", "TOOLS_FOR_TASK": "off",
    "FAULT": "none", "RETURN_ERRORS": "on", "RETRY": "0", "RETRY_BACKOFF": "0.5",
    "IDEMPOTENCY": "off", "FAKE_MODEL": "0", "FAKE_API": "0", "FAKE_DELAY": "0",
    "TOOLS_FILE": str(KIT / "tools.json"),
}


def load_config() -> dict:
    cfg = dict(DEFAULTS)
    env_file = Path(os.environ.get("AGENT_ENV", KIT / "agent.env"))
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                cfg[k.strip()] = v.strip().strip('"').strip("'")
    for k in list(cfg):
        if k in os.environ:
            cfg[k] = os.environ[k]
    os.environ.update({k: str(v) for k, v in cfg.items()})  # tools_impl reads these
    if cfg["FAKE_MODEL"] != "1" and not env_file.exists():
        sys.exit("agent.env not found. Run: cp agent.env.example agent.env, "
                 "then fill it in.")
    return cfg


CFG: dict = {}


def on(key: str) -> bool:
    return CFG.get(key, "off").lower() in ("on", "1", "true", "yes")


# ============================================================ tools registry
def load_tools() -> list[dict]:
    """tools.json is a list of {name, description, parameters}. An optional "impl" names
    the function in tools_impl.py when a learner renames a tool."""
    tools = json.loads(Path(CFG["TOOLS_FILE"]).read_text(encoding="utf-8"))
    for t in tools:
        t.setdefault("parameters", {"type": "object", "properties": {}})
        t.setdefault("description", "")
    return tools


def impl_for(tool: dict):
    return tools_impl.IMPLEMENTATIONS.get(tool.get("impl", tool["name"]))


def is_side_effect(tool: dict) -> bool:
    return impl_for(tool) is tools_impl.reserve_book


ID_RE = r"[A-Z]{2,3}-[A-Z]{2,4}-\d{3}(?:-v\d)?"
LOOKUP_WORDS = re.compile(r"how many|left|in stock|available|stock of", re.I)
DIRECT_RE = re.compile(rf"^\s*how many copies of ({ID_RE}) (?:are |is )?"
                       r"(?:left|available|in stock)\??\s*$", re.I)


def classify(message: str) -> str:
    """The task a message asks for, judged by its first clause. Used by ROUTER (through
    DIRECT_RE) and by TOOLS_FOR_TASK, which sends only the tools that task needs."""
    first = re.split(r",| and | then ", message, maxsplit=1)[0].lower()
    if LOOKUP_WORDS.search(first):
        return "lookup"
    if re.search(r"\breserv|\bhold\b", first):
        return "reserve"
    if message.strip().endswith("?") or \
            re.match(r"(which|what|when|how|who|does|is|can)\b", first):
        return "question"
    return "chat"


def declarations_for(task: str, tools: list[dict]) -> list[dict]:
    if not on("TOOLS"):
        return []
    if on("TOOLS_FOR_TASK") and task != "reserve":
        return [t for t in tools if not is_side_effect(t)]
    return tools


def validate_args(schema: dict, args: dict) -> str | None:
    """A small JSON Schema check (types, enum, min/max, required, unknown keys). Done in
    code because the model's arguments are text it produced, not values we chose."""
    props = schema.get("properties", {})
    kinds = {"string": str, "integer": int, "number": (int, float), "boolean": bool}
    for name in schema.get("required", []):
        if name not in args:
            return f"missing required argument {name!r}"
    for name, value in args.items():
        if name not in props:
            return f"unexpected argument {name!r}"
        p = props[name]
        want = kinds.get(p.get("type"))
        if want is int and isinstance(value, float) and value.is_integer():
            value = int(value)
        bad_bool = isinstance(value, bool) and want is int
        if want and (not isinstance(value, want) or bad_bool):
            return f"{name}={value!r} is not {p['type']}"
        if "enum" in p and value not in p["enum"]:
            return f"{name}={value!r} not in {p['enum']}"
        if "minimum" in p and value < p["minimum"]:
            return f"{name}={value!r} < minimum {p['minimum']}"
        if "maximum" in p and value > p["maximum"]:
            return f"{name}={value!r} > maximum {p['maximum']}"
    return None


# ============================================================ the model — Gemini
def system_instruction(user: str) -> str:
    who = CALLERS[user]
    return (f"You are the Meridian Bookshelf assistant for bank staff. The caller is "
            f"{who['name']} ({who['role']}), user id '{user}'. When a tool fits the "
            f"request call it, passing caller='{user}'. Report tool results plainly, "
            "including errors. Answer questions about policies and procedures only from "
            "documents "
            f"you are given, with citations; otherwise say exactly: \"{REFUSAL}\"")


class GeminiModel:
    """google-genai on Vertex AI. Imported lazily so FAKE_MODEL=1 needs no SDK."""
    label = ""

    def __init__(self, user: str):
        from google import genai
        from google.genai import types
        self.types = types
        self.user = user
        self.client = genai.Client(vertexai=True, project=CFG["PROJECT_ID"],
                                   location=CFG["LOCATION"])
        self.label = f"{CFG['MODEL']} (Vertex AI, {CFG['LOCATION']})"

    def user_text(self, text: str):
        return text  # a str in contents becomes a user turn

    def function_responses(self, results: list[tuple[str, dict]]):
        t = self.types
        return t.Content(role="user", parts=[
            t.Part.from_function_response(name=name, response=result)
            for name, result in results])

    def generate(self, contents, decls, mode, allowed, grounding):
        t = self.types
        tools, tool_config = [], None
        if decls:
            tools.append(t.Tool(function_declarations=[
                t.FunctionDeclaration(name=d["name"], description=d["description"],
                                      parameters_json_schema=d["parameters"])
                for d in decls]))
            # allowed_function_names is only honoured when the mode is ANY.
            tool_config = t.ToolConfig(function_calling_config=t.FunctionCallingConfig(
                mode=t.FunctionCallingConfigMode[mode],
                allowed_function_names=allowed if mode == "ANY" and allowed else None))
        if grounding:
            # The Day 1 data store as a server-side tool, with this caller's filter.
            # Not verified live: retrieval and function declarations in one request.
            ds = (f"projects/{CFG['PROJECT_ID']}/locations/global/collections/"
                  f"default_collection/dataStores/{CFG['DATASTORE_ID']}")
            tools.append(t.Tool(retrieval=t.Retrieval(vertex_ai_search=t.VertexAISearch(
                datastore=ds, filter=CALLERS[self.user]["filter"]))))
        config = t.GenerateContentConfig(
            tools=tools or None, tool_config=tool_config,
            system_instruction=system_instruction(self.user))
        return self.client.models.generate_content(
            model=CFG["MODEL"], contents=contents, config=config)


# ============================================================ the model — FAKE stand-in
# A scripted stand-in with the same response shape (.text, .function_calls,
# .usage_metadata, .candidates[0].grounding_metadata, .candidates[0].content). It picks
# tools with a few keyword rules and is deterministic. It is not Gemini and the printout
# says so; the lab's live runs use the real model.
NUMBERS = {"a": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}


class FakeModel:
    label = "FAKE — scripted stand-in driven by keyword rules, not Gemini"

    def __init__(self, user: str):
        self.user = user
        self.issued: list[dict] = []   # one entry per function_call sent, in order
        self.retried: set[int] = set() # issued[i] already re-sent after PARALLEL=off
        self.no_tool: list[dict] = []  # wants with no declared tool to call
        self.taken = 0                 # how many wants have been handled

    def user_text(self, text: str):
        return {"role": "user", "text": text}

    def function_responses(self, results):
        return {"role": "user", "responses": results}

    # ---- what the message asks for
    def wants(self, msg: str) -> list[dict]:
        low = msg.lower()
        ids = re.findall(rf"\b{ID_RE}\b", msg)
        m = re.search(r"\b(a|one|two|three|four|five|six|\d+)\s+cop", low)
        copies = NUMBERS.get(m.group(1), None) if m else 1
        if m and copies is None:
            copies = int(m.group(1))
        m = re.search(r"\bfor (priya|daniel|mlro)\b", low)
        caller = m.group(1) if m else self.user
        if re.search(r"\bcheck again\b|\bone more\b", low) and ids:
            # Lab 2 Part B: "check how many copies of X are left, reserve one copy for
            # me, check again, then reserve one more" — a task that genuinely needs
            # four turns (lookup, reserve, lookup, reserve), one call per turn.
            return [{"kind": "sequence", "book_id": ids[0], "copies": 1,
                     "caller": caller}]
        out = []
        if LOOKUP_WORDS.search(low) and ids:
            out.append({"kind": "lookup", "book_id": ids[0]})
        if re.search(r"\breserv|\bhold\b", low) and ids:
            targets = ids if len(ids) > 1 or not out else ids[:1]
            for bid in targets:
                out.append({"kind": "reserve", "book_id": bid, "copies": copies,
                            "caller": caller})
        if out:
            return out
        if re.match(r"\s*(hello|hi|hey)\b", low):
            return [{"kind": "chat"}]
        if msg.strip().endswith("?") or re.match(r"(which|what|when|how|who)\b", low):
            return [{"kind": "search", "question": msg}]
        return [{"kind": "chat"}]

    # ---- which declared tool fits a want (descriptions first, then names)
    @staticmethod
    def pick(kind: str, decls: list[dict]) -> dict | None:
        def desc_has(*words):
            return [d for d in decls if any(
                w in (d["description"] + " " + d["name"]).lower() for w in words)]
        if kind == "reserve":
            by_desc = [d for d in decls if "reserv" in d["description"].lower()]
            if by_desc:
                return by_desc[-1]      # six look-alikes: the last declared wins
            if not any("reserv" in d["name"].lower() for d in decls):
                return None             # nothing declared for reserving at all
            fallback = desc_has("copies", "stock", "book")   # "does things" says nothing
            return fallback[0] if fallback else None
        if kind == "lookup":
            c = desc_has("copies", "stock", "available")
            c = [d for d in c if not is_side_effect(d)] or c
            return c[0] if c else None
        if kind == "search":
            c = desc_has("search", "answer")
            return c[0] if c else None
        return None

    def args_for(self, tool: dict, want: dict) -> dict:
        values = {"book_id": want.get("book_id", "POL-CR-014"),
                  "copies": want.get("copies", 1),
                  "caller": want.get("caller", self.user),
                  "question": want.get("question", "")}
        props = tool["parameters"].get("properties", {})
        return {k: values[k] for k in props if k in values}

    def generate(self, history, decls, mode, allowed, grounding):
        if float(CFG["FAKE_DELAY"]) > 0:
            time.sleep(float(CFG["FAKE_DELAY"]))
        msg = history[0]["text"]
        done = [r for h in history if h.get("responses") for r in h["responses"]]
        wants = self.wants(msg)
        calls, chunks, text = [], [], ""
        if mode == "NONE":
            text = self.talk_only(wants)
        elif wants[0]["kind"] == "sequence":
            calls = self.sequence_call(decls, wants[0], done)
            if not calls:
                text, chunks = self.reply(wants, done, grounding)
        else:
            # Under ANY with ALLOWED the model can only name the allowed tools.
            pool = decls
            if mode == "ANY" and allowed:
                pool = [d for d in decls if d["name"] in allowed]
            calls = self.next_calls(wants, pool, done)
            if mode == "ANY" and not calls and pool:
                calls = [self.forced_call(pool, wants)]
            if not calls:
                text, chunks = self.reply(wants, done, grounding)
        self.issued += [c["want"] for c in calls]
        fcs = [NS(name=c["name"], args=c["args"]) for c in calls]
        model_turn = {"role": "model", "calls": [(c["name"], c["args"]) for c in calls],
                      "text": text}
        n_parts = sum(1 + len(h.get("responses", [])) for h in history)
        usage = NS(prompt_token_count=60 + 30 * len(decls) + 15 * n_parts,
                   candidates_token_count=25 + 20 * len(calls))
        gm = NS(grounding_chunks=[NS(retrieved_context=NS(**c)) for c in chunks],
                grounding_supports=[]) if grounding else None
        return NS(text=text or None, function_calls=fcs or None, usage_metadata=usage,
                  candidates=[NS(content=model_turn, grounding_metadata=gm)])

    def next_calls(self, wants, decls, done):
        """Everything not yet handled, plus anything the loop refused with
        'one action per turn' (PARALLEL=off), all in one turn."""
        pending = []
        for i, (want, (_, result)) in enumerate(zip(self.issued, done)):
            if result.get("error") == "one action per turn" and i not in self.retried:
                self.retried.add(i)
                pending.append(want)
        pending += wants[self.taken:]
        self.taken = len(wants)
        calls = []
        for want in pending:
            if want["kind"] == "chat":
                continue
            if want["kind"] == "search" and on("GROUNDING"):
                continue  # the server-side tool answers; no client call
            tool = self.pick(want["kind"], decls)
            if tool is None:
                self.no_tool.append(want)
                continue
            calls.append({"name": tool["name"], "args": self.args_for(tool, want),
                          "want": want})
        return calls

    def sequence_call(self, decls, want, done):
        """One call per turn, in the order the message gives them: lookup, reserve,
        lookup, reserve. The turn number is how many results have come back."""
        order = ["lookup", "reserve", "lookup", "reserve"]
        if len(done) >= len(order):
            return []               # all four done: the next turn is the text reply
        kind = order[len(done)]
        tool = self.pick(kind, decls)
        if tool is None:
            return []
        w = {**want, "kind": kind}
        return [{"name": tool["name"], "args": self.args_for(tool, w), "want": w}]

    def forced_call(self, pool, wants):
        """MODE=ANY: a call is required whether or not one is useful."""
        tool = pool[0]
        want = {"kind": "forced"}
        return {"name": tool["name"], "args": self.args_for(tool, want), "want": want}

    def talk_only(self, wants) -> str:
        w = wants[0]
        if w["kind"] in ("reserve", "sequence"):
            return ("I can't take that action in this conversation. Reserving "
                    f"{w.get('book_id', 'those documents')} would need the "
                    "reserve_book tool.")
        if w["kind"] == "lookup":
            return (f"I can't check stock in this conversation; {w['book_id']} is in "
                    "the library.")
        return "Hello. Ask me about stock or reservations in the Bookshelf."

    def reply(self, wants, done, grounding):
        """Final text once every issued call has a response."""
        who = CALLERS[self.user]
        lines, chunks = [], []
        for want, (name, result) in zip(self.issued, done):
            bid = want.get("book_id") or want.get("question", "that")
            if result.get("error") == "one action per turn":
                continue  # re-sent in a later turn; that entry carries the outcome
            if want["kind"] == "forced":
                lines.append(f"Hello. I called {name} because a tool call was required: "
                             f"{fmt(result)}")
            elif "error" in result:
                verb = {"reserve": "reserve", "lookup": "check", "search": "search for"}
                lines.append(f"I could not {verb.get(want['kind'], 'complete')} {bid}: "
                             f"{result['error']}.")
            elif want["kind"] == "reserve" and "reservation_id" in result:
                lines.append(f"Reserved {result['copies']} of {bid} for "
                             f"{want['caller']} ({result['reservation_id']}); "
                             f"{result['copies_available']} left.")
            elif "copies_available" in result:
                lines.append(f"{bid} — {result.get('title', '')}: "
                             f"{result['copies_available']} of "
                             f"{result.get('copies_total', 3)} copies available.")
            elif "answer" in result:
                cites = "".join(f" [{c['n']}] {c['title']}" for c in result["citations"])
                lines.append(result["answer"] + cites)
        for want in self.no_tool:
            if want["kind"] == "search":
                lines.append("I don't have access to Meridian's documents in this "
                             "conversation, so I cannot say which form applies. Please "
                             "check the policy directly.")
            else:
                lines.append(f"I cannot {want['kind']} {want.get('book_id', 'that')}: "
                             "no tool for it is available to me.")
        for want in wants:
            if want["kind"] == "search" and grounding:
                if tools_impl.is_dispute_question(want["question"]) and \
                        "confidential" in who["filter"]:
                    lines.append(FRM_ANSWER)
                    chunks.append(FRM_CHUNK)
                else:
                    lines.append(REFUSAL)
            elif want["kind"] == "chat" and not lines:
                lines.append(self.talk_only([want]))
        return " ".join(lines) or "Done.", chunks


# ============================================================ the loop
class ToolFailure(Exception):
    """The tool did not produce a result: timeout, 5xx, unparseable body."""


class Run:
    def __init__(self, user: str, message: str):
        self.user, self.message = user, message
        self.tools = load_tools()
        self.steps = self.calls = 0          # steps = model calls, calls = tool runs
        self.tokens_in = self.tokens_out = 0
        self.t0 = time.monotonic()
        self.stopped = False

    # ---- bounds and cost
    def cost(self) -> float:
        return (self.tokens_in * float(CFG["PRICE_INPUT_PER_M"])
                + self.tokens_out * float(CFG["PRICE_OUTPUT_PER_M"])) / 1e6

    def elapsed(self) -> float:
        return time.monotonic() - self.t0

    def bound_hit(self) -> str | None:
        if self.steps >= int(CFG["MAX_STEPS"]):
            return f"MAX_STEPS={CFG['MAX_STEPS']} reached"
        if self.elapsed() > float(CFG["MAX_SECONDS"]):
            return f"MAX_SECONDS={CFG['MAX_SECONDS']} reached ({self.elapsed():.1f}s)"
        if self.cost() > float(CFG["MAX_COST_USD"]):
            return f"MAX_COST_USD={CFG['MAX_COST_USD']} reached (${self.cost():.6f})"
        return None

    # ---- entry
    def go(self) -> None:
        print_header(self)
        if on("ROUTER"):
            m = DIRECT_RE.match(self.message)
            if m:
                say(f"route: direct (matched: how many copies of {m.group(1)} are left)")
                self.direct_lookup(m.group(1))
                print_stats(self)
                return
            say("route: model")
        task = classify(self.message)
        decls = declarations_for(task, self.tools)
        backend = FakeModel if CFG["FAKE_MODEL"] == "1" else GeminiModel
        model = backend(self.user)
        contents = [model.user_text(self.message)]
        allowed = [a.strip() for a in CFG["ALLOWED"].split(",") if a.strip()]
        if allowed and CFG["MODE"] != "ANY":
            say(f"note: ALLOWED={CFG['ALLOWED']} is ignored unless MODE=ANY")
        while True:
            bound = self.bound_hit()
            if bound:
                say(f"bound: {bound} — stopping")
                break
            # ANY forces a call on the first turn only; kept on, the loop could never end.
            mode = CFG["MODE"] if self.steps == 0 or CFG["MODE"] != "ANY" else "AUTO"
            print_to_model(self, decls, mode, allowed, task)
            resp = model.generate(contents, decls, mode, allowed, on("GROUNDING"))
            self.steps += 1
            self.add_usage(resp)
            fcs = list(resp.function_calls or [])
            print_from_model(resp, fcs)
            if not fcs:
                break
            contents.append(resp.candidates[0].content)
            results = []
            for i, fc in enumerate(fcs):
                args = dict(fc.args or {})
                if not on("PARALLEL") and i > 0:
                    say(f"⚙ run {fc.name}({fmt(args)}) → blocked: one action per turn "
                        "(PARALLEL=off)")
                    results.append((fc.name, {"error": "one action per turn"}))
                    continue
                results.append((fc.name, self.execute(fc.name, args)))
                if self.stopped:
                    print_stats(self)
                    return
            for name, result in results:
                say(f"← function_response {name} {fmt(result)}")
            contents.append(model.function_responses(results))
        print_stats(self)

    def add_usage(self, resp) -> None:
        u = getattr(resp, "usage_metadata", None)
        self.tokens_in += getattr(u, "prompt_token_count", 0) or 0
        self.tokens_out += getattr(u, "candidates_token_count", 0) or 0

    def direct_lookup(self, book_id: str) -> None:
        """ROUTER=on: a stock question needs no model. Same tool, no tokens."""
        self.calls += 1
        result = tools_impl.lookup_stock(book_id)
        say(f"⚙ run lookup_stock({fmt({'book_id': book_id})}) → {fmt(result)}")
        if "error" in result:
            say(f"answer: {result['error']}")
        else:
            say(f"answer: {book_id} — {result['title']}: {result['copies_available']} of "
                f"{result['copies_total']} copies available.")

    # ---- one function call → one result
    def execute(self, name: str, args: dict) -> dict:
        # The API returns whole numbers as floats (2.0); integer-typed args are meant.
        args = {k: int(v) if isinstance(v, float) and v.is_integer() else v
                for k, v in args.items()}
        head = f"⚙ run {name}({fmt(args)})"
        tool = next((t for t in self.tools if t["name"] == name), None)
        if tool is None:
            say(f"{head} → blocked: {name} is not declared in tools.json")
            return {"error": f"unknown tool {name}"}
        impl = impl_for(tool)
        if impl is None:
            say(f"{head} → blocked: no implementation for {name!r} (declared in "
                "tools.json, missing in tools_impl.py)")
            return {"error": f"no implementation for {name}"}
        if on("VALIDATE"):
            problem = validate_args(tool["parameters"], args)
            if problem:
                say(f"{head} → blocked: invalid args: {problem}")
                return {"error": f"invalid args: {problem}"}
        if "caller" in args and args["caller"] != self.user:
            # The caller (and so the filter string) is the session's, never the model's.
            say(f"{head} → blocked: caller mismatch: model said {args['caller']!r}, this "
                f"session is {self.user!r}")
            return {"error": f"caller must be {self.user}"}
        if is_side_effect(tool):
            verdict = self.approval(args)
            if verdict:
                say(f"{head} → blocked: {verdict}")
                return {"error": verdict}
        self.calls += 1
        try:
            result = self.call_with_policy(impl, args, is_side_effect(tool))
        except ToolFailure as e:
            if on("RETURN_ERRORS"):
                say(f"{head} → error: {e}")
                return {"error": str(e)}
            say(f"{head} → failed: {e}")
            say("stop: not returned to the model (RETURN_ERRORS=off) — a person looks "
                "at this")
            self.stopped = True
            return {"error": str(e)}
        say(f"{head} → {fmt(result)}")
        return result

    def approval(self, args: dict) -> str | None:
        """APPROVE=off blocks, auto runs, ask shows a card and waits for y/n."""
        policy = CFG["APPROVE"].lower()
        if policy == "off":
            return "needs approval (APPROVE=off)"
        if policy != "ask":
            return None
        print_approval_card(self, args)
        answer = sys.stdin.readline().strip().lower()
        say(f"approval: {answer or 'n'}")
        return None if answer == "y" else "declined by approver"

    def call_with_policy(self, impl, args: dict, side_effect: bool) -> dict:
        """Faults, retries with backoff, and one Idempotency-Key per logical request."""
        key = None
        if side_effect and on("IDEMPOTENCY"):
            key = tools_impl.new_idempotency_key()
            say(f"   idempotency-key: {key} (same key on every retry)")
        retries = int(CFG["RETRY"])
        for attempt in range(retries + 1):
            try:
                return self.attempt(impl, args, key, side_effect, attempt)
            except ToolFailure as e:
                if attempt >= retries:
                    raise
                wait = float(CFG["RETRY_BACKOFF"]) * 2 ** attempt
                say(f"   retry {attempt + 1}/{retries} in {wait}s: {e}")
                time.sleep(wait)
        raise AssertionError("unreachable")

    def attempt(self, impl, args, key, side_effect, attempt) -> dict:
        fault = CFG["FAULT"].lower()
        if side_effect and attempt == 0 and fault != "none":
            # Injected once, on the first attempt, so a retry can get through.
            say(f"   fault: {fault} (injected in the reserve_book wrapper)")
            if fault == "timeout":
                raise ToolFailure("timeout: no response from bookshelf-api after 10s")
            if fault == "500":
                raise ToolFailure("HTTP 500 from bookshelf-api: internal error")
            if fault == "garbage":
                raise ToolFailure("unparseable response from bookshelf-api: "
                                  "'<html><h1>502 Bad Gateway</h1></html>'")
            if fault == "timeout-after-success":
                self.invoke(impl, args, key, side_effect)   # the API did the work…
                raise ToolFailure("timeout: no response from bookshelf-api after 10s")
        result = self.invoke(impl, args, key, side_effect)
        if str(result.get("error", "")).startswith("HTTP 5"):
            raise ToolFailure(result["error"])
        return result

    @staticmethod
    def invoke(impl, args, key, side_effect) -> dict:
        try:
            return impl(**args, idempotency_key=key) if side_effect else impl(**args)
        except TypeError as e:
            return {"error": f"bad arguments: {e}"}
        except Exception as e:  # requests.Timeout / ConnectionError, without the import
            kind = type(e).__name__
            if "Timeout" in kind:
                raise ToolFailure("timeout: no response from bookshelf-api after 10s")
            raise ToolFailure(f"{kind}: {str(e)[:120]}")


# ============================================================ printing
def say(line: str) -> None:
    print(line, flush=True)


def fmt(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(", ", ": "))


def print_header(run: Run) -> None:
    who = CALLERS[run.user]
    say(f"caller: {run.user} ({who['name']}, {who['role']}, "
        f"clearance {who['clearance']})")
    if CFG["FAKE_MODEL"] == "1":
        say(f"model: {FakeModel.label}")
    else:
        say(f"model: {CFG['MODEL']} (Vertex AI, {CFG['LOCATION']})")
    if CFG["FAKE_API"] == "1":
        say("api: FAKE — in-process catalogue, no network")
    else:
        say(f"api: {CFG['BOOKSHELF_API_URL'] or '(BOOKSHELF_API_URL not set)'}")
    say(f"message: {run.message}")


def print_to_model(run: Run, decls, mode, allowed, task) -> None:
    names = ", ".join(d["name"] for d in decls)
    bits = [f"→ model  turn {run.steps + 1}"]
    if on("TOOLS_FOR_TASK"):
        bits.append(f"task={task}")
    bits.append(f"tools=[{names}]")
    bits.append(f"mode={mode}" + (f" allowed=[{', '.join(allowed)}]"
                                  if mode == "ANY" and allowed else ""))
    if CFG["MODE"] == "ANY" and mode == "AUTO":
        bits[-1] += " (ANY applied to the first turn only)"
    bits.append(f"grounding={'on' if on('GROUNDING') else 'off'}")
    say("  ".join(bits))


def print_from_model(resp, fcs) -> None:
    for fc in fcs:
        say(f"← model  function_call {fc.name}({fmt(dict(fc.args or {}))})")
    if not fcs:
        say(f"← model  text: {(resp.text or '').strip()}")
    if on("GROUNDING"):
        try:
            chunks = resp.candidates[0].grounding_metadata.grounding_chunks or []
        except (AttributeError, IndexError, TypeError):
            chunks = []
        if chunks:
            for i, ch in enumerate(chunks, 1):
                rc = getattr(ch, "retrieved_context", None)
                say(f"   grounding: [{i}] {getattr(rc, 'title', '?')} "
                    f"({getattr(rc, 'uri', '')})")
            say("   grounding: server-side retrieval — no call from our side")
        elif not fcs and getattr(resp.candidates[0], "grounding_metadata", None):
            say("   grounding: no chunks returned (nothing passed the caller's filter)")


def print_approval_card(run: Run, args: dict) -> None:
    if CFG["APPROVE_CARD"].lower() == "minimal":
        say("approve reserve_book? [y/n]")
        return
    bid, copies = args.get("book_id", "?"), args.get("copies", "?")
    stock = tools_impl.lookup_stock(bid) if bid != "?" else {}
    have = stock.get("copies_available", "?")
    after = have - copies if isinstance(have, int) and isinstance(copies, int) else "?"
    who = CALLERS.get(args.get("caller", ""), {})
    say("┌─ approval needed ─────────────────────────────────────────────")
    say("│ action   reserve_book")
    say(f"│ book     {bid} — {stock.get('title', TITLES.get(bid, 'unknown document'))}")
    say(f"│ copies   {copies}  ({have} available now, {after} after)")
    say(f"│ caller   {args.get('caller', '?')} — {who.get('name', '?')}, "
        f"{who.get('role', '?')}, clearance {who.get('clearance', '?')}")
    say("└─ approve? [y/n]")


def print_stats(run: Run) -> None:
    say(f"steps={run.steps} calls={run.calls} tokens={run.tokens_in + run.tokens_out} "
        f"cost=${run.cost():.6f} elapsed={run.elapsed():.2f}s")


# ============================================================ main
def main(argv=None) -> None:
    global CFG
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--user", choices=sorted(CALLERS), help="who is asking, callers.json")
    ap.add_argument("message", nargs="?", help="what they say")
    ap.add_argument("--reset", action="store_true", help="catalogue back to 3 copies")
    ap.add_argument("--selftest", action="store_true", help="run scripts/selftest.sh")
    a = ap.parse_args(argv)
    if a.selftest:
        os.execvp("bash", ["bash", str(KIT / "scripts" / "selftest.sh")])
    CFG = load_config()
    if a.reset:
        say(fmt(tools_impl.reset_catalogue()))
        return
    if not a.user or not a.message:
        ap.error("--user NAME and a message are required")
    Run(a.user, a.message).go()


if __name__ == "__main__":
    main()
