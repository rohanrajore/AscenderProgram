# regai-d2-agent-kit — the Bookshelf assistant with tools, Days 2 and 3

One small service, `agent.py`, runs a Gemini model on Vertex AI in a loop: send the
message and the tool definitions, run whatever function call comes back, send the result
in, repeat until the model answers in text. Day 2 (Lab 1) gives it tools and controls when
they fire. Day 3 (Lab 2) bounds the loop, adds an approval point and handles failures.

You edit two files and run the service. You write no code.

| File | What you change |
|---|---|
| `tools.json` | the tool definitions the model sees: name, description, parameters (JSON Schema) |
| `agent.env` | your project ids and the switches; each lab part flips one |

## Set-up

In Cloud Shell, upload the zip, then:

```
unzip regai-d2-agent-kit.zip && cd regai-d2-agent-kit
cp agent.env.example agent.env
source ~/regai-venv/bin/activate && pip install -q google-genai requests
```

Fill in the first block of `agent.env`: `PROJECT_ID`, `DATASTORE_ID` and `APP_ID` from
Day 1 (the console-generated ids), `BOOKSHELF_API_URL` from Day 0. Then:

```
python agent.py --user daniel "hello"
```

`--user` is one of `priya`, `daniel`, `mlro` from `callers.json`; it decides the filter
string the tools use. A switch on the command line wins over `agent.env` for one run:

```
MODE=NONE python agent.py --user daniel "hello"
```

`python agent.py --reset` puts the library back to three copies of every book.

## What is here

```
README.md            this file
agent.env.example    project ids and every switch, with the default (Lab 1 Part A) values
tools.json           the tool definitions you edit; ships with lookup_stock and search_bookshelf
callers.json         priya / daniel / mlro: clearance and filter string, as on Day 1
agent.py             the service: config → tools registry → the model → the loop → printing
tools_impl.py        the tool implementations: lookup_stock, reserve_book, search_bookshelf
fixtures/            tools.json as each part expects it (copy one if you are behind)
scripts/selftest.sh  every part of both labs, offline, with a scripted stand-in model
```

## Reading the printout

From `scripts/selftest.sh`, Lab 1 Part C (the stand-in model and catalogue; a live run
prints the model name and the service URL on lines 2 and 3 instead):

```
caller: daniel (Daniel Okafor, Dispute Officer, clearance confidential)
model: FAKE — scripted stand-in driven by keyword rules, not Gemini
api: FAKE — in-process catalogue, no network
message: Reserve two copies of PRC-KYC-003 for daniel
→ model  turn 1  tools=[lookup_stock, search_bookshelf, reserve_book]  mode=AUTO  grounding=off
← model  function_call reserve_book({"book_id": "PRC-KYC-003", "copies": 2, "caller": "daniel"})
⚙ run reserve_book({"book_id": "PRC-KYC-003", "copies": 2, "caller": "daniel"}) → {"reservation_id": "res_fake0001", "book_id": "PRC-KYC-003", "copies": 2, "copies_available": 1, "replayed": false}
← function_response reserve_book {"reservation_id": "res_fake0001", "book_id": "PRC-KYC-003", "copies": 2, "copies_available": 1, "replayed": false}
→ model  turn 2  tools=[lookup_stock, search_bookshelf, reserve_book]  mode=AUTO  grounding=off
← model  text: Reserved 2 of PRC-KYC-003 for daniel (res_fake0001); 1 left.
steps=2 calls=1 tokens=445 cost=$0.000287 elapsed=0.00s
```

`→ model` is what was sent (which tools, which mode). `← model` is what came back: text, or
one `function_call` line per call. `⚙ run` is our code running the call, or `blocked:` with
the reason. `← function_response` is what went back to the model. The last line:
`steps` = model calls, `calls` = tool runs, `cost` = tokens × the prices in `agent.env`.

## The switches

| Switch | Part | Effect |
|---|---|---|
| `TOOLS=off/on` | 1-A, 1-C | `off`: no function tools are sent; `on`: everything in `tools.json` |
| `GROUNDING=on/off` | 1-B | adds the Day 1 data store as a server-side retrieval tool with the caller's filter |
| `MODE=AUTO/ANY/NONE`, `ALLOWED=name,name` | 1-D | `function_calling_config`; `ALLOWED` counts only with `MODE=ANY`, and `ANY` applies to the first turn |
| `PARALLEL=on/off` | 1-D | `on`: run every function_call in the turn; `off`: run the first, return `{"error":"one action per turn"}` for the rest |
| `VALIDATE=on/off` | 1-F | check each call's arguments against the JSON Schema in code before running; reject with an error result |
| `APPROVE=off/auto/ask` | 1-F, 2-D | `off`: reserve_book is blocked ("needs approval"); `auto`: runs; `ask`: prints the approval card and waits for y/n |
| `APPROVE_CARD=full/minimal` | 2-D | the card with book, copies, copies left and caller — or one bare line |
| `ROUTER=on/off` | 2-A | `on`: a stock question matched by a regex goes straight to bookshelf-api, no model call; prints `route: direct` or `route: model` |
| `MAX_STEPS`, `MAX_SECONDS`, `MAX_COST_USD` | 2-B | the loop stops and prints which bound hit; cost from token counts × `PRICE_INPUT_PER_M` / `PRICE_OUTPUT_PER_M` |
| `TOOLS_FOR_TASK=on/off` | 2-C | `on`: the tool list sent depends on the task; a lookup gets no reserve_book; the printout shows `task=` and the tools sent |
| `FAULT=none/timeout/500/garbage/timeout-after-success` | 2-E, 2-F | injected in the reserve_book wrapper, once, on the first attempt |
| `RETURN_ERRORS=on/off` | 2-E | `on`: the error text goes back to the model; `off`: the run stops and a person looks |
| `RETRY=0..3`, `RETRY_BACKOFF` | 2-F | retries with backoff (`RETRY_BACKOFF × 2ⁿ` seconds) |
| `IDEMPOTENCY=on/off` | 2-F | `on`: one `Idempotency-Key` per request, the same on every retry, sent to bookshelf-api |

Two things live in your code on Gemini that are API features elsewhere: checking the
arguments before running a call (`VALIDATE`) and running one call at a time (`PARALLEL`).
The model may return several function calls in one turn; the loop decides what to run.

## Lab 1 — give the service a tool, and control when it fires

Every command is one line. Watch the `→ model`, `← model` and `⚙ run` lines.

**A — no tools.** `agent.env` as shipped (`TOOLS=off`).

```
python agent.py --user daniel "Which form must a cardholder sign before a dispute can go to chargeback?"
```

`tools=[]`; the model answers from nothing, or says it cannot.

**B — the Day 1 store as a server-side tool.** Set `GROUNDING=on`.

```
python agent.py --user daniel "Which form must a cardholder sign before a dispute can go to chargeback?"
python agent.py --user priya "Which form must a cardholder sign before a dispute can go to chargeback?"
```

daniel gets a cited answer with `grounding:` lines and no `⚙ run` line: the retrieval ran
on Google's side. priya's filter stops at `internal`, so the confidential policy is out of
reach and the answer says so.

**C — define a tool.** Set `GROUNDING=off` and `TOOLS=on`. Add `reserve_book` to
`tools.json` after `search_bookshelf` (mind the comma):

```json
{
  "name": "reserve_book",
  "description": "Reserve copies of a document in the Bookshelf library for a member of staff. Use when the caller asks to reserve, hold or book copies. This changes library records.",
  "parameters": {
    "type": "object",
    "properties": {
      "book_id": {"type": "string", "description": "Document id, e.g. PRC-KYC-003"},
      "copies": {"type": "integer", "minimum": 1, "maximum": 3, "description": "Copies to reserve, 1 to 3"},
      "caller": {"type": "string", "enum": ["priya", "daniel", "mlro"], "description": "Who the reservation is for"}
    },
    "required": ["book_id", "copies", "caller"]
  }
}
```

```
python agent.py --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
python agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
```

function_call → `⚙ run` → function_response → confirmation. `lookup_stock` was already
there and shows one copy left.

**D — control when it fires.**

```
MODE=NONE python agent.py --user daniel "Reserve two copies of PRC-KYC-003 for daniel"
MODE=ANY python agent.py --user daniel "hello"
MODE=ANY ALLOWED=reserve_book python agent.py --user daniel "hello"
python agent.py --user daniel "Reserve one copy of PRC-KYC-003 and PRC-CR-030 for daniel"
PARALLEL=off python agent.py --user daniel "Reserve one copy of PRC-KYC-003 and PRC-CR-030 for daniel"
```

`NONE`: talk only. `ANY` on "hello": a call the request never needed, and its cost.
`ALLOWED`: the call is forced to one tool. Two documents: two function calls in one
turn. `PARALLEL=off`: the second is refused and comes back in the next turn.

**E — when selection goes wrong.** In `tools.json`, change reserve_book's description to
`"does things"` and run the reservation from Part C again. Put the description back, then
add five look-alikes (`reserve_books`, `book_reserve`, `reserve_copy`, `make_reservation`,
`reserve_book_for_staff`, each with the same parameters and a one-line description) and run
it again. Delete the five and run it once more. `fixtures/tools.lab1e-bad.json` and
`fixtures/tools.lab1e-dupes.json` are the two broken states if you want to copy them.

**F — determinism in code.**

```
VALIDATE=on python agent.py --user daniel "Reserve five copies of PRC-KYC-003 for daniel"
APPROVE=off python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
APPROVE=off python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
APPROVE=off python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
python agent.py --user priya "Reserve one copy of PRC-KYC-003 for daniel"
```

Five copies is outside the schema: blocked in code before any call. `APPROVE=off` blocks
the reservation however it is asked, three times the same. The last one: the caller, and
so the filter string, is the session's; the model never chooses it.

## Lab 2 — bound a workflow with approval and failure handling

Start from `fixtures/tools.lab2.json` (`cp fixtures/tools.lab2.json tools.json`) with
`TOOLS=on`, `APPROVE=auto`, everything else as shipped.

**A — workflow or agent.** Set `ROUTER=on`.

```
python agent.py --user daniel "how many copies of PRC-KYC-003 are left"
python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
```

`route: direct` with `steps=0` and no tokens; `route: model` for the reservation.
Compare the last lines.

**B — bounds.**

```
MAX_STEPS=3 python agent.py --user daniel "Check how many copies of PRC-KYC-003 are left, reserve one copy for me, check again, then reserve one more"
MAX_SECONDS=5 python agent.py --user daniel "Check how many copies of PRC-KYC-003 are left, reserve one copy for me, check again, then reserve one more"
MAX_COST_USD=0.0003 python agent.py --user daniel "Check how many copies of PRC-KYC-003 are left, reserve one copy for me, check again, then reserve one more"
```

The request genuinely needs four turns (lookup, reserve, lookup, reserve), one call
each. The bound is checked before each model call: with `MAX_STEPS=3` the turns are
lookup → reserve → lookup, then `bound: MAX_STEPS=3 reached — stopping`,
`steps=3 calls=3`, and the fourth turn (the second reserve) never happens — stock is
down by exactly one. Likewise for the other two (measured live: the 3-step run takes
about 6 s and costs about $0.0004, so `MAX_SECONDS=5` and `MAX_COST_USD=0.0003` trip on
turn 2 or 3). The request must name the document and the steps: an open-ended ask
("reserve one copy of every procedure until none are left") is declined by the model,
which asks for a document id and a count — `steps=1 calls=0`, no bound trips. Run
`python agent.py --reset` afterwards.

**C — scoping permissions.** Set `TOOLS_FOR_TASK=on`.

```
python agent.py --user daniel "How many copies of PRC-KYC-003 are left, and reserve it for daniel"
```

`task=lookup  tools=[lookup_stock, search_bookshelf]`: reserve_book was never offered.
Set it back to `off` and run the same line: now it reserves.

**D — an approval a human can judge.** Set `APPROVE=ask`.

```
python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
APPROVE_CARD=minimal python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
```

The card shows book, copies, copies left and caller; answer `y` or `n`. The minimal card
shows nothing to judge. Set `APPROVE=auto` again before Part E.

**E — tool failure.**

```
FAULT=timeout python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
FAULT=500 python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
FAULT=garbage python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
FAULT=500 RETURN_ERRORS=off python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
```

With `RETURN_ERRORS=on` the error text goes back as the function_response and the model
reports it. With `off` the run stops at `⚙ run … → failed:` and nothing is sent to the model.

**F — retries and idempotency.** First redeploy bookshelf-api from the updated Day 0 kit
(`bash deploy.sh` again in `day0-bookshelf-api`), then `python agent.py --reset`.

```
FAULT=timeout-after-success RETRY=2 python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
python agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
python agent.py --reset
FAULT=timeout-after-success RETRY=2 IDEMPOTENCY=on python agent.py --user daniel "Reserve one copy of PRC-KYC-003 for daniel"
python agent.py --user daniel "How many copies of PRC-KYC-003 are left?"
```

The API did the work, the response was lost, the retry did it again: one copy left of
three. With `IDEMPOTENCY=on` the retry carries the same key, the API replays the original
reservation (`"replayed": true`) and two copies are left.

## If you are behind

Copy the `tools.json` a part expects and carry on:

| Before | Copy |
|---|---|
| Lab 1 A, B | `cp fixtures/tools.lab1a.json tools.json` (as shipped) |
| Lab 1 C, D, F | `cp fixtures/tools.lab1c.json tools.json` |
| Lab 1 E, first run | `cp fixtures/tools.lab1e-bad.json tools.json` |
| Lab 1 E, second run | `cp fixtures/tools.lab1e-dupes.json tools.json` |
| Lab 1 E, last run | `cp fixtures/tools.lab1e-fixed.json tools.json` |
| Lab 2 | `cp fixtures/tools.lab2.json tools.json` |

Switch values per part are in `agent.env.example`, next to each switch.

## Running everything offline

```
bash scripts/selftest.sh
```

runs every part of both labs with `FAKE_MODEL=1` (a scripted stand-in that picks tools by
keyword rules; the printout says `model: FAKE`) and `FAKE_API=1` (an in-process copy of
the catalogue), and checks the printed outcomes. It needs no project, no network and no
SDK. It shows that the loop and the switches do what this file says; only the live model
shows what Gemini chooses to do.

## If something fails

| Symptom | Fix |
|---|---|
| `agent.env not found` | `cp agent.env.example agent.env` and fill in the first block |
| `BOOKSHELF_API_URL is empty` | the URL printed by Day 0's `deploy.sh`, into `agent.env` |
| `HTTP 401` / `403` from bookshelf-api | `gcloud auth login`; your account needs `roles/run.invoker` on the service |
| The model is refused at `LOCATION=global` | use the `LOCATION=us-central1` line in `agent.env` |
| `no implementation for '…'` | a tool in `tools.json` has a name `tools_impl.py` does not know; rename it back, or add `"impl": "reserve_book"` to the entry |
| Stock numbers look wrong | `python agent.py --reset` |
